import React, { useState, useRef, useEffect } from 'react';
import { Camera, Upload, RefreshCw, CheckCircle, Leaf, ShieldAlert } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface ScanResult {
  category: 'Plastic' | 'Glass' | 'Metal' | 'Paper' | 'Organic' | 'E-Waste' | 'Medical' | 'Hazardous';
  itemName: string;
  confidence: number;
  impact: string;
  instructions: string;
  center: string;
  coinsReward: number;
}

const mockDatabase: Record<string, ScanResult> = {
  bottle: { category: 'Plastic', itemName: 'PET Plastic Bottle', confidence: 97.4, impact: 'Reduces landfill waste; saves 0.05 kWh of electricity.', instructions: 'Rinse thoroughly, crush to save space, and discard cap separately in the Dry Waste bin.', center: 'Vesu Municipal Recycling Hub (1.2 km)', coinsReward: 15 },
  can: { category: 'Metal', itemName: 'Aluminum Soda Can', confidence: 95.8, impact: 'Saves 95% of the energy needed to make a new can from ore.', instructions: 'Ensure it is empty. Rinse, crush, and place in the Metal/Recyclable section.', center: 'Adajan Metal Collection Point (2.4 km)', coinsReward: 25 },
  box: { category: 'Paper', itemName: 'Cardboard Shipping Box', confidence: 94.2, impact: 'Prevents deforestation; saves 24 liters of water per kg.', instructions: 'Remove adhesive tape, flatten completely, and keep dry. Place in the Paper/Cardboard bin.', center: 'Surat Central Pulp Recycling (3.1 km)', coinsReward: 20 },
  apple: { category: 'Organic', itemName: 'Organic Fruit Waste (Apple Core)', confidence: 98.1, impact: 'Avoids methane emissions in landfills. Creates nutrient-rich compost.', instructions: 'Place in the green WET waste bin for municipal composting. No plastic packaging!', center: 'Green Compost Yard - Zone A (0.7 km)', coinsReward: 10 },
  phone: { category: 'E-Waste', itemName: 'Old Lithium-Ion Battery / Smartphone', confidence: 91.5, impact: 'Prevents heavy metal leakage (lithium/cobalt) into soils.', instructions: 'Do not throw in household bins! Store in a dry box and schedule an E-Waste pickup.', center: 'EcoSync E-Waste Secure Segregator (4.5 km)', coinsReward: 75 },
  syringe: { category: 'Medical', itemName: 'Medical Syringe / Needle', confidence: 89.9, impact: 'Prevents infectious exposure to waste collectors.', instructions: 'CRITICAL: Place in a puncture-proof container and request Emergency Hazardous Waste pickup.', center: 'Civil Hospital Incineration Depot (2.9 km)', coinsReward: 30 }
};

export const AIWasteScanner: React.FC = () => {
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [image, setImage] = useState<string | null>(null);
  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState<ScanResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'camera' | 'upload'>('camera');

  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Stop camera stream
  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  };

  // Start camera stream
  const startCamera = async () => {
    setError(null);
    try {
      stopCamera();
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (err) {
      setError('Could not access camera. Please upload an image instead.');
      setActiveTab('upload');
    }
  };

  useEffect(() => {
    if (activeTab === 'camera') {
      startCamera();
    } else {
      stopCamera();
    }
    return () => stopCamera();
  }, [activeTab]);

  // Capture photo from video
  const capturePhoto = () => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth || 640;
      canvas.height = videoRef.current.videoHeight || 480;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg');
        setImage(dataUrl);
        analyzeImage(dataUrl);
      }
    }
  };

  // Upload file handler
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const dataUrl = reader.result as string;
        setImage(dataUrl);
        analyzeImage(dataUrl);
      };
      reader.readAsDataURL(file);
    }
  };

  // Simulate AI Scan Analysis
  const analyzeImage = (_dataUrl: string) => {
    setScanning(true);
    setResult(null);

    // Pick a random product from mockDatabase to simulate classification
    const keys = Object.keys(mockDatabase);
    const randomKey = keys[Math.floor(Math.random() * keys.length)];
    const detected = mockDatabase[randomKey];

    setTimeout(() => {
      setScanning(false);
      setResult(detected);
      stopCamera();
    }, 2800); // 2.8 seconds scan animation
  };

  const resetScanner = () => {
    setImage(null);
    setResult(null);
    setScanning(false);
    if (activeTab === 'camera') {
      startCamera();
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-4 md:p-6 rounded-2xl glass-panel border border-slate-200/50 dark:border-slate-800/50 shadow-lg">
      <div className="text-center mb-6">
        <h2 className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-eco-600 to-emerald-400 bg-clip-text text-transparent flex items-center justify-center gap-2">
          <Leaf className="w-6 h-6 text-eco-500 animate-pulse" /> AI Eco-Scanner
        </h2>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
          Scan waste items in real-time to identify recyclability, carbon savings, and disposal methods.
        </p>
      </div>

      {/* Tabs */}
      <div className="flex justify-center mb-6 bg-slate-100 dark:bg-brand-cardDark p-1 rounded-full w-fit mx-auto border border-slate-200/30 dark:border-slate-800/30">
        <button
          onClick={() => setActiveTab('camera')}
          className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-semibold transition-all ${
            activeTab === 'camera'
              ? 'bg-eco-500 text-white shadow-sm'
              : 'text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200'
          }`}
        >
          <Camera className="w-3.5 h-3.5" /> Live Camera
        </button>
        <button
          onClick={() => setActiveTab('upload')}
          className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-semibold transition-all ${
            activeTab === 'upload'
              ? 'bg-eco-500 text-white shadow-sm'
              : 'text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200'
          }`}
        >
          <Upload className="w-3.5 h-3.5" /> Upload File
        </button>
      </div>

      <div className="grid md:grid-cols-2 gap-6 items-start">
        {/* Scanner Viewer */}
        <div className="relative aspect-video md:aspect-[4/3] w-full rounded-xl bg-slate-900 overflow-hidden border border-slate-700/50 flex flex-col items-center justify-center">
          <AnimatePresence mode="wait">
            {!image && activeTab === 'camera' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="w-full h-full relative"
              >
                {error ? (
                  <div className="flex flex-col items-center justify-center p-6 text-center text-rose-400 h-full">
                    <ShieldAlert className="w-12 h-12 mb-2 animate-bounce" />
                    <p className="text-sm font-medium">{error}</p>
                  </div>
                ) : (
                  <>
                    <video
                      ref={videoRef}
                      autoPlay
                      playsInline
                      muted
                      className="w-full h-full object-cover"
                    />
                    {/* Bounding box guide corners */}
                    <div className="absolute inset-8 border border-white/20 pointer-events-none rounded-lg flex items-center justify-center">
                      <div className="absolute top-0 left-0 w-6 h-6 border-t-2 border-l-2 border-eco-400" />
                      <div className="absolute top-0 right-0 w-6 h-6 border-t-2 border-r-2 border-eco-400" />
                      <div className="absolute bottom-0 left-0 w-6 h-6 border-b-2 border-l-2 border-eco-400" />
                      <div className="absolute bottom-0 right-0 w-6 h-6 border-b-2 border-r-2 border-eco-400" />
                      <span className="text-[10px] text-white/50 tracking-wider uppercase font-semibold">Center target</span>
                    </div>

                    {/* Scan Button Overlay */}
                    <div className="absolute bottom-4 left-0 right-0 flex justify-center">
                      <button
                        onClick={capturePhoto}
                        id="btn-scan-capture"
                        className="flex items-center gap-2 px-6 py-2.5 rounded-full bg-eco-500 hover:bg-eco-600 text-white font-semibold text-sm shadow-lg hover:shadow-eco-500/20 active:scale-95 transition-all"
                      >
                        <Camera className="w-4 h-4" /> Scan Waste
                      </button>
                    </div>
                  </>
                )}
              </motion.div>
            )}

            {!image && activeTab === 'upload' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => fileInputRef.current?.click()}
                className="w-full h-full border-2 border-dashed border-slate-700/60 flex flex-col items-center justify-center p-6 text-center cursor-pointer hover:bg-slate-800/20 transition-all"
              >
                <Upload className="w-10 h-10 text-slate-500 mb-3" />
                <p className="text-sm font-semibold text-slate-300">Drag & Drop Image Here</p>
                <p className="text-xs text-slate-500 mt-1">Or click to browse from device</p>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  accept="image/*"
                  className="hidden"
                />
              </motion.div>
            )}

            {image && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="w-full h-full relative"
              >
                <img src={image} alt="Target scan" className="w-full h-full object-cover" />

                {/* Animated Scanner Laser Sweep */}
                {scanning && (
                  <motion.div
                    initial={{ y: 0 }}
                    animate={{ y: ['0%', '98%', '0%'] }}
                    transition={{ repeat: Infinity, duration: 2.2, ease: 'linear' }}
                    className="absolute left-0 right-0 h-1 bg-gradient-to-r from-transparent via-eco-400 to-transparent shadow-[0_0_12px_#4ade80] z-20 pointer-events-none"
                  />
                )}

                {/* Bounding box animation */}
                {!scanning && result && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="absolute border-2 border-eco-500 bg-eco-500/10 rounded-md pointer-events-none"
                    style={{
                      left: '20%',
                      top: '20%',
                      width: '60%',
                      height: '60%',
                    }}
                  >
                    <span className="absolute -top-6 left-0 bg-eco-500 text-white font-bold text-xs px-2 py-0.5 rounded shadow-md uppercase">
                      {result.itemName} ({result.confidence}%)
                    </span>
                  </motion.div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Diagnostic Results */}
        <div className="w-full h-full min-h-[280px] flex flex-col justify-center">
          <AnimatePresence mode="wait">
            {scanning && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="flex flex-col items-center justify-center p-8 bg-slate-100/50 dark:bg-brand-cardDark/50 rounded-xl border border-slate-200/20 dark:border-slate-800/20 h-full"
              >
                <RefreshCw className="w-10 h-10 text-eco-500 animate-spin mb-4" />
                <h3 className="font-semibold text-slate-700 dark:text-slate-300">Processing Waste Photo...</h3>
                <p className="text-xs text-slate-400 mt-2 text-center max-w-[250px]">
                  Extracting edge features, texture densities, and matching classification against recycling indices.
                </p>
              </motion.div>
            )}

            {!scanning && !result && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex flex-col items-center justify-center p-8 text-center text-slate-400 bg-slate-100/50 dark:bg-brand-cardDark/50 rounded-xl h-full border border-slate-200/20 dark:border-slate-800/20"
              >
                <Camera className="w-10 h-10 mb-3 text-slate-400/80" />
                <h3 className="font-semibold text-slate-600 dark:text-slate-300">Waiting for Scan</h3>
                <p className="text-xs text-slate-500 max-w-[250px] mt-1.5">
                  Point the target camera at an item (like plastic, cardboard, or fruit) or upload a photo to analyze.
                </p>
              </motion.div>
            )}

            {!scanning && result && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="space-y-4"
              >
                {/* Result header */}
                <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-xl flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-bold text-slate-800 dark:text-slate-100">{result.itemName}</h3>
                      <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-500 text-white uppercase">
                        {result.category}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      Confidence Level: <span className="font-bold text-slate-700 dark:text-slate-300">{result.confidence}%</span>
                    </p>
                  </div>
                </div>

                {/* Details */}
                <div className="space-y-3 p-4 bg-slate-100/60 dark:bg-brand-cardDark/60 rounded-xl border border-slate-200/30 dark:border-slate-800/30 text-sm">
                  <div>
                    <span className="text-xs text-slate-400 block font-semibold uppercase">Environmental Impact</span>
                    <p className="text-slate-700 dark:text-slate-300 font-medium">{result.impact}</p>
                  </div>

                  <div>
                    <span className="text-xs text-slate-400 block font-semibold uppercase">Disposal Instructions</span>
                    <p className="text-slate-700 dark:text-slate-300 font-medium">{result.instructions}</p>
                  </div>

                  <div>
                    <span className="text-xs text-slate-400 block font-semibold uppercase">Nearest Recycling Center</span>
                    <p className="text-slate-700 dark:text-slate-300 font-medium text-xs">{result.center}</p>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-200/50 dark:border-slate-800/50">
                    <span className="text-xs text-slate-400 font-semibold uppercase">Scan Reward</span>
                    <span className="text-xs font-bold text-amber-500 bg-amber-500/10 px-2 py-0.5 rounded-full flex items-center gap-1">
                      💎 +{result.coinsReward} Eco Coins
                    </span>
                  </div>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={resetScanner}
                    id="btn-scan-reset"
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-bold hover:bg-slate-300 dark:hover:bg-slate-700 active:scale-98 transition-all"
                  >
                    <RefreshCw className="w-3.5 h-3.5" /> Scan Another Item
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};
