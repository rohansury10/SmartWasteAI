import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageSquare, X, Send, Leaf, HelpCircle } from 'lucide-react';
interface Message {
  sender: 'bot' | 'user';
  text: string;
  timestamp: string;
}

export const EcoBot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    { sender: 'bot', text: 'Hi! I am EcoBot, your Smart City Waste Assistant. How can I help you recycle today?', timestamp: 'Just now' }
  ]);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const predefinedQuestions = [
    { q: 'How to segregate plastics?', a: 'Plastics should be cleaned of food debris, dried, and placed in the DRY Waste bin. PET bottles and HDPE cartons are 100% recyclable!' },
    { q: 'How do Eco Coins work?', a: 'Every time you schedule a waste pickup and our driver completes it, you receive Eco Coins based on the waste weight and type (e.g., E-waste gives 50 coins/kg!). You can redeem them for brand coupons or plant trees!' },
    { q: 'What is the impact of E-waste?', a: 'E-waste contains hazardous metals like lead and mercury. Proper recycling prevents them from contaminating groundwater, saving up to 80% energy compared to mining fresh minerals!' }
  ];

  const handleSend = (text: string) => {
    if (!text.trim()) return;

    const newMsg: Message = {
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, newMsg]);
    setInput('');

    // Simulated reply based on content keywords
    setTimeout(() => {
      let replyText = "I'm still learning about waste segregation! Try asking me about 'plastics', 'eco coins', or 'e-waste'. Or you can schedule a pickup directly from the Citizen Dashboard!";
      
      const normalized = text.toLowerCase();
      if (normalized.includes('plastic') || normalized.includes('dry')) {
        replyText = "Dry plastics like clean bottles, wrappers, and clean containers belong in the DRY bin. Ensure they are free of food particles before disposal!";
      } else if (normalized.includes('coin') || normalized.includes('reward') || normalized.includes('earn')) {
        replyText = "Earn Eco Coins by scheduling pickups! Plastics give 10 coins/kg, E-Waste gives 50 coins/kg, and Metals give 15 coins/kg. You can check your rewards balance in your Citizen Portal.";
      } else if (normalized.includes('e-waste') || normalized.includes('electronic') || normalized.includes('phone') || normalized.includes('battery')) {
        replyText = "E-waste must never be mixed with wet waste. Schedule a specialized E-Waste pickup on EcoSync, and we will send a dedicated truck to transfer it to a certified recycling center.";
      } else if (normalized.includes('wet') || normalized.includes('organic') || normalized.includes('food')) {
        replyText = "Wet waste includes fruit peels, leftover food, and vegetable scraps. Place them in the WET bin; they are transferred to our composting plant to make high-quality organic fertilizers!";
      } else if (normalized.includes('glass') || normalized.includes('bottle')) {
        replyText = "Glass bottles are 100% recyclable infinitely! Keep them safe from breakage, rinse them, and mark them under Glass pickup for our drivers.";
      }

      setMessages(prev => [...prev, {
        sender: 'bot',
        text: replyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }]);
    }, 1000);
  };

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isOpen]);

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Bot Icon Trigger */}
      <motion.button
        onClick={() => setIsOpen(!isOpen)}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        id="btn-ecobot-toggle"
        className={`w-14 h-14 rounded-full flex items-center justify-center shadow-lg transition-all ${
          isOpen ? 'bg-rose-500 hover:bg-rose-600 text-white' : 'bg-eco-500 hover:bg-eco-600 text-white glow-card-green'
        }`}
      >
        {isOpen ? <X className="w-6 h-6" /> : <MessageSquare className="w-6 h-6" />}
      </motion.button>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.9 }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="absolute bottom-16 right-0 w-80 md:w-96 h-[480px] rounded-2xl shadow-glass glass-panel overflow-hidden flex flex-col z-50 border border-slate-200/50 dark:border-slate-800/50"
          >
            {/* Header */}
            <div className="p-4 bg-gradient-to-r from-eco-600 to-emerald-600 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Leaf className="w-5 h-5 animate-pulse" />
                <div>
                  <h3 className="font-semibold text-sm">EcoBot Assistant</h3>
                  <p className="text-xs text-emerald-100 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 bg-emerald-300 rounded-full animate-ping" /> Online
                  </p>
                </div>
              </div>
            </div>

            {/* Chat Messages */}
            <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-slate-50/50 dark:bg-brand-dark/50">
              {messages.map((msg, i) => (
                <div key={i} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[80%] p-3 rounded-2xl text-sm ${
                    msg.sender === 'user'
                      ? 'bg-eco-600 text-white rounded-br-none'
                      : 'bg-white dark:bg-brand-cardDark text-slate-800 dark:text-slate-100 border border-slate-200/50 dark:border-slate-800/50 rounded-bl-none shadow-sm'
                  }`}>
                    <p>{msg.text}</p>
                    <span className="text-[10px] opacity-75 block text-right mt-1">{msg.timestamp}</span>
                  </div>
                </div>
              ))}
              <div ref={chatEndRef} />
            </div>

            {/* Quick Helper Questions */}
            <div className="px-4 py-2 border-t border-slate-200/30 dark:border-slate-800/30 bg-slate-100/50 dark:bg-brand-cardDark/50 space-y-1.5">
              <p className="text-[10px] text-slate-400 font-medium uppercase tracking-wider flex items-center gap-1">
                <HelpCircle className="w-3.5 h-3.5" /> Quick Inquiries
              </p>
              <div className="flex flex-wrap gap-1">
                {predefinedQuestions.map((item, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setInput(item.q);
                      handleSend(item.q);
                    }}
                    className="text-xs px-2.5 py-1 rounded-full bg-slate-200/60 dark:bg-slate-800/80 hover:bg-eco-50 dark:hover:bg-eco-950 hover:text-eco-600 dark:hover:text-eco-400 text-slate-600 dark:text-slate-300 border border-slate-300/30 dark:border-slate-700/30 transition-all"
                  >
                    {item.q}
                  </button>
                ))}
              </div>
            </div>

            {/* Input Form */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSend(input);
              }}
              className="p-3 border-t border-slate-200/50 dark:border-slate-800/50 bg-white dark:bg-brand-cardDark flex gap-2"
            >
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask EcoBot..."
                className="flex-1 px-4 py-2 text-sm rounded-full bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-700 focus:outline-none focus:border-eco-500"
              />
              <button
                type="submit"
                id="btn-ecobot-send"
                className="p-2 rounded-full bg-eco-500 hover:bg-eco-600 text-white flex items-center justify-center"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
