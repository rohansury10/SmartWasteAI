import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { User, MapPin, Camera, X, Check, Save, Phone, Mail, Sparkles, Building } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const PRESET_AVATARS = [
  { label: 'Aarav (Default)', url: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=150' },
  { label: 'Priya (Volunteer)', url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=150' },
  { label: 'Rajesh (Driver)', url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=150' },
  { label: 'Sunita (Green Activist)', url: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=150' },
  { label: 'Officer Kumar (Municipal)', url: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=150' },
  { label: 'Elena (Recycler)', url: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=150' },
];

const WARD_PRESETS = [
  { ward: 'Ward 1 - VIP Road / Vesu', address: 'A-402 Shanti Niketan Apartments, VIP Road', coords: { lat: 21.1662, lng: 72.7824 } },
  { ward: 'Ward 2 - Adajan', address: 'Rowhouse 18, Star Enclave, Adajan', coords: { lat: 21.1895, lng: 72.7989 } },
  { ward: 'Ward 3 - Varachha', address: 'B-204 Diamond Towers, Varachha Flyover Sector 2', coords: { lat: 21.2112, lng: 72.8422 } },
  { ward: 'Ward 4 - Pal', address: 'Villa 12, Pal RTO Corner & Green Park', coords: { lat: 21.1982, lng: 72.7712 } },
  { ward: 'Ward 5 - Central', address: 'Shop 42, Clock Tower Municipal Market', coords: { lat: 21.1950, lng: 72.8190 } },
];

export const ProfileModal: React.FC<ProfileModalProps> = ({ isOpen, onClose }) => {
  const { user, updateProfile } = useApp();

  const [name, setName] = useState(user.name);
  const [email, setEmail] = useState(user.email || 'citizen@smartwaste.ai');
  const [phone, setPhone] = useState(user.phone || '+91 98765 12345');
  const [avatar, setAvatar] = useState(user.avatar);
  const [ward, setWard] = useState(user.ward);
  const [homeAddress, setHomeAddress] = useState(user.homeAddress);
  const [homeCoords, setHomeCoords] = useState(user.homeCoords);
  const [customAvatarUrl, setCustomAvatarUrl] = useState('');
  const [savedToast, setSavedToast] = useState(false);

  // Sync state when modal opens
  useEffect(() => {
    if (isOpen) {
      setName(user.name);
      setEmail(user.email || 'citizen@smartwaste.ai');
      setPhone(user.phone || '+91 98765 12345');
      setAvatar(user.avatar);
      setWard(user.ward);
      setHomeAddress(user.homeAddress);
      setHomeCoords(user.homeCoords);
    }
  }, [isOpen, user]);

  const handleWardChange = (newWard: string) => {
    setWard(newWard);
    const preset = WARD_PRESETS.find(w => w.ward === newWard);
    if (preset) {
      setHomeCoords(preset.coords);
      if (!homeAddress || homeAddress.includes('Apartments') || homeAddress.includes('Enclave') || homeAddress.includes('Towers')) {
        setHomeAddress(preset.address);
      }
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setAvatar(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({
      name,
      email,
      phone,
      avatar,
      ward,
      homeAddress,
      homeCoords
    });
    setSavedToast(true);
    setTimeout(() => {
      setSavedToast(false);
      onClose();
    }, 900);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
          <motion.div
            initial={{ scale: 0.95, opacity: 0, y: 10 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.95, opacity: 0, y: 10 }}
            className="bg-white dark:bg-brand-cardDark max-w-xl w-full rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-6 relative"
          >
            {/* Header */}
            <div className="flex justify-between items-center pb-4 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 text-emerald-600 flex items-center justify-center text-lg font-black">
                  👤
                </div>
                <div>
                  <h3 className="font-black text-lg text-slate-900 dark:text-white">Edit Your Profile</h3>
                  <p className="text-xs text-slate-400">Update your avatar, residential address, and municipal ward.</p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-2 rounded-xl text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Avatar Section */}
              <div className="space-y-3">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                  Profile Photo & Avatar
                </label>
                <div className="flex items-center gap-4">
                  <img
                    src={avatar}
                    alt={name}
                    className="w-16 h-16 rounded-full object-cover border-2 border-emerald-500 shadow-md shrink-0"
                  />
                  <div className="space-y-1.5 flex-1">
                    <div className="flex flex-wrap gap-1.5">
                      {PRESET_AVATARS.map((preset, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => setAvatar(preset.url)}
                          className={`w-8 h-8 rounded-full overflow-hidden border-2 transition-transform ${
                            avatar === preset.url ? 'border-emerald-500 scale-110' : 'border-transparent opacity-70 hover:opacity-100'
                          }`}
                          title={preset.label}
                        >
                          <img src={preset.url} alt={preset.label} className="w-full h-full object-cover" />
                        </button>
                      ))}
                    </div>

                    <div className="flex items-center gap-2 pt-1">
                      <label className="cursor-pointer px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-[11px] font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                        <Camera className="w-3.5 h-3.5" /> Upload from Computer
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleFileUpload}
                          className="hidden"
                        />
                      </label>
                      <input
                        type="text"
                        placeholder="or paste Image URL..."
                        value={customAvatarUrl}
                        onChange={(e) => {
                          setCustomAvatarUrl(e.target.value);
                          if (e.target.value.startsWith('http')) {
                            setAvatar(e.target.value);
                          }
                        }}
                        className="text-xs px-2.5 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 border-none flex-1"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Personal Details */}
              <div className="grid sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    Full Name
                  </label>
                  <div className="relative">
                    <User className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border-none font-bold text-slate-800 dark:text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    Phone Number
                  </label>
                  <div className="relative">
                    <Phone className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input
                      type="text"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border-none font-semibold text-slate-800 dark:text-white"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border-none font-semibold text-slate-800 dark:text-white"
                  />
                </div>
              </div>

              {/* Municipal Ward & Address */}
              <div className="space-y-3 pt-2 border-t border-slate-100 dark:border-slate-800">
                <div>
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    Municipal Collection Ward (Determines your truck route & ETA)
                  </label>
                  <div className="relative">
                    <Building className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <select
                      value={ward}
                      onChange={(e) => handleWardChange(e.target.value)}
                      className="w-full pl-9 pr-3 py-2.5 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border-none font-bold text-slate-800 dark:text-white"
                    >
                      {WARD_PRESETS.map((w, idx) => (
                        <option key={idx} value={w.ward}>
                          {w.ward}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    Home Address & Street
                  </label>
                  <div className="relative">
                    <MapPin className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input
                      type="text"
                      required
                      value={homeAddress}
                      onChange={(e) => setHomeAddress(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border-none font-semibold text-slate-800 dark:text-white"
                    />
                  </div>
                  <span className="text-[10px] text-slate-400 block mt-1">
                    📍 GPS Target: {homeCoords.lat.toFixed(4)}, {homeCoords.lng.toFixed(4)}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <div>
                  {savedToast && (
                    <span className="text-xs font-bold text-emerald-600 flex items-center gap-1 animate-bounce">
                      <Check className="w-4 h-4" /> Changes Saved!
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2 rounded-xl text-xs font-bold text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs shadow-md shadow-emerald-600/20 transition-all flex items-center gap-1.5"
                  >
                    <Save className="w-3.5 h-3.5" /> Save Profile
                  </button>
                </div>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
