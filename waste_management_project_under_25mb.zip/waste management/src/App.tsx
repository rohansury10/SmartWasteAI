import React, { useState, useEffect } from 'react';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import { AppProvider, useApp } from './context/AppContext';
import type { UserRole } from './context/AppContext';
import { LandingPage } from './pages/LandingPage';
import { AuthPage } from './pages/AuthPage';
import { CitizenDashboard } from './pages/CitizenDashboard';
import { MunicipalDashboard } from './pages/MunicipalDashboard';
import { DriverDashboard } from './pages/DriverDashboard';
import { RecyclerDashboard } from './pages/RecyclerDashboard';
import { NGOPortal } from './pages/NGOPortal';
import { AdminPanel } from './pages/AdminPanel';
import { EcoBot } from './components/EcoBot';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Sun, Moon, Bell, LogOut, Globe, Heart,
  ChevronRight, Menu, X, Shield
} from 'lucide-react';

const AppContent: React.FC = () => {
  const { currentRole, setCurrentRole, user, notifications, setNotifications } = useApp();
  const { language, setLanguage, t } = useLanguage();

  const [activeView, setActiveView] = useState<'landing' | 'auth' | 'app'>('landing');
  const [darkMode, setDarkMode] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [sidebarTab, setSidebarTab] = useState<'dashboard' | 'ngo'>('dashboard');

  // Sync dark mode class with HTML/body tag
  useEffect(() => {
    const bodyClass = document.body.classList;
    if (darkMode) {
      bodyClass.add('dark');
    } else {
      bodyClass.remove('dark');
    }
  }, [darkMode]);

  const handleLogout = () => {
    setCurrentRole('guest');
    setActiveView('landing');
    setMobileSidebarOpen(false);
  };

  const handleRoleToggle = (role: UserRole) => {
    setCurrentRole(role);
    setMobileSidebarOpen(false);
  };

  // Notification count
  const unreadCount = notifications.filter(n => !n.read).length;

  const handleMarkAllRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  // Map sidebar links depending on role
  const getSidebarTitle = () => {
    if (currentRole === 'citizen') return 'Citizen Live Tracker';
    if (currentRole === 'driver') return 'Driver Turn-by-Turn';
    if (currentRole === 'municipality') return 'Municipal Fleet Center';
    if (currentRole === 'recycler') return 'Recycle Exchange';
    if (currentRole === 'admin') return 'City Admin Dashboard';
    return 'SmartWaste AI';
  };

  return (
    <div className="min-h-screen flex flex-col font-sans transition-colors duration-300 bg-slate-50 dark:bg-brand-dark text-slate-800 dark:text-slate-200">
      {/* GLOBAL HEADER BAR */}
      <header className="sticky top-0 z-40 w-full bg-white/80 dark:bg-brand-dark/80 backdrop-blur-md border-b border-slate-200/60 dark:border-slate-800/60">
        <div className="max-w-7xl mx-auto px-4 md:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {activeView === 'app' && (
              <button
                onClick={() => setMobileSidebarOpen(!mobileSidebarOpen)}
                className="lg:hidden p-2 rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-brand-cardDark"
              >
                <Menu className="w-5 h-5" />
              </button>
            )}

            <div
              className="flex items-center gap-2.5 cursor-pointer"
              onClick={() => {
                if (activeView !== 'app') setActiveView('landing');
              }}
            >
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white text-lg font-black shadow-md shadow-emerald-600/20">
                🚛
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-black text-xl tracking-tight text-slate-900 dark:text-white">
                    SmartWaste
                  </span>
                  <span className="text-[11px] font-black px-1.5 py-0.5 rounded-md bg-emerald-500 text-white shadow-sm">
                    AI
                  </span>
                </div>
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block -mt-1 hidden sm:block">
                  Smart City Fleet Tracking
                </span>
              </div>
            </div>
          </div>

          {/* Center Quick Switchers (When in App View) */}
          {activeView === 'app' && (
            <div className="hidden md:flex items-center gap-1 bg-slate-100 dark:bg-slate-800/60 p-1 rounded-2xl border border-slate-200/50 dark:border-slate-700/50 text-xs">
              <button
                onClick={() => setCurrentRole('citizen')}
                className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
                  currentRole === 'citizen'
                    ? 'bg-white dark:bg-slate-700 text-emerald-600 shadow-sm'
                    : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                }`}
              >
                🏡 Citizen
              </button>
              <button
                onClick={() => setCurrentRole('municipality')}
                className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
                  currentRole === 'municipality'
                    ? 'bg-white dark:bg-slate-700 text-blue-600 shadow-sm'
                    : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                }`}
              >
                🚛 Municipal Fleet
              </button>
              <button
                onClick={() => setCurrentRole('admin')}
                className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
                  currentRole === 'admin'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                }`}
              >
                📊 City Admin
              </button>
            </div>
          )}

          {/* Quick Menu Controls */}
          <div className="flex items-center gap-2.5">
            {/* Language Switcher */}
            <div className="relative group">
              <button
                id="btn-lang-selector"
                className="p-2 rounded-xl text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-brand-cardDark flex items-center gap-1 text-xs font-bold"
              >
                <Globe className="w-4 h-4" />
                <span className="hidden sm:inline uppercase">{language}</span>
              </button>

              <div className="absolute right-0 top-10 hidden group-hover:block bg-white dark:bg-brand-cardDark border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xl p-1.5 w-32 space-y-1 z-50">
                {[
                  { id: 'en', label: 'English' },
                  { id: 'hi', label: 'Hindi' },
                  { id: 'mr', label: 'Marathi' },
                  { id: 'gu', label: 'Gujarati' }
                ].map(lang => (
                  <button
                    key={lang.id}
                    onClick={() => setLanguage(lang.id as any)}
                    className="w-full text-left px-3 py-1.5 rounded-xl text-xs hover:bg-emerald-600 hover:text-white font-semibold transition-all"
                  >
                    {lang.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Dark Mode Toggle */}
            <button
              onClick={() => setDarkMode(!darkMode)}
              id="btn-theme-toggle"
              className="p-2 rounded-xl text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-brand-cardDark transition-colors"
            >
              {darkMode ? <Sun className="w-4 h-4 text-amber-500 animate-spin" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* Notification bell */}
            {activeView === 'app' && (
              <div className="relative">
                <button
                  onClick={() => setNotificationsOpen(!notificationsOpen)}
                  id="btn-notifications"
                  className="p-2 rounded-xl text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-brand-cardDark transition-colors relative"
                >
                  <Bell className="w-4 h-4" />
                  {unreadCount > 0 && (
                    <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
                  )}
                </button>
              </div>
            )}

            {/* Access Buttons for reviewers on Landing Page */}
            {activeView === 'landing' && (
              <button
                onClick={() => setActiveView('auth')}
                id="btn-landing-login"
                className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded-full shadow-md shadow-emerald-600/20 active:scale-95 transition-all ml-2"
              >
                Sign In <ChevronRight className="w-3.5 h-3.5" />
              </button>
            )}

            {/* Profile widget when logged in */}
            {activeView === 'app' && (
              <div className="flex items-center gap-2 border-l border-slate-200/60 dark:border-slate-800/60 pl-3">
                <img
                  src={user.avatar}
                  className="w-8 h-8 rounded-full object-cover border border-slate-300 dark:border-slate-700 shadow-sm"
                  alt={user.name}
                />
                <span className="text-xs font-bold hidden sm:inline">{user.name.split(' ')[0]}</span>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* NOTIFICATIONS DRAWER BAR */}
      <AnimatePresence>
        {notificationsOpen && (
          <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/50 backdrop-blur-sm">
            <div className="absolute inset-y-0 right-0 w-80 md:w-96 flex">
              <motion.div
                initial={{ x: '100%' }}
                animate={{ x: 0 }}
                exit={{ x: '100%' }}
                transition={{ type: 'spring', damping: 25, stiffness: 200 }}
                className="w-full h-full bg-white dark:bg-brand-cardDark border-l border-slate-200/60 dark:border-slate-800/60 shadow-2xl flex flex-col justify-between"
              >
                {/* Header */}
                <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-brand-dark/20">
                  <div className="flex items-center gap-2">
                    <Bell className="w-4 h-4 text-emerald-600" />
                    <h3 className="font-extrabold text-sm">Real-Time Alerts</h3>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleMarkAllRead}
                      className="text-[10px] text-emerald-600 hover:text-emerald-700 font-bold"
                    >
                      Mark Read
                    </button>
                    <button
                      onClick={() => setNotificationsOpen(false)}
                      className="p-1 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Notifications Log */}
                <div className="flex-1 overflow-y-auto p-4 space-y-3">
                  {notifications.length === 0 ? (
                    <div className="text-center text-slate-400 text-xs py-10">
                      No notifications recorded.
                    </div>
                  ) : (
                    notifications.map(notif => (
                      <div
                        key={notif.id}
                        className={`p-3 rounded-2xl border flex items-start gap-2.5 text-xs transition-all ${
                          notif.read
                            ? 'bg-white dark:bg-brand-cardDark border-slate-200/40 dark:border-slate-800/30 opacity-60'
                            : 'bg-emerald-500/5 border-emerald-500/20'
                        }`}
                      >
                        <span className="text-sm shrink-0">
                          {notif.type === 'success' ? '✅' : notif.type === 'alert' ? '🚨' : notif.type === 'warning' ? '⚠️' : 'ℹ️'}
                        </span>
                        <div className="flex-1 space-y-1">
                          <h4 className="font-bold text-slate-800 dark:text-slate-200">{notif.title}</h4>
                          <p className="text-slate-500 dark:text-slate-400 text-[11px] leading-relaxed">
                            {notif.message}
                          </p>
                          <span className="text-[9px] text-slate-400 block mt-1">{notif.time}</span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </motion.div>
            </div>
          </div>
        )}
      </AnimatePresence>

      {/* CORE VIEWPORT LAYOUT */}
      <main className="flex-1 flex flex-col">
        {activeView === 'landing' && (
          <LandingPage
            onGetStarted={() => {
              setCurrentRole('citizen');
              setActiveView('auth');
            }}
            onBookPickup={() => {
              setCurrentRole('citizen');
              setActiveView('auth');
            }}
          />
        )}

        {activeView === 'auth' && (
          <AuthPage onLoginSuccess={() => setActiveView('app')} />
        )}

        {activeView === 'app' && (
          <div className="flex-1 flex flex-col lg:flex-row relative">
            {/* COLLAPSIBLE RESPONSIVE SIDEBAR */}
            <aside
              className={`fixed inset-y-0 left-0 z-30 w-64 bg-white dark:bg-brand-cardDark border-r border-slate-200/60 dark:border-slate-800/60 p-4 transform ${
                mobileSidebarOpen ? 'translate-x-0' : '-translate-x-0 lg:translate-x-0'
              } transition-transform duration-300 lg:static lg:block shrink-0 shadow-sm flex flex-col justify-between`}
            >
              <div className="space-y-6">
                {/* Profile Widget details */}
                <div className="p-3 bg-slate-100/60 dark:bg-slate-800/40 rounded-2xl border border-slate-200/50 dark:border-slate-800/30 flex items-center gap-3">
                  <img
                    src={user.avatar}
                    className="w-10 h-10 rounded-full object-cover border border-white shadow-sm"
                    alt={user.name}
                  />
                  <div>
                    <h4 className="font-bold text-xs line-clamp-1">{user.name}</h4>
                    <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-extrabold uppercase">
                      {getSidebarTitle()}
                    </span>
                  </div>
                </div>

                {/* Main Navigation links */}
                <div className="space-y-1">
                  <span className="text-[10px] text-slate-400 font-bold block mb-2 uppercase tracking-widest">
                    SmartWaste Modules
                  </span>

                  <button
                    onClick={() => {
                      setSidebarTab('dashboard');
                      setMobileSidebarOpen(false);
                    }}
                    className={`w-full flex items-center gap-2 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
                      sidebarTab === 'dashboard'
                        ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                        : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/60'
                    }`}
                  >
                    🚛 {getSidebarTitle()}
                  </button>

                  <button
                    onClick={() => {
                      setSidebarTab('ngo');
                      setMobileSidebarOpen(false);
                    }}
                    className={`w-full flex items-center gap-2 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${
                      sidebarTab === 'ngo'
                        ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                        : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/60'
                    }`}
                  >
                    <Heart className="w-4 h-4 text-rose-500" /> Public Clean Drives
                  </button>
                </div>

                {/* ROLE SWITCHER FOR TESTING DEMO */}
                <div className="space-y-2 pt-4 border-t border-slate-100 dark:border-slate-800">
                  <span className="text-[10px] text-slate-400 font-bold block uppercase tracking-widest flex items-center gap-1">
                    <Shield className="w-3.5 h-3.5 text-blue-500" /> Portal Role Selector
                  </span>
                  <div className="grid grid-cols-2 gap-1.5 bg-slate-50 dark:bg-slate-900/50 p-1.5 rounded-2xl border border-slate-200/50 dark:border-slate-800/40">
                    {[
                      { id: 'citizen', label: 'Citizen', icon: '🏡' },
                      { id: 'municipality', label: 'Municipal', icon: '🚛' },
                      { id: 'admin', label: 'Admin', icon: '📊' },
                      { id: 'driver', label: 'Driver', icon: '🧭' },
                      { id: 'recycler', label: 'Recycler', icon: '♻️' }
                    ].map(role => (
                      <button
                        key={role.id}
                        onClick={() => handleRoleToggle(role.id as UserRole)}
                        className={`py-2 px-2 rounded-xl text-[10px] font-black text-center transition-all flex items-center justify-center gap-1 ${
                          currentRole === role.id
                            ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/25'
                            : 'text-slate-500 dark:text-slate-400 hover:bg-slate-200/60 dark:hover:bg-slate-800/40'
                        }`}
                      >
                        <span>{role.icon}</span>
                        <span>{role.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Logout Button */}
              <button
                onClick={handleLogout}
                id="btn-sidebar-logout"
                className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl text-xs font-bold text-rose-500 hover:bg-rose-500/10 transition-all mt-6"
              >
                <LogOut className="w-4 h-4" />
                {t('logout')}
              </button>
            </aside>

            {/* Main Interactive Portals Content */}
            <section className="flex-1 min-w-0 overflow-y-auto bg-slate-50/50 dark:bg-brand-dark/20 p-4 md:p-6 pb-20 relative z-10">
              <AnimatePresence mode="wait">
                {sidebarTab === 'ngo' ? (
                  <NGOPortal key="ngo-portal" />
                ) : (
                  <>
                    {currentRole === 'citizen' && <CitizenDashboard key="citizen" />}
                    {currentRole === 'municipality' && <MunicipalDashboard key="municipality" />}
                    {currentRole === 'driver' && <DriverDashboard key="driver" />}
                    {currentRole === 'recycler' && <RecyclerDashboard key="recycler" />}
                    {currentRole === 'admin' && <AdminPanel key="admin" />}
                  </>
                )}
              </AnimatePresence>
            </section>
          </div>
        )}
      </main>

      {/* FLOATING ECOBOT CHATBOT */}
      <EcoBot />
    </div>
  );
};

export const App: React.FC = () => {
  return (
    <LanguageProvider>
      <AppProvider>
        <AppContent />
      </AppProvider>
    </LanguageProvider>
  );
};

export default App;
