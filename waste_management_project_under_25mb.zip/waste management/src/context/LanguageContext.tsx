import React, { createContext, useContext, useState } from 'react';

type Language = 'en' | 'hi' | 'mr' | 'gu';

const translations: Record<Language, Record<string, string>> = {
  en: {
    heroTitle: "Transforming Waste Into a Smarter Future.",
    heroSubtitle: "AI-powered waste collection, segregation, recycling, and live tracking platform for smart cities.",
    getStarted: "Get Started",
    bookPickup: "Book Pickup",
    watchDemo: "Watch Demo",
    dashboard: "Dashboard",
    liveTracking: "Live Tracking",
    smartBins: "Smart Bins",
    marketplace: "Scrap Marketplace",
    ngoPortal: "NGO Portal",
    adminPanel: "Admin Panel",
    aiScanner: "AI Scanner",
    illegalDumping: "Report Dumping",
    ecoCoins: "Eco Reward Coins",
    carbonSaved: "Carbon Saved",
    notifications: "Notifications",
    logout: "Log Out",
    welcome: "Welcome back",
  },
  hi: {
    heroTitle: "कचरे को एक स्मार्ट भविष्य में बदलना।",
    heroSubtitle: "स्मार्ट शहरों के लिए एआई-संचालित कचरा संग्रह, पृथक्करण, पुनर्चक्रण और लाइव ट्रैकिंग प्लेटफॉर्म।",
    getStarted: "शुरू करें",
    bookPickup: "पिकअप बुक करें",
    watchDemo: "डेमो देखें",
    dashboard: "डैशबोर्ड",
    liveTracking: "लाइव ट्रैकिंग",
    smartBins: "स्मार्ट डिब्बे",
    marketplace: "स्क्रैप मार्केट",
    ngoPortal: "एनजीओ पोर्टल",
    adminPanel: "एडमिन पैनल",
    aiScanner: "एआई स्कैनर",
    illegalDumping: "कचरा रिपोर्ट करें",
    ecoCoins: "इको रिवॉर्ड कॉइन्स",
    carbonSaved: "बचाया गया कार्बन",
    notifications: "सूचनाएं",
    logout: "लॉग आउट",
    welcome: "आपका स्वागत है",
  },
  mr: {
    heroTitle: "कचऱ्याचे स्मार्ट भविष्यात रूपांतर करणे.",
    heroSubtitle: "स्मार्ट शहरांसाठी एआय-आधारित कचरा गोळा करणे, वर्गीकरण, पुनर्वापर आणि थेट ट्रॅकिंग प्लॅटफॉर्म.",
    getStarted: "सुरू करा",
    bookPickup: "पिकअप बुक करा",
    watchDemo: "डेमो पहा",
    dashboard: "डॅशबोर्ड",
    liveTracking: "थेट ट्रॅकिंग",
    smartBins: "स्मार्ट डबे",
    marketplace: "भंगार बाजार",
    ngoPortal: "एनजीओ पोर्टल",
    adminPanel: "अॅडमीन पॅनेल",
    aiScanner: "एआय स्कॅनर",
    illegalDumping: "कचरा नोंदवा",
    ecoCoins: "इको रिवॉर्ड कॉइन्स",
    carbonSaved: "कार्बन वाचवला",
    notifications: "सूचना",
    logout: "बाहेर पडा",
    welcome: "पुन्हा स्वागत आहे",
  },
  gu: {
    heroTitle: "કચરાને સ્માર્ટ ભવિષ્યમાં રૂપાંતરિત કરવું.",
    heroSubtitle: "સ્માર્ટ શહેરો માટે એઆઈ-સંચાલિત કચરો સંગ્રહ, વર્ગીકરણ, રિસાયક્લિંગ અને લાઇવ ટ્રેકિંગ પ્લેટફોર્મ.",
    getStarted: "શરૂ કરો",
    bookPickup: "પિકઅપ બુક કરો",
    watchDemo: "ડેમો જુઓ",
    dashboard: "ડેશબોર્ડ",
    liveTracking: "લાઇવ ટ્રેકિંગ",
    smartBins: "સ્માર્ટ ડબ્બા",
    marketplace: "સ્ક્રેપ માર્કેટ",
    ngoPortal: "એનજીઓ પોર્ટલ",
    adminPanel: "એડમિન પેનલ",
    aiScanner: "એઆઈ સ્કેનર",
    illegalDumping: "કચરો રિપોર્ટ કરો",
    ecoCoins: "ઇકો કોઈન્સ",
    carbonSaved: "બચેલો કાર્બન",
    notifications: "સૂચનાઓ",
    logout: "લૉગ આઉટ",
    welcome: "સ્વાગત છે",
  }
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: string): string => {
    return translations[language][key] || translations['en'][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
