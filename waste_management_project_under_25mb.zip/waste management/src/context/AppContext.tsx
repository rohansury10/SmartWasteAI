import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { playProximityChime, playSuccessChime } from '../utils/audioAlert';

export type UserRole = 'citizen' | 'driver' | 'recycler' | 'municipality' | 'admin' | 'guest';

export interface UserProfile {
  name: string;
  role: UserRole;
  email?: string;
  phone?: string;
  ecoCoins: number;
  carbonSaved: number; // in kg CO2
  avatar: string;
  ward: string;
  homeAddress: string;
  homeCoords: { lat: number; lng: number };
}

export interface PickupRequest {
  id: string;
  citizenName: string;
  type: 'Plastic' | 'Glass' | 'Metal' | 'Organic' | 'E-Waste' | 'Medical' | 'Mixed';
  weight: number; // in kg
  status: 'Pending' | 'Assigned' | 'Collected' | 'Transfer Station' | 'Segregating' | 'Recycling' | 'Recycled';
  date: string;
  timeSlot: string;
  address: string;
  lat: number;
  lng: number;
  photoUrl?: string;
  driverId?: string;
  ecoCoinsEarned: number;
}

export interface SmartBin {
  id: string;
  zone: string;
  address: string;
  lat: number;
  lng: number;
  fillPercentage: number;
  temperature: number;
  humidity: number;
  methane: number; // ppm
  battery: number;
  status: 'Normal' | 'Warning' | 'Critical';
  lastEmptied: string;
}

export interface GarbageTruck {
  id: string;
  driverName: string;
  phone: string;
  licensePlate: string;
  ward: string;
  lat: number;
  lng: number;
  speed: number;
  heading: number; // in degrees 0-360
  capacity: number; // current filled %
  fuelType: 'Electric' | 'CNG' | 'Diesel';
  fuelLevel: number; // %
  status: 'Collecting' | 'In Transit' | 'Transfer Station' | 'Maintenance';
  eta: string;
  distanceTraveledKm: number;
  fuelSavedLiters: number;
  co2SavedKg: number;
  currentStopIndex: number;
  routeStops: { name: string; lat: number; lng: number; completed: boolean }[];
  routePath: [number, number][]; // GPS Polyline
}

export interface MissedPickupIncident {
  id: string;
  citizenName: string;
  address: string;
  ward: string;
  lat: number;
  lng: number;
  wasteType: string;
  reportedAt: string;
  reason: string;
  photoUrl?: string;
  status: 'Reported' | 'Dispatched' | 'Resolved';
  assignedTruckId?: string;
  slaMinutes: number;
  notes?: string;
}

export interface PickupScheduleItem {
  id: string;
  ward: string;
  zoneName: string;
  wasteCategory: 'Organic / Wet' | 'Dry Recyclables' | 'E-Waste & Bulky' | 'Hazardous / Medical';
  days: string[];
  timeWindow: string;
  assignedTruckId: string;
  truckPlate: string;
  frequency: 'Daily' | 'Alternate Days' | 'Weekly';
  status: 'On Schedule' | 'In Progress' | 'Completed';
}

export interface ScrapListing {
  id: string;
  sellerName: string;
  type: string;
  quantity: string;
  basePrice: number;
  currentBid: number;
  highestBidder?: string;
  bidsCount: number;
  image: string;
  status: 'Available' | 'Sold';
}

export interface DumpReport {
  id: string;
  reporter: string;
  category: string;
  lat: number;
  lng: number;
  address: string;
  photoUrl?: string;
  description: string;
  priority: 'Low' | 'Medium' | 'High';
  status: 'Reported' | 'Investigating' | 'Cleared';
  date: string;
}

export interface NGOCampaign {
  id: string;
  title: string;
  organizer: string;
  date: string;
  location: string;
  volunteersJoined: number;
  targetVolunteers: number;
  donationsRaised: number;
  status: 'Upcoming' | 'Completed';
  description: string;
}

export interface NotificationLog {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'alert';
  time: string;
  read: boolean;
}

export interface WardCoverage {
  ward: string;
  percent: number;
  totalBins: number;
  servicedBins: number;
  status: 'Optimal' | 'In Progress' | 'Action Needed';
}

interface AppContextType {
  user: UserProfile;
  setUser: React.Dispatch<React.SetStateAction<UserProfile>>;
  currentRole: UserRole;
  setCurrentRole: (role: UserRole) => void;
  pickups: PickupRequest[];
  setPickups: React.Dispatch<React.SetStateAction<PickupRequest[]>>;
  smartBins: SmartBin[];
  setSmartBins: React.Dispatch<React.SetStateAction<SmartBin[]>>;
  trucks: GarbageTruck[];
  setTrucks: React.Dispatch<React.SetStateAction<GarbageTruck[]>>;
  missedPickups: MissedPickupIncident[];
  setMissedPickups: React.Dispatch<React.SetStateAction<MissedPickupIncident[]>>;
  schedules: PickupScheduleItem[];
  setSchedules: React.Dispatch<React.SetStateAction<PickupScheduleItem[]>>;
  listings: ScrapListing[];
  setListings: React.Dispatch<React.SetStateAction<ScrapListing[]>>;
  dumpReports: DumpReport[];
  setDumpReports: React.Dispatch<React.SetStateAction<DumpReport[]>>;
  campaigns: NGOCampaign[];
  setCampaigns: React.Dispatch<React.SetStateAction<NGOCampaign[]>>;
  notifications: NotificationLog[];
  setNotifications: React.Dispatch<React.SetStateAction<NotificationLog[]>>;
  addNotification: (title: string, message: string, type: NotificationLog['type']) => void;
  schedulePickup: (pickup: Omit<PickupRequest, 'id' | 'status' | 'citizenName' | 'ecoCoinsEarned'>) => void;
  reportMissedPickup: (incident: Omit<MissedPickupIncident, 'id' | 'status' | 'reportedAt' | 'slaMinutes'>) => void;
  autoDispatchTruckToMissedPickup: (incidentId: string) => void;
  resolveMissedPickup: (incidentId: string) => void;
  reportDumping: (report: Omit<DumpReport, 'id' | 'status' | 'date' | 'reporter'>) => void;
  placeBid: (listingId: string, bidAmount: number, bidderName: string) => boolean;
  joinCampaign: (campaignId: string) => void;
  assignTruckToPickup: (pickupId: string, truckId: string) => void;
  completeDriverPickup: (pickupId: string) => void;
  triggerRouteOptimization: () => void;
  emptyBin: (binId: string) => void;
  isSimulating: boolean;
  setIsSimulating: React.Dispatch<React.SetStateAction<boolean>>;
  simulationSpeed: number;
  setSimulationSpeed: (speed: number) => void;
  wardCoverageList: WardCoverage[];
  cityWideCoverageScore: number;
  proximityAlertEnabled: boolean;
  setProximityAlertEnabled: (enabled: boolean) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// Initial IoT Smart Bins
const initialBins: SmartBin[] = [
  { id: 'BIN-001', zone: 'Ward 1 - VIP Road', address: 'VIP Road Opp. Central Mall', lat: 21.1642, lng: 72.7844, fillPercentage: 84, temperature: 34, humidity: 45, methane: 32, battery: 92, status: 'Warning', lastEmptied: '2026-07-11 08:30 AM' },
  { id: 'BIN-002', zone: 'Ward 2 - Adajan', address: 'Adajan Star Bazaar Circle', lat: 21.1895, lng: 72.7989, fillPercentage: 96, temperature: 42, humidity: 55, methane: 72, battery: 45, status: 'Critical', lastEmptied: '2026-07-11 09:15 AM' },
  { id: 'BIN-003', zone: 'Ward 1 - Vesu', address: 'Vesu SD Jain Circle', lat: 21.1415, lng: 72.7752, fillPercentage: 38, temperature: 28, humidity: 40, methane: 14, battery: 88, status: 'Normal', lastEmptied: '2026-07-12 10:00 AM' },
  { id: 'BIN-004', zone: 'Ward 3 - Varachha', address: 'Varachha Flyover Sector 2', lat: 21.2112, lng: 72.8422, fillPercentage: 91, temperature: 38, humidity: 50, methane: 58, battery: 74, status: 'Critical', lastEmptied: '2026-07-11 11:20 AM' },
  { id: 'BIN-005', zone: 'Ward 4 - Pal', address: 'Pal RTO Corner & Green Park', lat: 21.1982, lng: 72.7712, fillPercentage: 42, temperature: 26, humidity: 38, methane: 8, battery: 95, status: 'Normal', lastEmptied: '2026-07-12 02:45 PM' },
  { id: 'BIN-006', zone: 'Ward 5 - Central', address: 'Clock Tower Municipal Market', lat: 21.1950, lng: 72.8190, fillPercentage: 78, temperature: 31, humidity: 48, methane: 24, battery: 81, status: 'Warning', lastEmptied: '2026-07-12 01:10 PM' }
];

// Initial Smart Waste Garbage Trucks with detailed GPS waypoints & telemetry
const initialTrucks: GarbageTruck[] = [
  {
    id: 'TRK-901',
    driverName: 'Rajesh Sharma',
    phone: '+91 98765 43210',
    licensePlate: 'GJ-05-SW-9011',
    ward: 'Ward 1 - VIP Road / Vesu',
    lat: 21.1685,
    lng: 72.7885,
    speed: 32,
    heading: 140,
    capacity: 68,
    fuelType: 'Electric',
    fuelLevel: 82,
    status: 'Collecting',
    eta: '4 mins',
    distanceTraveledKm: 18.4,
    fuelSavedLiters: 14.2,
    co2SavedKg: 36.8,
    currentStopIndex: 0,
    routeStops: [
      { name: 'VIP Road Opp. Central Mall', lat: 21.1642, lng: 72.7844, completed: false },
      { name: 'Shanti Niketan Residency Curb', lat: 21.1662, lng: 72.7824, completed: false },
      { name: 'Vesu SD Jain Circle Hub', lat: 21.1415, lng: 72.7752, completed: false },
      { name: 'Vesu Primary Eco Transfer Unit', lat: 21.1350, lng: 72.7710, completed: false }
    ],
    routePath: [
      [21.1710, 72.7930],
      [21.1685, 72.7885],
      [21.1662, 72.7824],
      [21.1642, 72.7844],
      [21.1550, 72.7800],
      [21.1415, 72.7752],
      [21.1350, 72.7710]
    ]
  },
  {
    id: 'TRK-902',
    driverName: 'Vikram Singh',
    phone: '+91 94234 56789',
    licensePlate: 'GJ-05-SW-9024',
    ward: 'Ward 2 - Adajan',
    lat: 21.1960,
    lng: 72.8090,
    speed: 28,
    heading: 260,
    capacity: 88,
    fuelType: 'CNG',
    fuelLevel: 61,
    status: 'Collecting',
    eta: '8 mins',
    distanceTraveledKm: 24.1,
    fuelSavedLiters: 18.5,
    co2SavedKg: 44.2,
    currentStopIndex: 1,
    routeStops: [
      { name: 'Adajan Star Bazaar Circle', lat: 21.1895, lng: 72.7989, completed: false },
      { name: 'Gujarat Gas Circle Stand', lat: 21.1920, lng: 72.8020, completed: true },
      { name: 'Anand Mahal Road Crossing', lat: 21.1990, lng: 72.8120, completed: false },
      { name: 'Pal-Adajan Waste MRF Station', lat: 21.2020, lng: 72.7850, completed: false }
    ],
    routePath: [
      [21.1920, 72.8020],
      [21.1960, 72.8090],
      [21.1990, 72.8120],
      [21.1895, 72.7989],
      [21.2020, 72.7850]
    ]
  },
  {
    id: 'TRK-903',
    driverName: 'Manoj Parmar',
    phone: '+91 98111 22334',
    licensePlate: 'GJ-05-SW-9038',
    ward: 'Ward 3 - Varachha',
    lat: 21.2150,
    lng: 72.8480,
    speed: 36,
    heading: 45,
    capacity: 45,
    fuelType: 'Electric',
    fuelLevel: 91,
    status: 'Collecting',
    eta: '12 mins',
    distanceTraveledKm: 14.7,
    fuelSavedLiters: 11.8,
    co2SavedKg: 28.5,
    currentStopIndex: 0,
    routeStops: [
      { name: 'Varachha Flyover Sector 2', lat: 21.2112, lng: 72.8422, completed: false },
      { name: 'Hirabaug Commercial Complex', lat: 21.2190, lng: 72.8530, completed: false },
      { name: 'Mini Bazaar Diamond Hub', lat: 21.2240, lng: 72.8590, completed: false }
    ],
    routePath: [
      [21.2090, 72.8390],
      [21.2150, 72.8480],
      [21.2190, 72.8530],
      [21.2240, 72.8590]
    ]
  },
  {
    id: 'TRK-904',
    driverName: 'Sunil Jadhav',
    phone: '+91 99245 67890',
    licensePlate: 'GJ-05-SW-9042',
    ward: 'Ward 4 - Pal / Gaurav Path',
    lat: 21.1940,
    lng: 72.7660,
    speed: 0,
    heading: 0,
    capacity: 94,
    fuelType: 'CNG',
    fuelLevel: 44,
    status: 'Transfer Station',
    eta: 'Offloading',
    distanceTraveledKm: 31.2,
    fuelSavedLiters: 22.0,
    co2SavedKg: 52.4,
    currentStopIndex: 3,
    routeStops: [
      { name: 'Pal RTO Corner & Green Park', lat: 21.1982, lng: 72.7712, completed: true },
      { name: 'Gaurav Path Residential Society', lat: 21.1910, lng: 72.7640, completed: true },
      { name: 'Surat Municipal Solid Waste MRF', lat: 21.1940, lng: 72.7660, completed: false }
    ],
    routePath: [
      [21.1982, 72.7712],
      [21.1910, 72.7640],
      [21.1940, 72.7660]
    ]
  }
];

// Initial Citizen Reported Missed Pickups
const initialMissedPickups: MissedPickupIncident[] = [
  {
    id: 'MIS-401',
    citizenName: 'Devang Joshi',
    address: 'B-104 Krishna Residency, VIP Road, Ward 1',
    ward: 'Ward 1 - VIP Road / Vesu',
    lat: 21.1610,
    lng: 72.7810,
    wasteType: 'Organic / Wet Waste',
    reportedAt: '08:45 AM Today',
    reason: 'Morning truck bypassed lane #4 without sounding bell',
    photoUrl: 'https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?auto=format&fit=crop&q=80&w=300',
    status: 'Reported',
    slaMinutes: 35,
    notes: 'Citizen flagged bin overflowing on porch.'
  },
  {
    id: 'MIS-402',
    citizenName: 'Meera Choksi',
    address: 'Rowhouse 18, Star Enclave, Adajan, Ward 2',
    ward: 'Ward 2 - Adajan',
    lat: 21.1860,
    lng: 72.8010,
    wasteType: 'Dry Recyclables',
    reportedAt: '09:20 AM Today',
    reason: 'Scheduled 9 AM pickup delayed > 2 hours',
    status: 'Dispatched',
    assignedTruckId: 'TRK-902',
    slaMinutes: 12,
    notes: 'TRK-902 rerouted to collect on next immediate turn.'
  }
];

// Initial Ward Weekly Pickup Timetables
const initialSchedules: PickupScheduleItem[] = [
  {
    id: 'SCH-01',
    ward: 'Ward 1 - VIP Road / Vesu',
    zoneName: 'VIP Road & Vesu Sectors',
    wasteCategory: 'Organic / Wet',
    days: ['Mon', 'Wed', 'Fri', 'Sun'],
    timeWindow: '07:00 AM - 09:30 AM',
    assignedTruckId: 'TRK-901',
    truckPlate: 'GJ-05-SW-9011',
    frequency: 'Daily',
    status: 'In Progress'
  },
  {
    id: 'SCH-02',
    ward: 'Ward 1 - VIP Road / Vesu',
    zoneName: 'VIP Road & Vesu Sectors',
    wasteCategory: 'Dry Recyclables',
    days: ['Tue', 'Thu', 'Sat'],
    timeWindow: '10:00 AM - 01:00 PM',
    assignedTruckId: 'TRK-901',
    truckPlate: 'GJ-05-SW-9011',
    frequency: 'Alternate Days',
    status: 'On Schedule'
  },
  {
    id: 'SCH-03',
    ward: 'Ward 2 - Adajan',
    zoneName: 'Adajan & Star Bazaar Zone',
    wasteCategory: 'Organic / Wet',
    days: ['Mon', 'Wed', 'Fri', 'Sun'],
    timeWindow: '07:30 AM - 10:00 AM',
    assignedTruckId: 'TRK-902',
    truckPlate: 'GJ-05-SW-9024',
    frequency: 'Daily',
    status: 'In Progress'
  },
  {
    id: 'SCH-04',
    ward: 'Ward 2 - Adajan',
    zoneName: 'Adajan & Star Bazaar Zone',
    wasteCategory: 'Dry Recyclables',
    days: ['Tue', 'Thu', 'Sat'],
    timeWindow: '11:00 AM - 02:00 PM',
    assignedTruckId: 'TRK-902',
    truckPlate: 'GJ-05-SW-9024',
    frequency: 'Alternate Days',
    status: 'On Schedule'
  },
  {
    id: 'SCH-05',
    ward: 'Ward 3 - Varachha',
    zoneName: 'Varachha Diamond District',
    wasteCategory: 'Organic / Wet',
    days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
    timeWindow: '06:30 AM - 09:00 AM',
    assignedTruckId: 'TRK-903',
    truckPlate: 'GJ-05-SW-9038',
    frequency: 'Daily',
    status: 'Completed'
  },
  {
    id: 'SCH-06',
    ward: 'Ward 4 - Pal / Gaurav Path',
    zoneName: 'Pal RTO & Riverfront Residences',
    wasteCategory: 'E-Waste & Bulky',
    days: ['Saturday', 'Sunday'],
    timeWindow: '02:00 PM - 05:00 PM',
    assignedTruckId: 'TRK-904',
    truckPlate: 'GJ-05-SW-9042',
    frequency: 'Weekly',
    status: 'On Schedule'
  }
];

const initialWardCoverage: WardCoverage[] = [
  { ward: 'Ward 1 - VIP Road / Vesu', percent: 96.2, totalBins: 48, servicedBins: 46, status: 'Optimal' },
  { ward: 'Ward 2 - Adajan', percent: 91.5, totalBins: 56, servicedBins: 51, status: 'In Progress' },
  { ward: 'Ward 3 - Varachha', percent: 84.0, totalBins: 62, servicedBins: 52, status: 'Action Needed' },
  { ward: 'Ward 4 - Pal', percent: 94.8, totalBins: 38, servicedBins: 36, status: 'Optimal' },
  { ward: 'Ward 5 - Central', percent: 97.0, totalBins: 42, servicedBins: 41, status: 'Optimal' }
];

const initialListings: ScrapListing[] = [
  { id: 'LST-001', sellerName: 'Karan Malhotra', type: 'Plastics (PET Bottles)', quantity: '250 kg', basePrice: 1200, currentBid: 1450, highestBidder: 'Metrogreen Recyclers', bidsCount: 4, image: 'https://images.unsplash.com/photo-1530587191325-3db32d826c18?auto=format&fit=crop&q=80&w=500', status: 'Available' },
  { id: 'LST-002', sellerName: 'Suman Roy', type: 'Electronic Waste (Motherboards)', quantity: '45 kg', basePrice: 4500, currentBid: 5200, highestBidder: 'E-Waste Solutions', bidsCount: 6, image: 'https://images.unsplash.com/photo-1591405351990-4726e331f141?auto=format&fit=crop&q=80&w=500', status: 'Available' },
  { id: 'LST-003', sellerName: 'Ravi Verma', type: 'Copper & Aluminum Scrap', quantity: '80 kg', basePrice: 8000, currentBid: 8000, bidsCount: 0, image: 'https://images.unsplash.com/photo-1518152006812-cdab29b069a8?auto=format&fit=crop&q=80&w=500', status: 'Available' },
  { id: 'LST-004', sellerName: 'Green Meadows Society', type: 'Cardboard & Paper Scrap', quantity: '400 kg', basePrice: 2000, currentBid: 2400, highestBidder: 'Pulp & Paper Co.', bidsCount: 3, image: 'https://images.unsplash.com/photo-1595079676339-1534801ad6cf?auto=format&fit=crop&q=80&w=500', status: 'Available' }
];

const initialPickups: PickupRequest[] = [
  { id: 'PKP-101', citizenName: 'Aarav Patel', type: 'Plastic', weight: 12.5, status: 'Segregating', date: '2026-07-12', timeSlot: '10:00 AM - 12:00 PM', address: 'A-402 Shanti Niketan Apartments, VIP Road', lat: 21.1662, lng: 72.7824, ecoCoinsEarned: 125, driverId: 'TRK-901' },
  { id: 'PKP-102', citizenName: 'Aarav Patel', type: 'E-Waste', weight: 4.2, status: 'Pending', date: '2026-07-13', timeSlot: '02:00 PM - 04:00 PM', address: 'A-402 Shanti Niketan Apartments, VIP Road', lat: 21.1662, lng: 72.7824, ecoCoinsEarned: 210 }
];

const initialCampaigns: NGOCampaign[] = [
  { id: 'NGO-001', title: 'Dumas Beach Cleanup Drive', organizer: 'Green Life Foundation', date: '2026-07-19', location: 'Dumas Beach, Surat', volunteersJoined: 142, targetVolunteers: 200, donationsRaised: 18500, status: 'Upcoming', description: 'Help us clear marine debris and plastic trash along the famous Dumas beachline. T-shirts, gloves, and refreshments provided!' },
  { id: 'NGO-002', title: 'Tapi River Bank Afforestation', organizer: 'Nature Care NGO', date: '2026-07-26', location: 'Tapi Riverfront Zone', volunteersJoined: 88, targetVolunteers: 150, donationsRaised: 32000, status: 'Upcoming', description: 'Planting 500 indigenous saplings along the Tapi river bed to improve soil retention and biodiversity.' }
];

const initialComplaints: DumpReport[] = [
  { id: 'DMP-301', reporter: 'Nisha Mehta', category: 'Construction Debris', lat: 21.1824, lng: 72.7915, address: 'Near Adajan Lake Garden', description: 'Truckload of concrete blocks dumped on the pedestrian walkway.', priority: 'High', status: 'Investigating', date: '2026-07-12' },
  { id: 'DMP-302', reporter: 'Anonymous', category: 'E-Waste / Hazardous', lat: 21.2082, lng: 72.8250, address: 'Varachha Sector 4 Alleyway', description: 'Old TV sets and acid containers leaking fluid behind industrial units.', priority: 'High', status: 'Reported', date: '2026-07-11' }
];

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentRole, setCurrentRole] = useState<UserRole>('guest');
  const [user, setUser] = useState<UserProfile>({
    name: 'Aarav Patel',
    role: 'citizen',
    ecoCoins: 420,
    carbonSaved: 54.8,
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=150',
    ward: 'Ward 1 - VIP Road / Vesu',
    homeAddress: 'A-402 Shanti Niketan Apartments, VIP Road',
    homeCoords: { lat: 21.1662, lng: 72.7824 }
  });

  const [pickups, setPickups] = useState<PickupRequest[]>(initialPickups);
  const [smartBins, setSmartBins] = useState<SmartBin[]>(initialBins);
  const [trucks, setTrucks] = useState<GarbageTruck[]>(initialTrucks);
  const [missedPickups, setMissedPickups] = useState<MissedPickupIncident[]>(initialMissedPickups);
  const [schedules, setSchedules] = useState<PickupScheduleItem[]>(initialSchedules);
  const [wardCoverageList, setWardCoverageList] = useState<WardCoverage[]>(initialWardCoverage);
  const [listings, setListings] = useState<ScrapListing[]>(initialListings);
  const [dumpReports, setDumpReports] = useState<DumpReport[]>(initialComplaints);
  const [campaigns, setCampaigns] = useState<NGOCampaign[]>(initialCampaigns);
  const [notifications, setNotifications] = useState<NotificationLog[]>([]);

  // Real-time simulation settings
  const [isSimulating, setIsSimulating] = useState<boolean>(true);
  const [simulationSpeed, setSimulationSpeed] = useState<number>(1);
  const [proximityAlertEnabled, setProximityAlertEnabled] = useState<boolean>(true);

  // Proximity alert latch to prevent chime spamming
  const proximityAlertFiredRef = useRef<boolean>(false);

  // Calculate city-wide coverage score
  const cityWideCoverageScore = Number(
    (wardCoverageList.reduce((acc, curr) => acc + curr.percent, 0) / wardCoverageList.length).toFixed(1)
  );

  // Helper to add notification
  const addNotification = (title: string, message: string, type: NotificationLog['type']) => {
    const newNotif: NotificationLog = {
      id: `NTF-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      title,
      message,
      type,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      read: false
    };
    setNotifications(prev => [newNotif, ...prev]);
  };

  // Default welcome notification
  useEffect(() => {
    addNotification(
      'SmartWaste AI Active',
      'Real-time municipal fleet tracking, IoT bin alerts, and dynamic schedule monitoring initialized.',
      'info'
    );
  }, []);

  // Citizen schedules an on-demand pickup
  const schedulePickup = (pickupData: Omit<PickupRequest, 'id' | 'status' | 'citizenName' | 'ecoCoinsEarned'>) => {
    const rewardRate = { Plastic: 10, Glass: 8, Metal: 15, Organic: 5, 'E-Waste': 50, Medical: 20, Mixed: 4 };
    const coins = Math.round(pickupData.weight * (rewardRate[pickupData.type] || 5));
    const newPickup: PickupRequest = {
      ...pickupData,
      id: `PKP-${100 + pickups.length + 1}`,
      citizenName: user.name,
      status: 'Pending',
      ecoCoinsEarned: coins
    };

    setPickups(prev => [newPickup, ...prev]);
    addNotification('On-Demand Pickup Booked', `Your ${pickupData.type} collection has been scheduled.`, 'success');

    // Auto-assign to nearest truck in citizen's ward
    setTimeout(() => {
      const assignedTruckId = 'TRK-901';
      setPickups(prev => prev.map(p => {
        if (p.id === newPickup.id) {
          return { ...p, status: 'Assigned', driverId: assignedTruckId };
        }
        return p;
      }));

      setTrucks(tList => tList.map(t => {
        if (t.id === assignedTruckId) {
          return {
            ...t,
            routeStops: [...t.routeStops, { name: `${newPickup.address} (${newPickup.type})`, lat: newPickup.lat, lng: newPickup.lng, completed: false }]
          };
        }
        return t;
      }));

      addNotification('Driver Dispatched', `Truck TRK-901 added ${newPickup.address} to its active pickup route.`, 'info');
      playSuccessChime();
    }, 2500);
  };

  // Citizen reports a missed pickup
  const reportMissedPickup = (incidentData: Omit<MissedPickupIncident, 'id' | 'status' | 'reportedAt' | 'slaMinutes'>) => {
    const newIncident: MissedPickupIncident = {
      ...incidentData,
      id: `MIS-${400 + missedPickups.length + 1}`,
      reportedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' Today',
      status: 'Reported',
      slaMinutes: 45
    };

    setMissedPickups(prev => [newIncident, ...prev]);
    addNotification(
      'Missed Pickup Incident Logged',
      `Ticket ${newIncident.id} created for ${incidentData.address}. City admin notified for recovery dispatch.`,
      'warning'
    );
  };

  // City Admin or Municipality auto-dispatches nearest truck to resolve missed pickup
  const autoDispatchTruckToMissedPickup = (incidentId: string) => {
    const targetIncident = missedPickups.find(m => m.id === incidentId);
    if (!targetIncident) return;

    // Find truck with same ward or lowest capacity
    const selectedTruck = trucks.find(t => t.ward.includes(targetIncident.ward.split(' ')[1] || '')) || trucks[0];

    setMissedPickups(prev => prev.map(m => {
      if (m.id === incidentId) {
        return {
          ...m,
          status: 'Dispatched',
          assignedTruckId: selectedTruck.id,
          slaMinutes: 15,
          notes: `Auto-dispatched ${selectedTruck.id} (${selectedTruck.driverName}) for immediate recovery pickup.`
        };
      }
      return m;
    }));

    // Append stop to truck route
    setTrucks(prev => prev.map(t => {
      if (t.id === selectedTruck.id) {
        return {
          ...t,
          routeStops: [
            ...t.routeStops,
            { name: `[RECOVERY] ${targetIncident.address}`, lat: targetIncident.lat, lng: targetIncident.lng, completed: false }
          ],
          eta: '10 mins'
        };
      }
      return t;
    }));

    addNotification(
      'Missed Pickup Auto-Dispatched',
      `Assigned Truck ${selectedTruck.id} to recover missed pickup at ${targetIncident.address}.`,
      'success'
    );
    playSuccessChime();
  };

  // Mark missed pickup as resolved
  const resolveMissedPickup = (incidentId: string) => {
    setMissedPickups(prev => prev.map(m => {
      if (m.id === incidentId) {
        return { ...m, status: 'Resolved', slaMinutes: 0 };
      }
      return m;
    }));
    addNotification('Missed Pickup Resolved', `Incident ${incidentId} marked as successfully collected.`, 'success');
  };

  // Citizens report illegal dumping
  const reportDumping = (reportData: Omit<DumpReport, 'id' | 'status' | 'date' | 'reporter'>) => {
    const newReport: DumpReport = {
      ...reportData,
      id: `DMP-${300 + dumpReports.length + 1}`,
      reporter: currentRole === 'citizen' ? user.name : 'Anonymous',
      status: 'Reported',
      date: new Date().toISOString().split('T')[0]
    };
    setDumpReports(prev => [newReport, ...prev]);
    addNotification('Dump Reported', 'Municipal squad notified about illegal dumping.', 'warning');
  };

  // Marketplace bid
  const placeBid = (listingId: string, bidAmount: number, bidderName: string): boolean => {
    let success = false;
    setListings(prev => prev.map(l => {
      if (l.id === listingId && bidAmount > l.currentBid) {
        success = true;
        return {
          ...l,
          currentBid: bidAmount,
          highestBidder: bidderName,
          bidsCount: l.bidsCount + 1
        };
      }
      return l;
    }));

    if (success) {
      addNotification('Bid Placed!', `New highest bid of ₹${bidAmount} placed on listing ${listingId}.`, 'success');
    }
    return success;
  };

  // Join Campaign
  const joinCampaign = (campaignId: string) => {
    setCampaigns(prev => prev.map(c => {
      if (c.id === campaignId) {
        return { ...c, volunteersJoined: c.volunteersJoined + 1 };
      }
      return c;
    }));
    setUser(prev => ({
      ...prev,
      ecoCoins: prev.ecoCoins + 50
    }));
    addNotification('Campaign Joined!', 'Thank you for volunteering! Earned 50 Eco Coins.', 'success');
  };

  // Municipality assigns truck to pickup
  const assignTruckToPickup = (pickupId: string, truckId: string) => {
    setPickups(prev => prev.map(p => {
      if (p.id === pickupId) {
        setTrucks(tList => tList.map(t => {
          if (t.id === truckId) {
            return {
              ...t,
              routeStops: [...t.routeStops, { name: p.address, lat: p.lat, lng: p.lng, completed: false }]
            };
          }
          return t;
        }));
        return { ...p, status: 'Assigned', driverId: truckId };
      }
      return p;
    }));
    addNotification('Driver Assigned', `Assigned Truck ${truckId} to pickup request ${pickupId}.`, 'info');
  };

  // Driver marks pickup complete
  const completeDriverPickup = (pickupId: string) => {
    let earnedCoins = 0;
    let carbonSavings = 0;

    setPickups(prev => prev.map(p => {
      if (p.id === pickupId) {
        earnedCoins = p.ecoCoinsEarned;
        carbonSavings = Number((p.weight * 1.8).toFixed(1));
        return { ...p, status: 'Collected' };
      }
      return p;
    }));

    setTrucks(tList => tList.map(t => {
      const activePickup = pickups.find(p => p.id === pickupId);
      if (activePickup && t.id === activePickup.driverId) {
        const updatedStops = t.routeStops.map(stop => {
          if (stop.name.includes(activePickup.address)) {
            return { ...stop, completed: true };
          }
          return stop;
        });
        const completedCount = updatedStops.filter(s => s.completed).length;
        return {
          ...t,
          capacity: Math.min(100, t.capacity + 6),
          routeStops: updatedStops,
          currentStopIndex: Math.min(updatedStops.length - 1, completedCount)
        };
      }
      return t;
    }));

    setUser(prev => ({
      ...prev,
      ecoCoins: prev.ecoCoins + earnedCoins,
      carbonSaved: Number((prev.carbonSaved + carbonSavings).toFixed(1))
    }));

    addNotification('Pickup Completed', `Waste collected. Citizens rewarded.`, 'success');
  };

  // AI Route Optimizer
  const triggerRouteOptimization = () => {
    setTrucks(prev => prev.map(t => {
      const criticalBinStops = smartBins
        .filter(b => b.status !== 'Normal')
        .map(b => ({ name: `IoT Bin: ${b.id} (${b.address})`, lat: b.lat, lng: b.lng, completed: false }));

      const currentStops = t.routeStops.filter(s => !s.completed);
      const completedStops = t.routeStops.filter(s => s.completed);
      const sortedStops = [...currentStops, ...criticalBinStops].sort((a, b) => a.lat - b.lat);

      return {
        ...t,
        routeStops: [...completedStops, ...sortedStops],
        eta: 'Optimized (4 mins)',
        fuelSavedLiters: Number((t.fuelSavedLiters + 2.5).toFixed(1)),
        co2SavedKg: Number((t.co2SavedKg + 6.2).toFixed(1))
      };
    }));

    // Update ward coverage
    setWardCoverageList(prev => prev.map(w => ({
      ...w,
      percent: Math.min(100, Number((w.percent + 2.2).toFixed(1))),
      servicedBins: Math.min(w.totalBins, w.servicedBins + 1)
    })));

    addNotification('AI Route Optimizer Executed', 'Fleet routes re-aligned to prioritize full bins and eliminate detour miles.', 'success');
    playSuccessChime();
  };

  // Empty a smart bin
  const emptyBin = (binId: string) => {
    setSmartBins(prev => prev.map(b => {
      if (b.id === binId) {
        return {
          ...b,
          fillPercentage: 0,
          temperature: 25,
          humidity: 35,
          methane: 2,
          status: 'Normal',
          lastEmptied: new Date().toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })
        };
      }
      return b;
    }));
    addNotification('Smart Bin Emptied', `Bin ${binId} has been successfully cleared and reset.`, 'success');
  };

  // Real-time GPS Fleet Telemetry & IoT Simulation Loop
  useEffect(() => {
    if (!isSimulating) return;

    const tickTime = Math.max(1500, 4000 / simulationSpeed);

    const interval = setInterval(() => {
      // 1. Move active trucks along their route points
      setTrucks(prevTrucks =>
        prevTrucks.map(truck => {
          if (truck.status === 'Transfer Station' || truck.status === 'Maintenance') return truck;

          const currentStop = truck.routeStops[truck.currentStopIndex];
          if (!currentStop) return truck;

          const latDiff = currentStop.lat - truck.lat;
          const lngDiff = currentStop.lng - truck.lng;
          const distanceToStop = Math.sqrt(latDiff * latDiff + lngDiff * lngDiff);

          // If within reach of stop, complete it
          if (distanceToStop < 0.0006) {
            const updatedStops = truck.routeStops.map((stop, idx) =>
              idx === truck.currentStopIndex ? { ...stop, completed: true } : stop
            );
            const nextIdx = (truck.currentStopIndex + 1) % truck.routeStops.length;

            return {
              ...truck,
              lat: currentStop.lat,
              lng: currentStop.lng,
              routeStops: updatedStops,
              currentStopIndex: nextIdx,
              capacity: Math.min(100, truck.capacity + 3),
              distanceTraveledKm: Number((truck.distanceTraveledKm + 0.3).toFixed(1)),
              eta: `${Math.floor(Math.random() * 4) + 2} mins`
            };
          }

          // Step towards target stop
          const stepSize = 0.00035 * simulationSpeed;
          const angle = Math.atan2(latDiff, lngDiff);
          const newLat = truck.lat + Math.sin(angle) * stepSize;
          const newLng = truck.lng + Math.cos(angle) * stepSize;
          const headingDeg = Math.round((angle * 180) / Math.PI + 90);

          return {
            ...truck,
            lat: Number(newLat.toFixed(6)),
            lng: Number(newLng.toFixed(6)),
            heading: headingDeg >= 0 ? headingDeg : headingDeg + 360,
            speed: Math.floor(Math.random() * 12) + 24,
            distanceTraveledKm: Number((truck.distanceTraveledKm + 0.05).toFixed(1)),
            fuelLevel: truck.fuelType === 'Electric' ? Math.max(5, truck.fuelLevel - 0.05) : Math.max(5, truck.fuelLevel - 0.1)
          };
        })
      );

      // 2. Check citizen proximity for TRK-901
      const nearestTruck = trucks.find(t => t.id === 'TRK-901');
      if (nearestTruck && proximityAlertEnabled) {
        const dLat = (nearestTruck.lat - user.homeCoords.lat) * 111; // approx km
        const dLng = (nearestTruck.lng - user.homeCoords.lng) * 111 * Math.cos(user.homeCoords.lat * (Math.PI / 180));
        const distanceKm = Math.sqrt(dLat * dLat + dLng * dLng);

        if (distanceKm < 0.6 && !proximityAlertFiredRef.current) {
          proximityAlertFiredRef.current = true;
          playProximityChime();
          addNotification(
            '🚚 Truck Approaching Your Street!',
            `SmartWaste Truck ${nearestTruck.id} (${nearestTruck.driverName}) is within 500m of ${user.homeAddress}. Please place waste bins outside.`,
            'alert'
          );
        } else if (distanceKm > 1.2) {
          proximityAlertFiredRef.current = false;
        }
      }

      // 3. IoT Bin fill fluctuations
      if (Math.random() > 0.6) {
        setSmartBins(prev => prev.map(bin => {
          if (bin.fillPercentage >= 100) return bin;
          const added = Math.floor(Math.random() * 2) + 1;
          const newFill = Math.min(100, bin.fillPercentage + added);
          let newStatus: SmartBin['status'] = 'Normal';
          if (newFill >= 90) newStatus = 'Critical';
          else if (newFill >= 75) newStatus = 'Warning';

          return {
            ...bin,
            fillPercentage: newFill,
            status: newStatus
          };
        }));
      }

      // 4. Update SLA timers on reported missed pickups
      setMissedPickups(prev => prev.map(m => {
        if (m.status === 'Resolved' || m.slaMinutes <= 0) return m;
        return { ...m, slaMinutes: Math.max(0, m.slaMinutes - 1) };
      }));
    }, tickTime);

    return () => clearInterval(interval);
  }, [isSimulating, simulationSpeed, proximityAlertEnabled, trucks, user.homeCoords, user.homeAddress]);

  return (
    <AppContext.Provider value={{
      user, setUser,
      currentRole, setCurrentRole,
      pickups, setPickups,
      smartBins, setSmartBins,
      trucks, setTrucks,
      missedPickups, setMissedPickups,
      schedules, setSchedules,
      wardCoverageList,
      cityWideCoverageScore,
      proximityAlertEnabled, setProximityAlertEnabled,
      listings, setListings,
      dumpReports, setDumpReports,
      campaigns, setCampaigns,
      notifications, setNotifications,
      addNotification,
      schedulePickup,
      reportMissedPickup,
      autoDispatchTruckToMissedPickup,
      resolveMissedPickup,
      reportDumping,
      placeBid,
      joinCampaign,
      assignTruckToPickup,
      completeDriverPickup,
      triggerRouteOptimization,
      emptyBin,
      isSimulating, setIsSimulating,
      simulationSpeed, setSimulationSpeed
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
