import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, Users, MapPin, X, AlertTriangle } from 'lucide-react';
import { useApp } from '../context/AppContext';
import L from 'leaflet';

export const NGOPortal: React.FC = () => {
  const { campaigns, joinCampaign, reportDumping } = useApp();
  const [activeTab, setActiveTab] = useState<'ngo' | 'report'>('ngo');

  // Report Form State
  const [category, setCategory] = useState('Plastic Accumulation');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState<'Low' | 'Medium' | 'High'>('High');
  const [anonymous, setAnonymous] = useState(false);
  const [dumpCoords, setDumpCoords] = useState<{ lat: number; lng: number }>({ lat: 21.1824, lng: 72.7915 });
  const [dumpPhoto, setDumpPhoto] = useState<string | null>(null);
  const [showCameraModal, setShowCameraModal] = useState(false);

  const dumpMapRef = useRef<L.Map | null>(null);

  // Initialize Dump Picker Map
  useEffect(() => {
    if (activeTab === 'report') {
      setTimeout(() => {
        if (dumpMapRef.current) return;
        const map = L.map('dump-picker-map').setView([21.1824, 72.7915], 13);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

        let marker = L.marker([21.1824, 72.7915], { draggable: true }).addTo(map);
        marker.on('dragend', () => {
          const position = marker.getLatLng();
          setDumpCoords({ lat: position.lat, lng: position.lng });
        });

        map.on('click', (e) => {
          const { lat, lng } = e.latlng;
          marker.setLatLng([lat, lng]);
          setDumpCoords({ lat, lng });
        });

        dumpMapRef.current = map;
      }, 100);
    } else {
      if (dumpMapRef.current) {
        dumpMapRef.current.remove();
        dumpMapRef.current = null;
      }
    }
  }, [activeTab]);

  const handleReportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    reportDumping({
      category,
      lat: dumpCoords.lat,
      lng: dumpCoords.lng,
      address: `Custom Pin drop (${dumpCoords.lat.toFixed(4)}, ${dumpCoords.lng.toFixed(4)})`,
      photoUrl: dumpPhoto || 'https://images.unsplash.com/photo-1611284446314-60a58ac0deb9?auto=format&fit=crop&q=80&w=300',
      description,
      priority
    });
    // Reset fields
    setDescription('');
    setDumpPhoto(null);
    setActiveTab('ngo');
  };

  const simulateCameraSnapshot = () => {
    setDumpPhoto('https://images.unsplash.com/photo-1611284446314-60a58ac0deb9?auto=format&fit=crop&q=80&w=300');
    setShowCameraModal(false);
  };

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-6 space-y-6">
      {/* Tab Switcher */}
      <div className="flex bg-slate-100 dark:bg-brand-cardDark p-1 rounded-xl border border-slate-200/30 dark:border-slate-800/30 w-fit gap-1 mx-auto">
        <button
          onClick={() => setActiveTab('ngo')}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold transition-all ${
            activeTab === 'ngo'
              ? 'bg-eco-500 text-white shadow-sm'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <Heart className="w-3.5 h-3.5" /> NGO Campaigns
        </button>
        <button
          onClick={() => setActiveTab('report')}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold transition-all ${
            activeTab === 'report'
              ? 'bg-eco-500 text-white shadow-sm'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <AlertTriangle className="w-3.5 h-3.5" /> Report Dumping
        </button>
      </div>

      <div className="min-h-[400px]">
        <AnimatePresence mode="wait">
          {activeTab === 'ngo' && (
            <motion.div
              key="ngo-view"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="space-y-6"
            >
              <div className="text-center mb-6">
                <h2 className="text-xl md:text-2xl font-extrabold text-slate-800 dark:text-white">Active Social Campaigns</h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Support environmental organizations, volunteer for cleanups, or sponsor tree saplings.
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                {campaigns.map(camp => (
                  <div
                    key={camp.id}
                    className="p-5 rounded-2xl bg-white dark:bg-brand-cardDark border border-slate-200/50 dark:border-slate-800/50 shadow-sm flex flex-col justify-between"
                  >
                    <div className="space-y-3">
                      <div className="flex justify-between items-start">
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 uppercase">
                          {camp.organizer}
                        </span>
                        <span className="text-[10px] text-slate-400 font-bold">{camp.date}</span>
                      </div>

                      <h4 className="font-extrabold text-base text-slate-800 dark:text-white">{camp.title}</h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">{camp.description}</p>
                      
                      <div className="flex items-center gap-1.5 text-xs text-slate-500">
                        <MapPin className="w-4 h-4 text-emerald-500" /> {camp.location}
                      </div>
                    </div>

                    <div className="pt-4 border-t border-slate-100 dark:border-slate-800/60 mt-4 flex items-center justify-between">
                      <span className="text-xs text-slate-400 font-semibold flex items-center gap-1">
                        <Users className="w-4 h-4" /> {camp.volunteersJoined} / {camp.targetVolunteers} Volunteers
                      </span>
                      
                      <button
                        onClick={() => joinCampaign(camp.id)}
                        id={`btn-join-campaign-${camp.id}`}
                        className="px-4 py-2 rounded-lg bg-eco-500 hover:bg-eco-600 text-white font-bold text-xs shadow-md transition-colors"
                      >
                        Join as Volunteer
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {activeTab === 'report' && (
            <motion.div
              key="report-view"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="grid md:grid-cols-2 gap-6"
            >
              {/* Form */}
              <form onSubmit={handleReportSubmit} className="space-y-4">
                <h3 className="text-lg font-bold text-slate-800 dark:text-white flex items-center gap-1.5">
                  🚨 Report Public Garbage Dumping
                </h3>
                <p className="text-xs text-slate-400">
                  Help the city administration locate overflow areas or illegal dumps. Reports are processed anonymously.
                </p>

                <div>
                  <label className="text-xs text-slate-400 font-semibold uppercase block mb-1">Garbage Category</label>
                  <select
                    value={category}
                    onChange={e => setCategory(e.target.value)}
                    className="w-full px-4 py-3 bg-white dark:bg-brand-cardDark text-slate-800 dark:text-white rounded-xl border border-slate-200 dark:border-slate-800 focus:outline-none focus:border-eco-500 text-sm shadow-sm"
                  >
                    {['Plastic Accumulation', 'Construction Debris', 'Electronic Dump', 'Toxic / Hazardous Liquid', 'Medical Waste', 'Bio scraps'].map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs text-slate-400 font-semibold uppercase block mb-1">Priority Level</label>
                    <select
                      value={priority}
                      onChange={e => setPriority(e.target.value as any)}
                      className="w-full px-4 py-3 bg-white dark:bg-brand-cardDark text-slate-800 dark:text-white rounded-xl border border-slate-200 dark:border-slate-800 focus:outline-none focus:border-eco-500 text-sm shadow-sm"
                    >
                      <option value="Low">Low Priority</option>
                      <option value="Medium">Medium Priority</option>
                      <option value="High">High Priority (Urgent)</option>
                    </select>
                  </div>

                  <div className="flex items-center pt-5">
                    <label className="flex items-center gap-2 text-xs font-semibold text-slate-500 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={anonymous}
                        onChange={e => setAnonymous(e.target.checked)}
                        className="rounded border-slate-300 accent-eco-500"
                      />
                      Report anonymously
                    </label>
                  </div>
                </div>

                <div>
                  <label className="text-xs text-slate-400 font-semibold uppercase block mb-1">Description / Notes</label>
                  <textarea
                    required
                    value={description}
                    onChange={e => setDescription(e.target.value)}
                    placeholder="Describe size of accumulation, hazardous smell, or if causing roadblock."
                    className="w-full px-4 py-3 bg-white dark:bg-brand-cardDark text-slate-800 dark:text-white rounded-xl border border-slate-200 dark:border-slate-800 focus:outline-none focus:border-eco-500 text-sm shadow-sm"
                    rows={3}
                  />
                </div>

                {/* Photo Snap */}
                <div>
                  <span className="text-xs text-slate-400 font-semibold uppercase block mb-1">Attach Photograph</span>
                  <div className="flex gap-2 items-center">
                    {dumpPhoto ? (
                      <div className="relative w-20 h-20 rounded-xl overflow-hidden border border-slate-200">
                        <img src={dumpPhoto} className="w-full h-full object-cover" />
                        <button
                          type="button"
                          onClick={() => setDumpPhoto(null)}
                          className="absolute top-1 right-1 p-0.5 rounded-full bg-rose-500 text-white"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setShowCameraModal(true)}
                        className="h-20 flex-1 border-2 border-dashed border-slate-200 dark:border-slate-800 hover:bg-slate-100/50 dark:hover:bg-brand-cardDark/50 rounded-xl flex flex-col items-center justify-center text-slate-400 text-xs font-semibold animate-pulse"
                      >
                        📷 Tap to Attach Photo Evidence
                      </button>
                    )}
                  </div>
                </div>

                <button
                  type="submit"
                  id="btn-report-dumping"
                  className="w-full py-3.5 rounded-xl bg-rose-500 hover:bg-rose-600 text-white font-bold shadow-lg hover:shadow-rose-500/20 active:scale-98 transition-all text-sm"
                >
                  File Complaint
                </button>
              </form>

              {/* Coordinates Pin Drop Map */}
              <div className="flex flex-col h-[400px] md:h-auto">
                <label className="text-xs text-slate-400 font-semibold uppercase block mb-1">Pin Location coordinates (Drag Marker)</label>
                <div id="dump-picker-map" className="flex-1 rounded-2xl border border-slate-200 dark:border-slate-800/80 shadow-md min-h-[300px]" />
                <div className="mt-2 text-xs text-slate-400">
                  Dump site Coords: ({dumpCoords.lat.toFixed(4)}, {dumpCoords.lng.toFixed(4)})
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Simulated camera capture evidence modal */}
      <AnimatePresence>
        {showCameraModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white dark:bg-brand-cardDark p-6 rounded-2xl shadow-glass border border-slate-200 dark:border-slate-800/80 w-full max-w-md relative"
            >
              <h4 className="font-bold text-base mb-3 text-slate-800 dark:text-white">Simulated Evidence Camera</h4>
              <div className="aspect-video bg-slate-900 rounded-xl overflow-hidden relative mb-4 border border-slate-800">
                <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-500 text-xs">
                  <span className="text-4xl animate-bounce mb-2">📸</span>
                  <span>Align camera window with garbage heap...</span>
                </div>
              </div>
              <div className="flex gap-3 justify-end">
                <button
                  type="button"
                  onClick={() => setShowCameraModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-500"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={simulateCameraSnapshot}
                  className="px-5 py-2 text-xs font-bold rounded-lg bg-eco-500 text-white"
                >
                  Take Evidence Photo
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
