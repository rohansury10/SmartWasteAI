import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Truck, Camera, AlertOctagon, Zap, Compass, X } from 'lucide-react';
import { useApp } from '../context/AppContext';
import L from 'leaflet';

export const DriverDashboard: React.FC = () => {
  const { trucks, pickups, completeDriverPickup, addNotification } = useApp();
  const [activeTruckId, setActiveTruckId] = useState('TRK-901');
  const [selectedStopIdx, setSelectedStopIdx] = useState<number | null>(null);
  const [showQrModal, setShowQrModal] = useState(false);
  const [showRoadblockModal, setShowRoadblockModal] = useState(false);
  const [roadblockDesc, setRoadblockDesc] = useState('');
  
  const driverMapRef = useRef<L.Map | null>(null);
  const activeTruck = trucks.find(t => t.id === activeTruckId) || trucks[0];

  // Initialize Navigation Map
  useEffect(() => {
    setTimeout(() => {
      if (driverMapRef.current) driverMapRef.current.remove();
      if (!activeTruck) return;

      const map = L.map('driver-nav-map').setView([activeTruck.lat, activeTruck.lng], 14);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

      // Active Truck Marker
      const truckIcon = L.divIcon({
        html: `<div class="w-8 h-8 rounded-full bg-blue-600 border-2 border-white flex items-center justify-center text-white font-bold shadow-md pulse-marker-active">🚚</div>`,
        className: ''
      });
      const truckMarker = L.marker([activeTruck.lat, activeTruck.lng], { icon: truckIcon }).addTo(map);

      // Stop Markers
      activeTruck.routeStops.forEach((stop, idx) => {
        const iconSymbol = stop.completed ? '✅' : '📍';
        const markerIcon = L.divIcon({
          html: `<div class="w-7 h-7 rounded-full bg-white dark:bg-brand-cardDark border-2 border-slate-300 dark:border-slate-800 flex items-center justify-center text-sm shadow-sm">${iconSymbol}</div>`,
          className: ''
        });
        L.marker([stop.lat, stop.lng], { icon: markerIcon }).addTo(map).bindPopup(`<b>Stop ${idx + 1}</b>: ${stop.name}`);
      });

      // Update truck position live
      const interval = setInterval(() => {
        truckMarker.setLatLng([activeTruck.lat, activeTruck.lng]);
      }, 1000);

      driverMapRef.current = map;
      return () => {
        clearInterval(interval);
        if (driverMapRef.current) {
          driverMapRef.current.remove();
          driverMapRef.current = null;
        }
      };
    }, 100);
  }, [activeTruckId, activeTruck?.lat, activeTruck?.lng, activeTruck?.routeStops]);

  const handleStopComplete = (pickupId: string) => {
    completeDriverPickup(pickupId);
    setShowQrModal(false);
  };

  const handleRoadblockSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addNotification('Roadblock Reported', `Blocked: ${roadblockDesc}. Municipal squad dispatched.`, 'warning');
    setShowRoadblockModal(false);
    setRoadblockDesc('');
  };

  // Find corresponding pickup ID for the stop to link back to AppState
  const getPickupForStop = (stopAddress: string) => {
    return pickups.find(p => p.address === stopAddress && p.status !== 'Recycled');
  };

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-6 space-y-6">
      {/* Truck HUD Header */}
      <div className="grid md:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl glass-panel border border-slate-200/50 dark:border-slate-800/30 shadow-md flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 font-bold uppercase">Active Vehicle</span>
            <select
              value={activeTruckId}
              onChange={(e) => setActiveTruckId(e.target.value)}
              className="text-sm font-extrabold text-slate-800 dark:text-white mt-1 bg-transparent border-none p-0 cursor-pointer focus:ring-0"
            >
              {trucks.map(t => (
                <option key={t.id} value={t.id} className="text-slate-800 dark:text-slate-900 font-bold">
                  {t.id} ({t.fuelType})
                </option>
              ))}
            </select>
          </div>
          <Truck className="w-8 h-8 text-blue-500" />
        </div>

        <div className="p-4 rounded-2xl glass-panel border border-slate-200/50 dark:border-slate-800/30 shadow-md flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 font-bold uppercase">CNG / Fuel level</span>
            <h4 className="text-lg font-extrabold text-emerald-500 mt-1">{activeTruck?.fuelLevel.toFixed(1)}%</h4>
          </div>
          <Zap className="w-8 h-8 text-emerald-500" />
        </div>

        <div className="p-4 rounded-2xl glass-panel border border-slate-200/50 dark:border-slate-800/30 shadow-md flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 font-bold uppercase">Live Speed</span>
            <h4 className="text-lg font-extrabold text-slate-800 dark:text-white mt-1">{activeTruck?.speed} km/h</h4>
          </div>
          <Compass className="w-8 h-8 text-sky-500" />
        </div>

        <div className="p-4 rounded-2xl glass-panel border border-slate-200/50 dark:border-slate-800/30 shadow-md flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 font-bold uppercase">Truck Capacity</span>
            <h4 className="text-lg font-extrabold text-slate-800 dark:text-white mt-1">{activeTruck?.capacity}%</h4>
          </div>
          <Truck className="w-8 h-8 text-blue-500" />
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Navigation HUD Leaflet map */}
        <div className="lg:col-span-2 flex flex-col h-[400px] lg:h-[480px]">
          <div className="flex justify-between items-center mb-1">
            <h3 className="text-base font-bold text-slate-800 dark:text-white">Active Nav-Route Path</h3>
            <span className="text-xs text-slate-400">Heading North-East</span>
          </div>
          <div id="driver-nav-map" className="flex-1 rounded-2xl border border-slate-200 dark:border-slate-800/80 shadow-md" />
        </div>

        {/* Checklist */}
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-base font-bold text-slate-800 dark:text-white">Today's Stop Checklist</h3>
            <button
              onClick={() => setShowRoadblockModal(true)}
              className="text-xs bg-rose-500/10 text-rose-500 font-bold px-2 py-1 rounded border border-rose-500/20 flex items-center gap-1"
            >
              <AlertOctagon className="w-3.5 h-3.5" /> Report Block
            </button>
          </div>

          <div className="space-y-3 max-h-[420px] overflow-y-auto pr-1">
            {activeTruck?.routeStops.map((stop, idx) => {
              const matchedPickup = getPickupForStop(stop.name);
              const isSelected = selectedStopIdx === idx;

              return (
                <div
                  key={idx}
                  onClick={() => setSelectedStopIdx(isSelected ? null : idx)}
                  className={`p-4 rounded-xl cursor-pointer transition-all border ${
                    stop.completed
                      ? 'bg-slate-100/50 dark:bg-brand-cardDark/50 border-slate-200/50 dark:border-slate-800/50 opacity-60'
                      : isSelected
                      ? 'bg-eco-500/10 border-eco-500/40'
                      : 'bg-white dark:bg-brand-cardDark border-slate-200/50 dark:border-slate-800/50 shadow-sm hover:border-slate-300 dark:hover:border-slate-700'
                  }`}
                >
                  <div className="flex justify-between items-start gap-2">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded text-slate-500">
                        Stop {idx + 1}
                      </span>
                      {stop.completed && <span className="text-xs text-emerald-500 font-semibold">Done</span>}
                    </div>
                    <span className="text-[10px] text-slate-400">1.8 km</span>
                  </div>

                  <p className="text-xs font-bold text-slate-800 dark:text-white mt-2">{stop.name}</p>

                  <AnimatePresence>
                    {isSelected && !stop.completed && matchedPickup && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="mt-3 pt-3 border-t border-slate-200/30 dark:border-slate-800/30 space-y-3 overflow-hidden"
                      >
                        <div className="flex justify-between items-center text-xs">
                          <span className="text-slate-400">Type</span>
                          <span className="font-bold text-slate-700 dark:text-slate-200">{matchedPickup.type} Waste</span>
                        </div>
                        <div className="flex justify-between items-center text-xs">
                          <span className="text-slate-400">Weight</span>
                          <span className="font-bold text-slate-700 dark:text-slate-200">{matchedPickup.weight} kg</span>
                        </div>
                        <div className="flex justify-between items-center text-xs">
                          <span className="text-slate-400">Contact</span>
                          <span className="font-bold text-slate-700 dark:text-slate-200">{matchedPickup.citizenName}</span>
                        </div>

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setShowQrModal(true);
                          }}
                          id={`btn-driver-scan-${matchedPickup.id}`}
                          className="w-full py-2 rounded-lg bg-eco-500 hover:bg-eco-600 text-white font-bold text-xs shadow-md active:scale-95 transition-all flex items-center justify-center gap-1.5"
                        >
                          <Camera className="w-3.5 h-3.5" /> Validate Smart Bin QR / Scan Code
                        </button>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* QR Code Validation Scanner Modal */}
      <AnimatePresence>
        {showQrModal && selectedStopIdx !== null && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white dark:bg-brand-cardDark p-6 rounded-2xl shadow-glass border border-slate-200 dark:border-slate-800/80 w-full max-w-md relative"
            >
              <button
                onClick={() => setShowQrModal(false)}
                className="absolute top-4 right-4 text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>

              <h4 className="font-bold text-base mb-3 text-slate-800 dark:text-white">Scan Smart Bin QR Code</h4>
              <p className="text-xs text-slate-500 mb-4">
                Point the driver lens at the bin's physical QR barcode to authenticate volume matching.
              </p>

              <div className="aspect-square w-48 mx-auto bg-slate-900 rounded-xl overflow-hidden relative mb-6 border border-slate-800 flex items-center justify-center">
                {/* QR Guide lines */}
                <div className="absolute inset-6 border border-white/20 pointer-events-none rounded flex items-center justify-center">
                  <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-eco-400" />
                  <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-eco-400" />
                  <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-eco-400" />
                  <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-eco-400" />
                  <span className="text-[9px] text-white/40 font-mono">TARGET QR</span>
                </div>
                <span className="text-3xl animate-bounce">📱</span>
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowQrModal(false)}
                  className="flex-1 py-2 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-semibold text-xs rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  id="btn-scan-qr-validate"
                  onClick={() => {
                    const stop = activeTruck.routeStops[selectedStopIdx];
                    const matchedPickup = getPickupForStop(stop.name);
                    if (matchedPickup) {
                      handleStopComplete(matchedPickup.id);
                    }
                  }}
                  className="flex-1 py-2 bg-eco-500 hover:bg-eco-600 text-white font-bold text-xs rounded-lg shadow-md"
                >
                  Simulate QR Verified
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Roadblock Modal */}
      <AnimatePresence>
        {showRoadblockModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white dark:bg-brand-cardDark p-6 rounded-2xl shadow-glass border border-slate-200 dark:border-slate-800/80 w-full max-w-md relative"
            >
              <button onClick={() => setShowRoadblockModal(false)} className="absolute top-4 right-4 text-slate-400 hover:text-slate-600"><X className="w-5 h-5" /></button>
              <h4 className="font-bold text-base mb-3 text-slate-800 dark:text-white">Report Road Blockage / Traffic</h4>
              <form onSubmit={handleRoadblockSubmit} className="space-y-4">
                <div>
                  <label className="text-xs text-slate-400 font-semibold uppercase block mb-1">Blockage Description</label>
                  <textarea
                    required
                    value={roadblockDesc}
                    onChange={e => setRoadblockDesc(e.target.value)}
                    placeholder="E.g., VIP road closed for metro construction work."
                    className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-white border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none"
                    rows={3}
                  />
                </div>
                <button type="submit" className="w-full py-2.5 rounded-lg bg-rose-500 hover:bg-rose-600 text-white font-bold text-xs">
                  Report to Command Center
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
