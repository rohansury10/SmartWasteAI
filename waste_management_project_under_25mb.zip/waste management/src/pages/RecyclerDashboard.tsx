import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShoppingBag, TrendingUp, DollarSign, Layers, X, Gavel, FileText } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const RecyclerDashboard: React.FC = () => {
  const { listings, placeBid, user, addNotification } = useApp();
  const [selectedListingId, setSelectedListingId] = useState<string | null>(null);
  const [bidAmount, setBidAmount] = useState<number>(0);
  const [activeTab, setActiveTab] = useState<'market' | 'inventory' | 'prices'>('market');

  const selectedListing = listings.find(l => l.id === selectedListingId);

  const handleBidSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedListingId && bidAmount > 0) {
      const success = placeBid(selectedListingId, bidAmount, user.name);
      if (success) {
        setSelectedListingId(null);
      } else {
        addNotification('Bid Failed', 'Bid amount must exceed current highest bid.', 'warning');
      }
    }
  };

  const inventoryStock = [
    { type: 'rPET (Polyester Pellets)', quantity: '1,240 kg', purity: '98.5%', buyer: 'PepsiCo India' },
    { type: 'Recycled Aluminum Ingots', quantity: '850 kg', purity: '99.1%', buyer: 'Hindalco' },
    { type: 'Shredded Copper Wire', quantity: '420 kg', purity: '96.2%', buyer: 'Surat Cables Ltd.' },
    { type: 'De-inked Paper Pulp', quantity: '3,100 kg', purity: '92.0%', buyer: 'Century Paper Mill' }
  ];

  const commodityPrices = [
    { name: 'PET Plastic Scrap', current: '₹34 / kg', change: '+2.4%', trend: 'up' },
    { name: 'HDPE Plastic Bottles', current: '₹48 / kg', change: '-1.1%', trend: 'down' },
    { name: 'Copper Wire Scrap', current: '₹620 / kg', change: '+4.5%', trend: 'up' },
    { name: 'Cardboard Waste', current: '₹14 / kg', change: '0.0%', trend: 'neutral' },
    { name: 'Aluminum Cans', current: '₹115 / kg', change: '+1.8%', trend: 'up' }
  ];

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-6 space-y-6">
      {/* HUD metrics */}
      <div className="grid md:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl glass-panel border border-slate-200/50 dark:border-slate-800/30 shadow-md flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 font-bold uppercase">Active Purchases</span>
            <h4 className="text-xl font-extrabold text-slate-800 dark:text-white mt-1">
              {listings.filter(l => l.highestBidder === user.name).length} Orders
            </h4>
          </div>
          <ShoppingBag className="w-8 h-8 text-blue-500" />
        </div>

        <div className="p-5 rounded-2xl glass-panel border border-slate-200/50 dark:border-slate-800/30 shadow-md flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 font-bold uppercase">Commodity Market Index</span>
            <h4 className="text-xl font-extrabold text-emerald-500 mt-1">Bullish (+3.2%)</h4>
          </div>
          <TrendingUp className="w-8 h-8 text-emerald-500" />
        </div>

        <div className="p-5 rounded-2xl glass-panel border border-slate-200/50 dark:border-slate-800/30 shadow-md flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 font-bold uppercase">Material Stock Vol.</span>
            <h4 className="text-xl font-extrabold text-slate-800 dark:text-white mt-1">5,610 kg</h4>
          </div>
          <Layers className="w-8 h-8 text-indigo-500" />
        </div>
      </div>

      {/* Tabs */}
      <div className="flex bg-slate-100 dark:bg-brand-cardDark p-1 rounded-xl border border-slate-200/30 dark:border-slate-800/30 w-fit gap-1">
        {[
          { id: 'market', label: 'Bidding Board', icon: <Gavel className="w-3.5 h-3.5" /> },
          { id: 'inventory', label: 'Recycled Stocks', icon: <Layers className="w-3.5 h-3.5" /> },
          { id: 'prices', label: 'Commodity Prices', icon: <DollarSign className="w-3.5 h-3.5" /> }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold transition-all ${
              activeTab === tab.id
                ? 'bg-eco-500 text-white shadow-sm'
                : 'text-slate-500 dark:text-slate-400 hover:bg-slate-200/50 dark:hover:bg-slate-800/50'
            }`}
          >
            {tab.icon}
            {tab.label}
          </button>
        ))}
      </div>

      {/* Content tabs */}
      <div className="min-h-[400px]">
        <AnimatePresence mode="wait">
          {activeTab === 'market' && (
            <motion.div
              key="market-view"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="grid md:grid-cols-2 lg:grid-cols-4 gap-6"
            >
              {listings.map(item => (
                <div
                  key={item.id}
                  className="rounded-2xl overflow-hidden bg-white dark:bg-brand-cardDark border border-slate-200/50 dark:border-slate-800/50 shadow-sm flex flex-col justify-between"
                >
                  <div className="relative aspect-video">
                    <img src={item.image} alt={item.type} className="w-full h-full object-cover" />
                    <span className="absolute bottom-2 left-2 bg-slate-900/80 backdrop-blur-md text-white text-[10px] font-bold px-2 py-0.5 rounded uppercase">
                      {item.quantity}
                    </span>
                  </div>

                  <div className="p-4 space-y-3 flex-1 flex flex-col justify-between">
                    <div>
                      <h4 className="font-bold text-sm text-slate-800 dark:text-white line-clamp-1">{item.type}</h4>
                      <p className="text-[10px] text-slate-400 mt-0.5">Listed by: {item.sellerName}</p>
                    </div>

                    <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-1">
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-slate-400">Current Bid</span>
                        <span className="font-bold text-slate-800 dark:text-white">₹{item.currentBid}</span>
                      </div>
                      <div className="flex justify-between items-center text-[10px]">
                        <span className="text-slate-400">Highest Bidder</span>
                        <span className="font-semibold text-eco-500">{item.highestBidder || 'None'}</span>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        setSelectedListingId(item.id);
                        setBidAmount(item.currentBid + 100);
                      }}
                      id={`btn-bid-${item.id}`}
                      className="w-full py-2 bg-eco-500 hover:bg-eco-600 text-white font-bold text-xs rounded-xl shadow-md transition-colors flex items-center justify-center gap-1 mt-2"
                    >
                      <Gavel className="w-3.5 h-3.5" /> Place Offer / Bid
                    </button>
                  </div>
                </div>
              ))}
            </motion.div>
          )}

          {activeTab === 'inventory' && (
            <motion.div
              key="inventory-view"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="space-y-4"
            >
              <h3 className="text-base font-bold text-slate-800 dark:text-white">Reprocessed Materials Stockpile</h3>
              <div className="overflow-hidden rounded-2xl border border-slate-200 dark:border-slate-800/80 shadow-md">
                <table className="w-full text-left border-collapse bg-white dark:bg-brand-cardDark">
                  <thead>
                    <tr className="bg-slate-100/80 dark:bg-brand-cardDark/80 border-b border-slate-200/30 dark:border-slate-800/30 text-xs font-bold text-slate-400 uppercase">
                      <th className="p-4">Material Category</th>
                      <th className="p-4">In-Stock Quantity</th>
                      <th className="p-4">Average Purity Index</th>
                      <th className="p-4">Target Offtake Partner</th>
                      <th className="p-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800/50 text-sm">
                    {inventoryStock.map((inv, idx) => (
                      <tr key={idx} className="hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors">
                        <td className="p-4 font-bold text-slate-700 dark:text-slate-300">{inv.type}</td>
                        <td className="p-4 font-semibold">{inv.quantity}</td>
                        <td className="p-4">
                          <span className="px-2.5 py-0.5 rounded bg-emerald-500/10 text-emerald-500 font-bold text-xs">
                            {inv.purity}
                          </span>
                        </td>
                        <td className="p-4 font-medium text-slate-500">{inv.buyer}</td>
                        <td className="p-4 text-right">
                          <button className="text-xs text-eco-500 font-bold hover:underline flex items-center gap-1 ml-auto">
                            <FileText className="w-3.5 h-3.5" /> Manifest
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}

          {activeTab === 'prices' && (
            <motion.div
              key="prices-view"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="max-w-2xl mx-auto space-y-4"
            >
              <h3 className="text-base font-bold text-slate-800 dark:text-white text-center">Daily Commodity Price Index</h3>
              <div className="rounded-2xl border border-slate-200 dark:border-slate-800/80 shadow-md bg-white dark:bg-brand-cardDark overflow-hidden">
                <div className="divide-y divide-slate-100 dark:divide-slate-800/50">
                  {commodityPrices.map((comm, idx) => (
                    <div key={idx} className="p-4 flex items-center justify-between text-sm">
                      <div>
                        <span className="font-bold text-slate-700 dark:text-slate-200">{comm.name}</span>
                      </div>
                      <div className="flex items-center gap-4">
                        <span className="font-extrabold text-slate-800 dark:text-white">{comm.current}</span>
                        <span className={`text-xs font-bold px-2 py-0.5 rounded ${
                          comm.trend === 'up' ? 'bg-emerald-500/10 text-emerald-500' :
                          comm.trend === 'down' ? 'bg-rose-500/10 text-rose-500' :
                          'bg-slate-100 text-slate-500'
                        }`}>
                          {comm.change}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Place Bid Modal */}
      <AnimatePresence>
        {selectedListingId && selectedListing && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white dark:bg-brand-cardDark p-6 rounded-2xl shadow-glass border border-slate-200 dark:border-slate-800/80 w-full max-w-md relative"
            >
              <button
                onClick={() => setSelectedListingId(null)}
                className="absolute top-4 right-4 text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>

              <h4 className="font-bold text-base mb-2 text-slate-800 dark:text-white">Submit Marketplace Offer</h4>
              <p className="text-xs text-slate-400 mb-4">
                Category: <b>{selectedListing.type}</b> ({selectedListing.quantity})
              </p>

              <form onSubmit={handleBidSubmit} className="space-y-4">
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="text-xs text-slate-400 font-semibold uppercase">Your Bid Amount (₹)</label>
                    <span className="text-xs text-slate-400 font-medium">Minimum: &gt; ₹{selectedListing.currentBid}</span>
                  </div>
                  <input
                    type="number"
                    required
                    value={bidAmount}
                    onChange={e => setBidAmount(Number(e.target.value))}
                    min={selectedListing.currentBid + 1}
                    className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-white rounded-xl border border-slate-200 dark:border-slate-700 font-bold text-lg focus:outline-none focus:border-eco-500"
                  />
                </div>

                <button
                  type="submit"
                  id="btn-confirm-bid"
                  className="w-full py-3 rounded-xl bg-eco-500 hover:bg-eco-600 text-white font-bold text-xs shadow-md active:scale-98 transition-all flex items-center justify-center gap-1.5"
                >
                  <Gavel className="w-3.5 h-3.5" /> Submit Auction Bid
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
