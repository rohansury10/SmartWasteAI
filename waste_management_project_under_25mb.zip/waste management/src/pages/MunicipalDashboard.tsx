import React, { useEffect, useRef, useState } from 'react';
import {
  Activity, BarChart3, Map, Battery, Thermometer,
  Wind, Navigation, AlertOctagon,
  Sparkles, CheckCircle2
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Line } from 'react-chartjs-2';
import L from 'leaflet';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

export const MunicipalDashboard: React.FC = () => {
  const {
    smartBins,
    trucks,
    pickups,
    missedPickups,
    assignTruckToPickup,
    autoDispatchTruckToMissedPickup,
    emptyBin,
    triggerRouteOptimization,
    cityWideCoverageScore,
    isSimulating,
    setIsSimulating,
    simulationSpeed,
    setSimulationSpeed
  } = useApp();

  const [activeSubTab, setActiveSubTab] = useState<'map' | 'bins' | 'routes' | 'analytics'>('map');
  const [selectedTruckId, setSelectedTruckId] = useState<string>('TRK-901');
  const municipalMapRef = useRef<L.Map | null>(null);
  const truckMarkersRef = useRef<{ [id: string]: L.Marker }>({});

  // Stats Counters
  const warningBinsCount = smartBins.filter(b => b.status === 'Warning').length;
  const criticalBinsCount = smartBins.filter(b => b.status === 'Critical').length;
  const pendingCitizenPickups = pickups.filter(p => p.status === 'Pending');
  const pendingMissedPickups = missedPickups.filter(m => m.status === 'Reported');
  const activeTrucksCount = trucks.filter(t => t.status === 'Collecting' || t.status === 'In Transit').length;

  const selectedTruck = trucks.find(t => t.id === selectedTruckId) || trucks[0];

  // Initialize and update Live City Map
  useEffect(() => {
    if (activeSubTab === 'map') {
      const timer = setTimeout(() => {
        if (municipalMapRef.current) {
          municipalMapRef.current.remove();
          municipalMapRef.current = null;
        }

        const mapContainer = document.getElementById('municipal-city-map');
        if (!mapContainer) return;

        const map = L.map('municipal-city-map', {
          zoomControl: true,
          scrollWheelZoom: true
        }).setView([21.1750, 72.8050], 13);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: '&copy; OpenStreetMap contributors'
        }).addTo(map);

        truckMarkersRef.current = {};

        // 1. Render Route Paths for all trucks
        trucks.forEach(t => {
          if (t.routePath && t.routePath.length > 0) {
            L.polyline(t.routePath, {
              color: t.id === selectedTruckId ? '#2563eb' : '#94a3b8',
              weight: t.id === selectedTruckId ? 4 : 2,
              opacity: t.id === selectedTruckId ? 0.85 : 0.4,
              dashArray: '6, 6'
            }).addTo(map);
          }
        });

        // 2. Render Smart IoT Bins
        smartBins.forEach(bin => {
          const color = bin.status === 'Critical' ? '#e11d48' : bin.status === 'Warning' ? '#f59e0b' : '#10b981';
          const binMarker = L.circleMarker([bin.lat, bin.lng], {
            radius: bin.status === 'Critical' ? 10 : 8,
            fillColor: color,
            color: '#ffffff',
            weight: 2,
            opacity: 1,
            fillOpacity: 0.85
          }).addTo(map);

          binMarker.bindPopup(`
            <div class="text-xs font-sans space-y-1">
              <p class="font-extrabold text-slate-800">${bin.id} (${bin.zone})</p>
              <p class="text-slate-500">${bin.address}</p>
              <p>Fill Level: <b>${bin.fillPercentage}%</b></p>
              <p>Methane: <b>${bin.methane} ppm</b></p>
              <p>Temperature: <b>${bin.temperature}°C</b></p>
            </div>
          `);
        });

        // 3. Render Trucks
        trucks.forEach(t => {
          const truckIcon = L.divIcon({
            html: `
              <div class="relative flex items-center justify-center">
                <div class="w-10 h-10 rounded-full ${
                  t.status === 'Transfer Station' ? 'bg-amber-600' : 'bg-blue-600'
                } border-2 border-white flex items-center justify-center text-white text-base shadow-xl">
                  🚚
                </div>
                <div class="absolute -top-6 px-1.5 py-0.5 bg-slate-900/90 text-white text-[9px] font-black rounded whitespace-nowrap shadow">
                  ${t.id}
                </div>
              </div>
            `,
            className: 'custom-fleet-marker',
            iconSize: [40, 40],
            iconAnchor: [20, 20]
          });

          const marker = L.marker([t.lat, t.lng], { icon: truckIcon })
            .addTo(map)
            .bindPopup(`
              <div class="text-xs font-sans space-y-1">
                <b class="text-blue-600">${t.id} - ${t.driverName}</b>
                <p>Ward: ${t.ward}</p>
                <p>Plate: <b>${t.licensePlate}</b></p>
                <p>Status: <b>${t.status}</b></p>
                <p>Speed: <b>${t.speed} km/h</b></p>
                <p>Capacity: <b>${t.capacity}% full</b></p>
              </div>
            `);

          marker.on('click', () => {
            setSelectedTruckId(t.id);
          });

          truckMarkersRef.current[t.id] = marker;
        });

        // 4. Render Missed Pickups
        missedPickups.forEach(incident => {
          if (incident.status !== 'Resolved') {
            L.marker([incident.lat, incident.lng], {
              icon: L.divIcon({
                html: `
                  <div class="w-8 h-8 rounded-full bg-rose-600 border-2 border-white flex items-center justify-center text-white text-sm shadow-md animate-bounce">
                    ⚠️
                  </div>
                `,
                className: 'custom-incident-marker',
                iconSize: [32, 32],
                iconAnchor: [16, 16]
              })
            }).addTo(map).bindPopup(`
              <div class="text-xs font-sans">
                <b class="text-rose-600">Missed Pickup: ${incident.id}</b>
                <p>${incident.address}</p>
                <p>Reason: ${incident.reason}</p>
                <p>Status: <b>${incident.status}</b></p>
              </div>
            `);
          }
        });

        municipalMapRef.current = map;
      }, 150);

      return () => {
        clearTimeout(timer);
        if (municipalMapRef.current) {
          municipalMapRef.current.remove();
          municipalMapRef.current = null;
        }
      };
    }
  }, [activeSubTab, selectedTruckId, smartBins, missedPickups]);

  // Update truck marker positions smoothly
  useEffect(() => {
    trucks.forEach(t => {
      const marker = truckMarkersRef.current[t.id];
      if (marker) {
        marker.setLatLng([t.lat, t.lng]);
      }
    });
  }, [trucks]);

  // Waste forecasting line chart
  const lineChartData = {
    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun (Est)'],
    datasets: [
      {
        label: 'Dry Recyclables Collected (Tons)',
        data: [42, 48, 51, 46, 55, 62, 68],
        borderColor: '#10b981',
        backgroundColor: 'rgba(16, 185, 129, 0.1)',
        fill: true,
        tension: 0.35
      },
      {
        label: 'Organic Compost Collected (Tons)',
        data: [35, 38, 42, 40, 47, 49, 53],
        borderColor: '#0284c7',
        backgroundColor: 'rgba(2, 132, 199, 0.08)',
        fill: true,
        tension: 0.35
      }
    ]
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { position: 'top' as const }
    },
    scales: {
      y: { grid: { color: 'rgba(0,0,0,0.05)' } },
      x: { grid: { display: false } }
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Top Telemetry KPI Bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-5 rounded-3xl bg-white dark:bg-brand-cardDark border border-slate-200/80 dark:border-slate-800/80 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-blue-500/10 text-blue-600 flex items-center justify-center text-xl font-black">
            🚚
          </div>
          <div>
            <span className="text-[11px] text-slate-400 font-bold uppercase tracking-wider block">Fleet In Action</span>
            <span className="text-2xl font-black text-slate-800 dark:text-white">
              {activeTrucksCount} / {trucks.length} Trucks
            </span>
          </div>
        </div>

        <div className="p-5 rounded-3xl bg-white dark:bg-brand-cardDark border border-slate-200/80 dark:border-slate-800/80 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-600 flex items-center justify-center text-xl font-black">
            ⚡
          </div>
          <div>
            <span className="text-[11px] text-slate-400 font-bold uppercase tracking-wider block">City Coverage</span>
            <span className="text-2xl font-black text-emerald-600 dark:text-emerald-400">
              {cityWideCoverageScore}%
            </span>
          </div>
        </div>

        <div className="p-5 rounded-3xl bg-white dark:bg-brand-cardDark border border-slate-200/80 dark:border-slate-800/80 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-rose-500/10 text-rose-600 flex items-center justify-center text-xl font-black">
            🚨
          </div>
          <div>
            <span className="text-[11px] text-slate-400 font-bold uppercase tracking-wider block">Critical IoT Bins</span>
            <span className="text-2xl font-black text-slate-800 dark:text-white">
              {criticalBinsCount} <span className="text-xs text-slate-400 font-normal">({warningBinsCount} warning)</span>
            </span>
          </div>
        </div>

        <div className="p-5 rounded-3xl bg-white dark:bg-brand-cardDark border border-slate-200/80 dark:border-slate-800/80 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/10 text-amber-600 flex items-center justify-center text-xl font-black">
            ⚠️
          </div>
          <div>
            <span className="text-[11px] text-slate-400 font-bold uppercase tracking-wider block">Missed Pickups</span>
            <span className="text-2xl font-black text-slate-800 dark:text-white">
              {pendingMissedPickups.length} Pending
            </span>
          </div>
        </div>
      </div>

      {/* Simulation Controls & Subtabs Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-brand-cardDark p-2 rounded-2xl border border-slate-200/80 dark:border-slate-800/80 shadow-sm">
        <div className="flex overflow-x-auto gap-1">
          {[
            { id: 'map', label: 'Live Fleet Radar', icon: <Map className="w-4 h-4" /> },
            { id: 'bins', label: 'IoT Smart Bins', icon: <Activity className="w-4 h-4" /> },
            { id: 'routes', label: 'AI Route Optimizer', icon: <Navigation className="w-4 h-4" /> },
            { id: 'analytics', label: 'Forecasting & Fuel', icon: <BarChart3 className="w-4 h-4" /> }
          ].map(sub => (
            <button
              key={sub.id}
              onClick={() => setActiveSubTab(sub.id as any)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all shrink-0 ${
                activeSubTab === sub.id
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/50'
              }`}
            >
              {sub.icon}
              {sub.label}
            </button>
          ))}
        </div>

        {/* Simulation Speed Controls */}
        <div className="flex items-center gap-2 px-3 py-1 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/60 dark:border-slate-700/60 text-xs">
          <span className="text-slate-400 font-semibold text-[11px]">GPS Simulation:</span>
          <button
            onClick={() => setIsSimulating(!isSimulating)}
            className={`px-2 py-0.5 rounded font-extrabold text-[10px] ${
              isSimulating ? 'bg-emerald-500 text-white' : 'bg-slate-300 dark:bg-slate-700 text-slate-600'
            }`}
          >
            {isSimulating ? 'Active' : 'Paused'}
          </button>
          <div className="flex items-center gap-1 border-l border-slate-200 dark:border-slate-700 pl-2">
            {[1, 2, 5].map(speed => (
              <button
                key={speed}
                onClick={() => setSimulationSpeed(speed)}
                className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                  simulationSpeed === speed
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-400 hover:text-slate-600'
                }`}
              >
                {speed}x
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* SUBTAB 1: LIVE MULTI-FLEET RADAR MAP */}
      {activeSubTab === 'map' && (
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main City Map */}
          <div className="lg:col-span-2 space-y-4">
            <div className="bg-white dark:bg-brand-cardDark p-4 rounded-3xl border border-slate-200/80 dark:border-slate-800/80 shadow-sm">
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-blue-500 animate-pulse" />
                  <h3 className="font-extrabold text-sm text-slate-800 dark:text-white">
                    Municipal Fleet Operations Grid
                  </h3>
                </div>
                <div className="flex items-center gap-2 text-xs font-semibold text-slate-500">
                  <span>Selected Truck:</span>
                  <span className="px-2 py-0.5 rounded-lg bg-blue-500/10 text-blue-600 font-black border border-blue-500/20">
                    {selectedTruck.id}
                  </span>
                </div>
              </div>

              {/* Map Container */}
              <div
                id="municipal-city-map"
                className="w-full h-[520px] rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700 shadow-inner"
              />

              {/* Legend */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-3 mt-3 text-[11px] text-slate-500">
                <div className="flex items-center gap-4">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-blue-600 inline-block" /> Active Fleet Truck
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block" /> Normal Bin (&lt;75%)
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block" /> Warning Bin (75-89%)
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-600 inline-block" /> Critical Bin (≥90%)
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block" /> Missed Pickup Flag
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Fleet Selector & Dispatch Actions */}
          <div className="space-y-4">
            {/* Selected Truck Card */}
            <div className="p-5 rounded-3xl bg-white dark:bg-brand-cardDark border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-extrabold text-sm text-slate-800 dark:text-white">
                    {selectedTruck.id} Telemetry
                  </h4>
                  <span className="text-[11px] text-slate-400">{selectedTruck.licensePlate} • {selectedTruck.ward}</span>
                </div>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                  selectedTruck.status === 'Collecting' ? 'bg-emerald-500/10 text-emerald-600' : 'bg-blue-500/10 text-blue-600'
                }`}>
                  {selectedTruck.status}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-100 dark:border-slate-800 text-xs">
                <div>
                  <span className="text-slate-400 text-[10px] uppercase font-bold block">Driver</span>
                  <span className="font-bold text-slate-700 dark:text-slate-300">{selectedTruck.driverName}</span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] uppercase font-bold block">Speed</span>
                  <span className="font-bold text-slate-700 dark:text-slate-300">{selectedTruck.speed} km/h</span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] uppercase font-bold block">Capacity Load</span>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <div className="w-16 bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden">
                      <div className="h-full bg-blue-600 rounded-full" style={{ width: `${selectedTruck.capacity}%` }} />
                    </div>
                    <span className="font-bold">{selectedTruck.capacity}%</span>
                  </div>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] uppercase font-bold block">Fuel / Battery</span>
                  <span className="font-bold text-emerald-600">{selectedTruck.fuelLevel.toFixed(1)}% ({selectedTruck.fuelType})</span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] uppercase font-bold block">Distance Today</span>
                  <span className="font-bold">{selectedTruck.distanceTraveledKm} km</span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] uppercase font-bold block">CO₂ Saved</span>
                  <span className="font-bold text-teal-600">{selectedTruck.co2SavedKg} kg</span>
                </div>
              </div>

              {/* Truck Selector Pills */}
              <div>
                <span className="text-[11px] text-slate-400 font-bold uppercase tracking-wider block mb-2">
                  Select Fleet Unit:
                </span>
                <div className="grid grid-cols-2 gap-2">
                  {trucks.map(t => (
                    <button
                      key={t.id}
                      onClick={() => setSelectedTruckId(t.id)}
                      className={`p-2.5 rounded-xl text-left text-xs font-bold border transition-all ${
                        selectedTruckId === t.id
                          ? 'bg-blue-600 text-white border-blue-600 shadow-md'
                          : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      <div className="flex justify-between items-center">
                        <span>{t.id}</span>
                        <span className="text-[10px] font-normal opacity-80">{t.fuelType}</span>
                      </div>
                      <span className="text-[10px] font-normal block opacity-80 truncate">{t.driverName}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Pending Missed Pickups Fast Dispatch Queue */}
            <div className="p-5 rounded-3xl bg-white dark:bg-brand-cardDark border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-extrabold text-xs text-slate-800 dark:text-white flex items-center gap-1.5">
                  <AlertOctagon className="w-4 h-4 text-rose-600" /> Missed Pickup Alerts ({pendingMissedPickups.length})
                </h4>
              </div>

              <div className="space-y-2.5 max-h-52 overflow-y-auto pr-1">
                {pendingMissedPickups.length === 0 ? (
                  <div className="p-4 text-center text-slate-400 text-xs bg-slate-50 dark:bg-slate-800/30 rounded-2xl">
                    No active missed pickups reported.
                  </div>
                ) : (
                  pendingMissedPickups.map(incident => (
                    <div
                      key={incident.id}
                      className="p-3 rounded-2xl bg-rose-50/50 dark:bg-rose-950/20 border border-rose-200/50 dark:border-rose-800/40 text-xs space-y-2"
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-bold text-slate-800 dark:text-white">{incident.citizenName}</p>
                          <p className="text-[10px] text-slate-500">{incident.address}</p>
                        </div>
                        <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-rose-500 text-white">
                          SLA: {incident.slaMinutes}m
                        </span>
                      </div>
                      <button
                        onClick={() => autoDispatchTruckToMissedPickup(incident.id)}
                        className="w-full py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-[11px] transition-all shadow-sm flex items-center justify-center gap-1"
                      >
                        ⚡ 1-Click Auto-Dispatch Truck
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Pending Citizen Pickups Queue */}
            <div className="p-5 rounded-3xl bg-white dark:bg-brand-cardDark border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-3">
              <h4 className="font-extrabold text-xs text-slate-800 dark:text-white flex items-center gap-1.5">
                📥 On-Demand Citizen Requests ({pendingCitizenPickups.length})
              </h4>
              <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                {pendingCitizenPickups.length === 0 ? (
                  <div className="p-4 text-center text-slate-400 text-xs bg-slate-50 dark:bg-slate-800/30 rounded-2xl">
                    All on-demand pickups dispatched.
                  </div>
                ) : (
                  pendingCitizenPickups.map(p => (
                    <div
                      key={p.id}
                      className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/50 text-xs space-y-2"
                    >
                      <div className="flex justify-between">
                        <span className="font-bold text-slate-800 dark:text-white">{p.citizenName}</span>
                        <span className="font-bold text-blue-600">{p.type} • {p.weight}kg</span>
                      </div>
                      <div className="flex items-center justify-between pt-1">
                        <span className="text-[10px] text-slate-400">Assign to:</span>
                        <div className="flex gap-1">
                          {trucks.slice(0, 2).map(t => (
                            <button
                              key={t.id}
                              onClick={() => assignTruckToPickup(p.id, t.id)}
                              className="px-2 py-0.5 rounded bg-blue-600 text-white font-bold text-[10px]"
                            >
                              {t.id}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 2: IOT SMART BINS */}
      {activeSubTab === 'bins' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center bg-white dark:bg-brand-cardDark p-6 rounded-3xl border border-slate-200/80 dark:border-slate-800/80 shadow-sm">
            <div>
              <h3 className="text-lg font-black text-slate-900 dark:text-white">
                IoT Sensor Telemetry Grid (Surat Smart City)
              </h3>
              <p className="text-xs text-slate-500">
                Real-time ultrasonic fill-level monitors, methane leak detection, and battery levels.
              </p>
            </div>
          </div>

          <div className="overflow-hidden rounded-3xl border border-slate-200/80 dark:border-slate-800/80 shadow-sm bg-white dark:bg-brand-cardDark">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50/80 dark:bg-slate-800/80 border-b border-slate-200/60 dark:border-slate-700/60 text-xs font-bold text-slate-400 uppercase">
                    <th className="p-4">Bin Identifier</th>
                    <th className="p-4">Ward / Landmark</th>
                    <th className="p-4 text-center">Fill Rate</th>
                    <th className="p-4 text-center">Methane Level</th>
                    <th className="p-4 text-center">Temp / Humidity</th>
                    <th className="p-4 text-center">Battery</th>
                    <th className="p-4 text-center">Status</th>
                    <th className="p-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                  {smartBins.map(bin => (
                    <tr key={bin.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                      <td className="p-4 font-black text-slate-800 dark:text-slate-200">{bin.id}</td>
                      <td className="p-4">
                        <span className="font-bold block text-slate-800 dark:text-white">{bin.zone}</span>
                        <span className="text-[10px] text-slate-400">{bin.address}</span>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center justify-center gap-2">
                          <div className="w-20 bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                            <div
                              className={`h-full rounded-full ${
                                bin.fillPercentage >= 90 ? 'bg-rose-600' : bin.fillPercentage >= 75 ? 'bg-amber-500' : 'bg-emerald-500'
                              }`}
                              style={{ width: `${bin.fillPercentage}%` }}
                            />
                          </div>
                          <span className="font-extrabold w-8 text-right">{bin.fillPercentage}%</span>
                        </div>
                      </td>
                      <td className="p-4 text-center">
                        <span className={`inline-flex items-center gap-1 font-bold ${
                          bin.methane > 50 ? 'text-rose-600' : 'text-slate-600 dark:text-slate-400'
                        }`}>
                          <Wind className="w-3 h-3" /> {bin.methane} ppm
                        </span>
                      </td>
                      <td className="p-4 text-center">
                        <span className="flex items-center justify-center gap-1 text-slate-600 dark:text-slate-400">
                          <Thermometer className="w-3 h-3" /> {bin.temperature}°C / {bin.humidity}%
                        </span>
                      </td>
                      <td className="p-4 text-center">
                        <span className="flex items-center justify-center gap-1 font-semibold text-emerald-600">
                          <Battery className="w-3.5 h-3.5" /> {bin.battery}%
                        </span>
                      </td>
                      <td className="p-4 text-center">
                        <span className={`text-[10px] font-black px-2 py-0.5 rounded-full uppercase ${
                          bin.status === 'Critical' ? 'bg-rose-500/10 text-rose-600' :
                          bin.status === 'Warning' ? 'bg-amber-500/10 text-amber-600' :
                          'bg-emerald-500/10 text-emerald-600'
                        }`}>
                          {bin.status}
                        </span>
                      </td>
                      <td className="p-4 text-right">
                        <button
                          onClick={() => emptyBin(bin.id)}
                          className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-emerald-600 hover:text-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold transition-all"
                        >
                          Clear Bin
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 3: AI ROUTE OPTIMIZER */}
      {activeSubTab === 'routes' && (
        <div className="grid md:grid-cols-3 gap-6">
          {/* Controls */}
          <div className="md:col-span-1 p-6 rounded-3xl bg-white dark:bg-brand-cardDark border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-5">
            <div>
              <span className="px-2.5 py-1 rounded-full bg-blue-500/10 text-blue-600 text-[10px] font-bold uppercase tracking-wider inline-block mb-2">
                Neural Dynamic Routing
              </span>
              <h3 className="text-lg font-black text-slate-900 dark:text-white">SmartWaste AI Engine</h3>
              <p className="text-xs text-slate-500 mt-1">
                Optimizes vehicle routes in real-time by ingesting IoT bin fill rates, traffic conditions, citizen on-demand requests, and battery constraints.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-blue-50/50 dark:bg-blue-950/20 border border-blue-200/50 dark:border-blue-800/40 space-y-3 text-xs">
              <div className="flex justify-between items-center">
                <span className="text-slate-500">Route Distance Reduction:</span>
                <span className="font-black text-emerald-600">-28.4% Kilometers</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500">Fuel & Energy Saved:</span>
                <span className="font-black text-blue-600">+34.2% Efficiency</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500">Overflow Bin Prioritization:</span>
                <span className="font-black text-amber-500">Active (Critical First)</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500">CO₂ Avoided Today:</span>
                <span className="font-black text-teal-600">112.6 kg CO₂</span>
              </div>
            </div>

            <button
              onClick={triggerRouteOptimization}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-extrabold text-xs shadow-lg shadow-blue-600/25 transition-all flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4" /> Recalculate & Push AI Route Optimization
            </button>
          </div>

          {/* Active Driver Schedules */}
          <div className="md:col-span-2 space-y-4">
            <h3 className="text-base font-black text-slate-800 dark:text-white">Active Fleet Routes & Waypoints</h3>
            <div className="grid sm:grid-cols-2 gap-4">
              {trucks.map(t => (
                <div
                  key={t.id}
                  className="p-5 rounded-3xl bg-white dark:bg-brand-cardDark border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-3"
                >
                  <div className="flex justify-between items-center">
                    <div>
                      <h4 className="font-black text-sm text-slate-800 dark:text-white">{t.id} - {t.driverName}</h4>
                      <span className="text-[10px] text-slate-400">{t.ward}</span>
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-blue-500/10 text-blue-600 font-bold border border-blue-500/20">
                      {t.routeStops.length} stops
                    </span>
                  </div>

                  <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1 text-xs">
                    {t.routeStops.map((stop, idx) => (
                      <div
                        key={idx}
                        className={`p-2 rounded-xl flex items-center justify-between ${
                          stop.completed
                            ? 'bg-slate-50 dark:bg-slate-800/30 text-slate-400 line-through'
                            : 'bg-slate-100/70 dark:bg-slate-800/70 text-slate-700 dark:text-slate-300 font-medium'
                        }`}
                      >
                        <span className="truncate pr-2">{idx + 1}. {stop.name}</span>
                        {stop.completed ? (
                          <CheckCircle2 className="w-3 h-3 text-emerald-500 shrink-0" />
                        ) : (
                          <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-ping shrink-0" />
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 4: ANALYTICS & FORECASTING */}
      {activeSubTab === 'analytics' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-brand-cardDark p-6 rounded-3xl border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-lg font-black text-slate-900 dark:text-white">
                  Waste Generation & Collection Forecasting
                </h3>
                <p className="text-xs text-slate-500">
                  Predictive collection curve generated from historical weighbridge logs and IoT fill rate models.
                </p>
              </div>
              <span className="text-xs font-bold text-emerald-600 bg-emerald-500/10 px-3 py-1 rounded-full">
                AI Accuracy: 96.8%
              </span>
            </div>

            <div className="h-80 w-full pt-4">
              <Line data={lineChartData} options={chartOptions} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
