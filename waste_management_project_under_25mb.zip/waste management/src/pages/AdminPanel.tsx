import React, { useEffect, useState } from 'react';
import {
  ShieldCheck, AlertTriangle, CheckCircle2,
  TrendingUp, Leaf, Fuel, Timer,
  Sparkles, Terminal, Activity, Layers
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

export const AdminPanel: React.FC = () => {
  const {
    trucks,
    missedPickups,
    autoDispatchTruckToMissedPickup,
    resolveMissedPickup,
    wardCoverageList,
    cityWideCoverageScore,
    notifications,
    triggerRouteOptimization
  } = useApp();

  const [activeTab, setActiveTab] = useState<'coverage' | 'missed' | 'efficiency' | 'telemetry'>('coverage');
  const [logs, setLogs] = useState<string[]>([
    'SmartWaste AI Master Cluster: Fleet tracking server connected [Active 4/4 nodes]',
    'GIS Service: Polyline telemetry stream active for Ward 1 to Ward 5',
    'IoT Sensor Gateway: 6 ultrasonic bins sending telemetry at 10s intervals',
    'SLA Engine: Missed pickup incident recovery protocol active (Max SLA 45m)'
  ]);

  // Feed notifications into telemetry log
  useEffect(() => {
    if (notifications.length > 0) {
      const latest = notifications[0];
      setLogs(prev => [
        `[${latest.time}] ${latest.type.toUpperCase()}: ${latest.title} - ${latest.message}`,
        ...prev.slice(0, 15)
      ]);
    }
  }, [notifications]);

  // Aggregate fleet totals
  const totalKmToday = trucks.reduce((acc, t) => acc + t.distanceTraveledKm, 0).toFixed(1);
  const totalFuelSaved = trucks.reduce((acc, t) => acc + t.fuelSavedLiters, 0).toFixed(1);
  const totalCo2Saved = trucks.reduce((acc, t) => acc + t.co2SavedKg, 0).toFixed(1);
  const pendingMissedCount = missedPickups.filter(m => m.status === 'Reported').length;
  const dispatchedMissedCount = missedPickups.filter(m => m.status === 'Dispatched').length;

  // Efficiency Comparison Chart Data (Traditional vs SmartWaste AI)
  const efficiencyChartData = {
    labels: ['Ward 1 VIP', 'Ward 2 Adajan', 'Ward 3 Varachha', 'Ward 4 Pal', 'Ward 5 Central'],
    datasets: [
      {
        label: 'Static Legacy Route (Fuel Litres / Day)',
        data: [28, 34, 40, 26, 32],
        backgroundColor: 'rgba(239, 68, 68, 0.7)',
        borderRadius: 8
      },
      {
        label: 'SmartWaste AI Route (Fuel Litres / Day)',
        data: [18, 22, 27, 16, 21],
        backgroundColor: 'rgba(16, 185, 129, 0.85)',
        borderRadius: 8
      }
    ]
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { position: 'top' as const }
    },
    scales: {
      y: {
        grid: { color: 'rgba(0,0,0,0.05)' },
        title: { display: true, text: 'Fuel / Energy Units Consumed' }
      },
      x: { grid: { display: false } }
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* City Admin Header Banner */}
      <div className="bg-slate-900 dark:bg-brand-cardDark rounded-3xl p-6 text-white border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 border border-emerald-500/30">
              <ShieldCheck className="w-3.5 h-3.5" />
              Municipal Command & Control
            </span>
          </div>
          <h1 className="text-2xl md:text-3xl font-black tracking-tight">
            City Executive Waste Operations Center
          </h1>
          <p className="text-slate-400 text-xs md:text-sm max-w-2xl mt-1">
            Real-time oversight over citywide fleet coverage, rapid recovery of missed citizen pickups, and AI-driven route efficiency analytics.
          </p>
        </div>

        {/* Global Efficiency Rating */}
        <div className="flex items-center gap-4 bg-slate-800/80 p-4 rounded-2xl border border-slate-700/60 shrink-0">
          <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xl font-black">
            ⚡
          </div>
          <div>
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Citywide Coverage</span>
            <span className="text-2xl font-black text-emerald-400">{cityWideCoverageScore}%</span>
            <span className="text-[10px] text-slate-400 block">Target SLA: &gt;90%</span>
          </div>
        </div>
      </div>

      {/* Admin KPI Quick Counters */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-5 rounded-3xl bg-white dark:bg-brand-cardDark border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[11px] text-slate-400 font-bold uppercase tracking-wider">Fleet Coverage</span>
            <Layers className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">{cityWideCoverageScore}%</span>
            <span className="text-xs font-bold text-emerald-600">Optimal</span>
          </div>
          <span className="text-[10px] text-slate-400 block">Across 5 municipal wards</span>
        </div>

        <div className="p-5 rounded-3xl bg-white dark:bg-brand-cardDark border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[11px] text-slate-400 font-bold uppercase tracking-wider">Missed Pickups</span>
            <AlertTriangle className="w-4 h-4 text-rose-500" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black text-rose-600">{pendingMissedCount}</span>
            <span className="text-xs text-slate-400 font-semibold">({dispatchedMissedCount} dispatched)</span>
          </div>
          <span className="text-[10px] text-slate-400 block">Average recovery SLA: 18m</span>
        </div>

        <div className="p-5 rounded-3xl bg-white dark:bg-brand-cardDark border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[11px] text-slate-400 font-bold uppercase tracking-wider">Fuel & Energy Saved</span>
            <Fuel className="w-4 h-4 text-blue-500" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black text-blue-600">{totalFuelSaved} L</span>
            <span className="text-xs font-bold text-blue-500">+34% saved</span>
          </div>
          <span className="text-[10px] text-slate-400 block">via AI dynamic routing</span>
        </div>

        <div className="p-5 rounded-3xl bg-white dark:bg-brand-cardDark border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[11px] text-slate-400 font-bold uppercase tracking-wider">CO₂ Offset Today</span>
            <Leaf className="w-4 h-4 text-teal-500" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black text-teal-600">{totalCo2Saved} kg</span>
            <span className="text-xs font-bold text-teal-500">{totalKmToday} km driven</span>
          </div>
          <span className="text-[10px] text-slate-400 block">Green smart city fleet</span>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex bg-white dark:bg-brand-cardDark p-1.5 rounded-2xl border border-slate-200/80 dark:border-slate-800/80 shadow-sm overflow-x-auto gap-1">
        {[
          { id: 'coverage', label: 'Ward Fleet Coverage', icon: <Layers className="w-4 h-4" /> },
          { id: 'missed', label: 'Missed Pickups Queue', count: pendingMissedCount, icon: <AlertTriangle className="w-4 h-4" /> },
          { id: 'efficiency', label: 'Route Efficiency & AI Savings', icon: <TrendingUp className="w-4 h-4" /> },
          { id: 'telemetry', label: 'Live Telemetry Stream', icon: <Terminal className="w-4 h-4" /> }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all shrink-0 ${
              activeTab === tab.id
                ? 'bg-slate-900 dark:bg-slate-800 text-white shadow-md'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/50'
            }`}
          >
            {tab.icon}
            {tab.label}
            {tab.count !== undefined && tab.count > 0 && (
              <span className="px-1.5 py-0.5 text-[10px] rounded-full bg-rose-600 text-white font-black ml-0.5">
                {tab.count}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* TAB 1: WARD FLEET COVERAGE MONITOR */}
      {activeTab === 'coverage' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-brand-cardDark p-6 rounded-3xl border border-slate-200/80 dark:border-slate-800/80 shadow-sm">
            <div>
              <h3 className="text-lg font-black text-slate-900 dark:text-white">
                Municipal Ward Coverage Monitor
              </h3>
              <p className="text-xs text-slate-500">
                Live collection completion rate across residential, commercial, and industrial zones.
              </p>
            </div>
            <button
              onClick={triggerRouteOptimization}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-emerald-600/20 transition-all"
            >
              <Sparkles className="w-3.5 h-3.5" /> Re-balance Fleet Coverage
            </button>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {wardCoverageList.map((ward, idx) => (
              <div
                key={idx}
                className="p-5 rounded-3xl bg-white dark:bg-brand-cardDark border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-4 hover:shadow-md transition-all"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-extrabold text-sm text-slate-800 dark:text-white">{ward.ward}</h4>
                    <span className="text-[11px] text-slate-400">
                      {ward.servicedBins} / {ward.totalBins} collection points completed
                    </span>
                  </div>
                  <span className={`text-[10px] font-black px-2.5 py-1 rounded-full uppercase ${
                    ward.status === 'Optimal' ? 'bg-emerald-500/10 text-emerald-600 border border-emerald-500/20' :
                    ward.status === 'In Progress' ? 'bg-blue-500/10 text-blue-600 border border-blue-500/20' :
                    'bg-rose-500/10 text-rose-600 border border-rose-500/20'
                  }`}>
                    {ward.status}
                  </span>
                </div>

                {/* Progress Bar */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-bold">
                    <span className="text-slate-400">Daily Coverage:</span>
                    <span className={ward.percent >= 90 ? 'text-emerald-600' : 'text-amber-500'}>
                      {ward.percent}%
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        ward.percent >= 95 ? 'bg-emerald-500' : ward.percent >= 90 ? 'bg-blue-500' : 'bg-rose-500'
                      }`}
                      style={{ width: `${ward.percent}%` }}
                    />
                  </div>
                </div>

                {/* Assigned Vehicle */}
                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                  <span className="text-slate-400">Assigned Fleet:</span>
                  <span className="font-bold text-slate-700 dark:text-slate-300">
                    {trucks[idx % trucks.length]?.id} ({trucks[idx % trucks.length]?.driverName})
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: MISSED PICKUPS RESOLUTION QUEUE */}
      {activeTab === 'missed' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-brand-cardDark p-6 rounded-3xl border border-slate-200/80 dark:border-slate-800/80 shadow-sm">
            <div>
              <h3 className="text-lg font-black text-slate-900 dark:text-white">
                Missed Pickup Incident Management Queue
              </h3>
              <p className="text-xs text-slate-500">
                Citizen reported skipped streets or delayed bins. Click auto-dispatch to dynamically divert the closest truck.
              </p>
            </div>
            <span className="text-xs font-bold px-3 py-1 rounded-full bg-rose-500/10 text-rose-600">
              {pendingMissedCount} Action Required
            </span>
          </div>

          <div className="overflow-hidden rounded-3xl border border-slate-200/80 dark:border-slate-800/80 shadow-sm bg-white dark:bg-brand-cardDark">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50/80 dark:bg-slate-800/80 border-b border-slate-200/60 dark:border-slate-700/60 text-xs font-bold text-slate-400 uppercase">
                    <th className="p-4">Ticket ID</th>
                    <th className="p-4">Citizen & Location</th>
                    <th className="p-4">Waste Category</th>
                    <th className="p-4">Reported Time</th>
                    <th className="p-4 text-center">Remaining SLA</th>
                    <th className="p-4 text-center">Status</th>
                    <th className="p-4 text-right">Recovery Dispatch</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                  {missedPickups.map(incident => (
                    <tr key={incident.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                      <td className="p-4 font-mono font-bold text-slate-800 dark:text-slate-200">
                        {incident.id}
                      </td>
                      <td className="p-4">
                        <span className="font-bold block text-slate-800 dark:text-white">{incident.citizenName}</span>
                        <span className="text-[10px] text-slate-400 block">{incident.address}</span>
                        <span className="text-[10px] text-slate-500 italic block mt-0.5">"{incident.reason}"</span>
                      </td>
                      <td className="p-4 font-semibold text-slate-700 dark:text-slate-300">
                        {incident.wasteType}
                      </td>
                      <td className="p-4 text-slate-500">
                        {incident.reportedAt}
                      </td>
                      <td className="p-4 text-center font-bold">
                        <span className={`inline-flex items-center gap-1 ${
                          incident.slaMinutes <= 15 ? 'text-rose-600' : 'text-amber-500'
                        }`}>
                          <Timer className="w-3.5 h-3.5" /> {incident.slaMinutes} mins
                        </span>
                      </td>
                      <td className="p-4 text-center">
                        <span className={`text-[10px] font-black px-2.5 py-1 rounded-full uppercase ${
                          incident.status === 'Resolved' ? 'bg-emerald-500/10 text-emerald-600' :
                          incident.status === 'Dispatched' ? 'bg-blue-500/10 text-blue-600 animate-pulse' :
                          'bg-rose-500/10 text-rose-600'
                        }`}>
                          {incident.status}
                        </span>
                      </td>
                      <td className="p-4 text-right">
                        {incident.status === 'Reported' && (
                          <button
                            onClick={() => autoDispatchTruckToMissedPickup(incident.id)}
                            className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold transition-all shadow-sm flex items-center gap-1 ml-auto"
                          >
                            <Sparkles className="w-3.5 h-3.5" /> Auto-Dispatch
                          </button>
                        )}
                        {incident.status === 'Dispatched' && (
                          <button
                            onClick={() => resolveMissedPickup(incident.id)}
                            className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold transition-all shadow-sm flex items-center gap-1 ml-auto"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" /> Mark Cleared
                          </button>
                        )}
                        {incident.status === 'Resolved' && (
                          <span className="text-[11px] font-semibold text-emerald-600 flex items-center gap-1 justify-end">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Resolved
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: ROUTE EFFICIENCY & SUSTAINABILITY ANALYTICS */}
      {activeTab === 'efficiency' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-brand-cardDark p-6 rounded-3xl border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-lg font-black text-slate-900 dark:text-white">
                  Fleet Route Efficiency & Fuel Optimization Index
                </h3>
                <p className="text-xs text-slate-500">
                  Benchmarking fuel consumption and travel distance of SmartWaste AI dynamic routing vs static legacy municipal routes.
                </p>
              </div>
              <span className="text-xs font-extrabold px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-600 border border-emerald-500/20">
                Citywide Fuel Saved: 34.2%
              </span>
            </div>

            {/* Bar Chart */}
            <div className="h-80 w-full pt-4">
              <Bar data={efficiencyChartData} options={chartOptions} />
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-4">
            <div className="p-5 rounded-3xl bg-white dark:bg-brand-cardDark border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-2">
              <span className="text-xs text-slate-400 font-bold uppercase">Kilometers Bypassed</span>
              <h4 className="text-2xl font-black text-slate-900 dark:text-white">48.2 km / Day</h4>
              <p className="text-xs text-slate-500">
                Eliminated dead-heading and redundant street passes using real-time IoT bin fill triggers.
              </p>
            </div>

            <div className="p-5 rounded-3xl bg-white dark:bg-brand-cardDark border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-2">
              <span className="text-xs text-slate-400 font-bold uppercase">On-Time Collection Rate</span>
              <h4 className="text-2xl font-black text-emerald-600">97.8% Compliance</h4>
              <p className="text-xs text-slate-500">
                Timetable adherence measured across morning and afternoon residential collection shifts.
              </p>
            </div>

            <div className="p-5 rounded-3xl bg-white dark:bg-brand-cardDark border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-2">
              <span className="text-xs text-slate-400 font-bold uppercase">Average Missed Turnaround</span>
              <h4 className="text-2xl font-black text-blue-600">22.4 Minutes</h4>
              <p className="text-xs text-slate-500">
                From citizen mobile complaint to truck arrival on scene with automated re-routing.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: LIVE TELEMETRY & AUDIT STREAM */}
      {activeTab === 'telemetry' && (
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            <div className="p-6 rounded-3xl bg-slate-950 border border-slate-800 shadow-xl space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-emerald-400 animate-pulse" />
                  <h3 className="font-mono text-sm font-bold text-slate-200">
                    Live Telemetry Stream (MQTT &amp; GPS Telematics)
                  </h3>
                </div>
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
                  CONNECTED • 248 ms
                </span>
              </div>

              <div className="space-y-2 font-mono text-xs max-h-96 overflow-y-auto pr-2">
                {logs.map((line, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-slate-300">
                    <span className="text-slate-600 select-none">&gt;</span>
                    <span className="leading-relaxed">{line}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="p-6 rounded-3xl bg-white dark:bg-brand-cardDark border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-4">
              <h4 className="font-extrabold text-sm text-slate-800 dark:text-white flex items-center gap-2">
                <Activity className="w-4 h-4 text-blue-600" /> Infrastructure Health
              </h4>
              <div className="space-y-3 text-xs">
                <div className="flex justify-between items-center">
                  <span className="text-slate-500">GeoServer Spatial Nodes:</span>
                  <span className="font-bold text-emerald-600">Online (5/5)</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-500">MQTT Broker Latency:</span>
                  <span className="font-bold text-emerald-600">12 ms</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-500">Active Truck Telematics:</span>
                  <span className="font-bold text-blue-600">4 GPS streams</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-500">Security Encryption:</span>
                  <span className="font-bold text-slate-700 dark:text-slate-300">TLS 1.3 Strict</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
