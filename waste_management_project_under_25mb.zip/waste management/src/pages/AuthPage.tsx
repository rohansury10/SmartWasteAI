import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mail, Lock, LogIn, User, Truck, ShieldAlert, HeartHandshake, Building2, Smartphone } from 'lucide-react';
import type { UserRole } from '../context/AppContext';
import { useApp } from '../context/AppContext';

interface AuthPageProps {
  onLoginSuccess: () => void;
}

export const AuthPage: React.FC<AuthPageProps> = ({ onLoginSuccess }) => {
  const { setCurrentRole, setUser } = useApp();
  const [selectedRole, setSelectedRole] = useState<UserRole>('citizen');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [otpMode, setOtpMode] = useState(false);
  const [otpDigits, setOtpDigits] = useState(['', '', '', '']);
  const [loading, setLoading] = useState(false);

  // Pre-configured profiles for quick demo login
  const defaultCredentials: Record<Exclude<UserRole, 'guest'>, { email: string; name: string; avatar: string }> = {
    citizen: { email: 'citizen@smartwaste.ai', name: 'Aarav Patel', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=150' },
    driver: { email: 'driver@smartwaste.ai', name: 'Rajesh Sharma', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=150' },
    recycler: { email: 'recycler@smartwaste.ai', name: 'Greenlife Recyclers Inc.', avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&q=80&w=150' },
    municipality: { email: 'municipality@smartwaste.ai', name: 'Surat Municipal Corporation', avatar: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=150' },
    admin: { email: 'admin@smartwaste.ai', name: 'SmartWaste Administrator', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=150' }
  };

  const handleQuickCredentialSelect = () => {
    if (selectedRole !== 'guest') {
      setEmail(defaultCredentials[selectedRole].email);
      setPassword('password123');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    setTimeout(() => {
      setLoading(false);
      if (selectedRole !== 'guest') {
        const profile = defaultCredentials[selectedRole];
        setUser({
          name: profile.name,
          role: selectedRole,
          ecoCoins: selectedRole === 'citizen' ? 420 : 0,
          carbonSaved: selectedRole === 'citizen' ? 54.8 : 0,
          avatar: profile.avatar,
          ward: 'Ward 1 - VIP Road / Vesu',
          homeAddress: 'A-402 Shanti Niketan Apartments, VIP Road',
          homeCoords: { lat: 21.1662, lng: 72.7824 }
        });
      }
      setCurrentRole(selectedRole);
      onLoginSuccess();
    }, 1500);
  };

  const handleGoogleLogin = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      if (selectedRole !== 'guest') {
        const profile = defaultCredentials[selectedRole];
        setUser({
          name: profile.name,
          role: selectedRole,
          ecoCoins: selectedRole === 'citizen' ? 420 : 0,
          carbonSaved: selectedRole === 'citizen' ? 54.8 : 0,
          avatar: profile.avatar,
          ward: 'Ward 1 - VIP Road / Vesu',
          homeAddress: 'A-402 Shanti Niketan Apartments, VIP Road',
          homeCoords: { lat: 21.1662, lng: 72.7824 }
        });
      }
      setCurrentRole(selectedRole);
      onLoginSuccess();
    }, 1200);
  };

  const handleOtpDigitChange = (value: string, idx: number) => {
    if (/^[0-9]?$/.test(value)) {
      const nextOtp = [...otpDigits];
      nextOtp[idx] = value;
      setOtpDigits(nextOtp);

      // Auto focus next input
      if (value && idx < 3) {
        const nextInput = document.getElementById(`otp-${idx + 1}`);
        nextInput?.focus();
      }
    }
  };

  const roles = [
    { id: 'citizen', label: 'Citizen', icon: <User className="w-4 h-4" /> },
    { id: 'driver', label: 'Truck Driver', icon: <Truck className="w-4 h-4" /> },
    { id: 'recycler', label: 'Recycler', icon: <HeartHandshake className="w-4 h-4" /> },
    { id: 'municipality', label: 'Municipality', icon: <Building2 className="w-4 h-4" /> },
    { id: 'admin', label: 'Admin', icon: <ShieldAlert className="w-4 h-4" /> },
  ];

  return (
    <div className="min-h-screen flex items-center justify-center relative p-4 bg-slate-50 dark:bg-brand-dark overflow-hidden">
      {/* Background Orbs */}
      <div className="absolute top-10 left-10 w-72 h-72 bg-eco-500/10 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-80 h-80 bg-blue-500/10 rounded-full blur-[100px] pointer-events-none" />

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-xl rounded-3xl glass-panel border border-slate-200/50 dark:border-slate-800/40 p-6 md:p-8 shadow-glass relative z-10"
      >
        <div className="text-center mb-6">
          <div className="w-12 h-12 rounded-xl bg-eco-500 text-white flex items-center justify-center mx-auto text-2xl font-extrabold shadow-md mb-3">
            ♻️
          </div>
          <h2 className="text-2xl font-extrabold text-slate-800 dark:text-white">Sign In to EcoSync</h2>
          <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">Smart city portal access gateway</p>
        </div>

        {/* Role Selection bar */}
        <div className="mb-6">
          <span className="text-xs text-slate-400 dark:text-slate-500 font-semibold block mb-2 uppercase">Select Workspace Access</span>
          <div className="flex flex-wrap gap-2 bg-slate-100/80 dark:bg-brand-cardDark/80 p-1.5 rounded-xl border border-slate-200/30 dark:border-slate-800/30 justify-between">
            {roles.map(r => (
              <button
                key={r.id}
                onClick={() => {
                  setSelectedRole(r.id as UserRole);
                  setOtpMode(false);
                }}
                className={`flex items-center gap-1 px-3 py-2 rounded-lg text-xs font-bold transition-all ${
                  selectedRole === r.id
                    ? 'bg-eco-500 text-white shadow-md'
                    : 'text-slate-500 dark:text-slate-400 hover:bg-slate-200/50 dark:hover:bg-slate-800/50'
                }`}
              >
                {r.icon}
                {r.label}
              </button>
            ))}
          </div>
        </div>

        {/* Main form card */}
        <AnimatePresence mode="wait">
          {!otpMode ? (
            <motion.form
              key="password-form"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              onSubmit={handleSubmit}
              className="space-y-4"
            >
              <div>
                <label className="text-xs text-slate-400 font-semibold uppercase block mb-1">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-400" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    placeholder="name@ecosync.com"
                    className="w-full pl-10 pr-4 py-3 bg-white dark:bg-brand-cardDark text-slate-800 dark:text-white rounded-xl border border-slate-200 dark:border-slate-800 focus:outline-none focus:border-eco-500 text-sm shadow-sm transition-all"
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="text-xs text-slate-400 font-semibold uppercase">Password</label>
                  <a href="#" className="text-xs text-eco-600 hover:text-eco-500 font-semibold">Forgot?</a>
                </div>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-400" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-10 pr-4 py-3 bg-white dark:bg-brand-cardDark text-slate-800 dark:text-white rounded-xl border border-slate-200 dark:border-slate-800 focus:outline-none focus:border-eco-500 text-sm shadow-sm transition-all"
                  />
                </div>
              </div>

              {/* Login Button */}
              <button
                type="submit"
                disabled={loading}
                id="btn-auth-login"
                className="w-full py-3.5 rounded-xl bg-eco-500 hover:bg-eco-600 disabled:bg-slate-400 text-white font-bold flex items-center justify-center gap-2 shadow-lg hover:shadow-eco-500/20 active:scale-98 transition-all text-sm mt-6"
              >
                {loading ? (
                  <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    Sign In <LogIn className="w-4 h-4" />
                  </>
                )}
              </button>

              <div className="flex items-center justify-between text-xs text-slate-400 dark:text-slate-500 py-2">
                <button
                  type="button"
                  onClick={() => setOtpMode(true)}
                  className="flex items-center gap-1 hover:text-eco-500 font-semibold"
                >
                  <Smartphone className="w-3.5 h-3.5" /> Sign in with OTP / Mobile
                </button>
                <button
                  type="button"
                  onClick={handleQuickCredentialSelect}
                  className="text-eco-600 dark:text-eco-400 font-semibold hover:underline"
                >
                  ⚡ Auto-fill credentials
                </button>
              </div>
            </motion.form>
          ) : (
            <motion.div
              key="otp-form"
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              className="space-y-6 text-center"
            >
              <p className="text-sm text-slate-500 dark:text-slate-400">
                We sent a 4-digit verification code to your registered mobile device.
              </p>

              {/* Digits row */}
              <div className="flex justify-center gap-3 my-4">
                {otpDigits.map((dig, idx) => (
                  <input
                    key={idx}
                    id={`otp-${idx}`}
                    type="text"
                    maxLength={1}
                    value={dig}
                    onChange={e => handleOtpDigitChange(e.target.value, idx)}
                    className="w-14 h-14 bg-white dark:bg-brand-cardDark text-slate-800 dark:text-white text-center font-bold text-xl rounded-xl border border-slate-200 dark:border-slate-800 focus:outline-none focus:border-eco-500 shadow-sm"
                  />
                ))}
              </div>

              <div className="flex gap-4">
                <button
                  onClick={() => setOtpMode(false)}
                  className="flex-1 py-3 rounded-xl bg-slate-100 dark:bg-brand-cardDark text-slate-700 dark:text-slate-300 font-semibold border border-slate-200 dark:border-slate-800 text-xs hover:bg-slate-200 dark:hover:bg-slate-800 active:scale-98 transition-all"
                >
                  Back
                </button>
                <button
                  onClick={handleGoogleLogin}
                  className="flex-1 py-3 rounded-xl bg-eco-500 text-white font-bold text-xs hover:bg-eco-600 active:scale-98 transition-all"
                >
                  Verify & Login
                </button>
              </div>
              <button className="text-xs text-slate-400 hover:text-eco-500 block mx-auto">Resend Code (59s)</button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Divider */}
        <div className="relative my-6 text-center">
          <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-200 dark:border-slate-800/80" /></div>
          <span className="relative px-3 bg-slate-50 dark:bg-brand-dark text-xs text-slate-400 dark:text-slate-500 uppercase tracking-widest font-semibold">Or Connect With</span>
        </div>

        {/* Social login buttons */}
        <button
          onClick={handleGoogleLogin}
          id="btn-auth-google"
          className="w-full py-3 rounded-xl bg-white dark:bg-brand-cardDark text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-800 font-bold hover:bg-slate-50 dark:hover:bg-slate-800/80 flex items-center justify-center gap-2 active:scale-98 transition-all text-xs shadow-sm"
        >
          <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
            <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
            <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" fill="#FBBC05"/>
            <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
          </svg>
          Google Identity SSO Secure
        </button>

        {/* Instructions Helper Box */}
        <div className="mt-6 p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl text-[11px] text-amber-700 dark:text-amber-300 space-y-1">
          <p className="font-bold flex items-center gap-1">💡 Demo Workspace Access instructions:</p>
          <p>
            1. Select a tab above to switch roles.<br />
            2. Click <span className="font-bold">Auto-fill credentials</span>, or click the Google button directly to bypass sign-in instantly.
          </p>
        </div>
      </motion.div>
    </div>
  );
};
