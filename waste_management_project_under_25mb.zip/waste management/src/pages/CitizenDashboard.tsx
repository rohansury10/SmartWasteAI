import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Calendar, MapPin, Navigation, Leaf,
  CheckCircle2, Clock, Phone, AlertCircle,
  Truck, Search, Radio, Compass, Camera
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import type { PickupRequest } from '../context/AppContext';
import L from 'leaflet';
import { playProximityChime } from '../utils/audioAlert';

export const CitizenDashboard: React.FC = () => {
  const {
    user,
    schedulePickup,
    trucks,
    missedPickups,
    reportMissedPickup,
    schedules,
    addNotification,
    proximityAlertEnabled,
    setProximityAlertEnabled
  } = useApp();

  const [activeTab, setActiveTab] = useState<'track' | 'schedule' | 'missed' | 'book' | 'rewards'>('track');

  // Map references
  const liveMapRef = useRef<L.Map | null>(null);
  const truckMarkerRef = useRef<L.Marker | null>(null);
  const routePolylineRef = useRef<L.Polyline | null>(null);
  const rangeCircleRef = useRef<L.Circle | null>(null);
  const pinMapRef = useRef<L.Map | null>(null);

  // Selected schedule ward filter
  const [selectedWard, setSelectedWard] = useState<string>('All Wards');
  const [scheduleSearch, setScheduleSearch] = useState<string>('');

  // Book Pickup State
  const [wasteType, setWasteType] = useState<PickupRequest['type']>('Plastic');
  const [weight, setWeight] = useState(5);
  const [bookAddress, setBookAddress] = useState(user.homeAddress);
  const [timeSlot, setTimeSlot] = useState('10:00 AM - 12:00 PM');
  const [pickupDate, setPickupDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedCoords, setSelectedCoords] = useState<{ lat: number; lng: number }>(user.homeCoords);
  const [wastePhoto, setWastePhoto] = useState<string | null>(null);

  // Missed Pickup Form State
  const [missedReason, setMissedReason] = useState('Truck bypassed our lane without stopping');
  const [missedWasteType, setMissedWasteType] = useState('Organic / Wet Waste');
  const [missedAddress, setMissedAddress] = useState(user.homeAddress);
  const [missedPhoto, setMissedPhoto] = useState<string | null>(null);
  const [showMissedModal, setShowMissedModal] = useState(false);

  // Active truck assigned to user's sector/ward (default TRK-901 for Ward 1)
  const activeTruck = trucks.find(t => t.ward.includes('Ward 1')) || trucks[0];

  // Calculate real-time distance from user home to active truck
  const calculateDistance = () => {
    if (!activeTruck) return { meters: 0, text: 'N/A', mins: '0' };
    const dLat = (activeTruck.lat - user.homeCoords.lat) * 111000;
    const dLng = (activeTruck.lng - user.homeCoords.lng) * 111000 * Math.cos(user.homeCoords.lat * (Math.PI / 180));
    const distMeters = Math.round(Math.sqrt(dLat * dLat + dLng * dLng));
    const mins = Math.max(1, Math.round(distMeters / 120)); // walking/truck speed estimate
    const text = distMeters >= 1000 ? `${(distMeters / 1000).toFixed(1)} km` : `${distMeters} m`;
    return { meters: distMeters, text, mins: `${mins} mins` };
  };

  const distanceInfo = calculateDistance();

  // Test sound chime manually
  const handleTestChime = () => {
    playProximityChime();
    addNotification('Proximity Alert Test', 'Chime sound is working properly for your device.', 'info');
  };

  // Initialize Citizen Live Tracker Map
  useEffect(() => {
    if (activeTab === 'track') {
      const timer = setTimeout(() => {
        if (liveMapRef.current) {
          liveMapRef.current.remove();
          liveMapRef.current = null;
        }

        const mapContainer = document.getElementById('citizen-live-track-map');
        if (!mapContainer) return;

        const map = L.map('citizen-live-track-map', {
          zoomControl: true,
          scrollWheelZoom: false
        }).setView([user.homeCoords.lat, user.homeCoords.lng], 15);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: '&copy; OpenStreetMap contributors'
        }).addTo(map);

        // 1. Citizen Home Marker
        const homeIcon = L.divIcon({
          html: `
            <div class="relative flex items-center justify-center">
              <div class="w-10 h-10 rounded-full bg-emerald-600 border-2 border-white flex items-center justify-center text-white text-base shadow-xl z-20">
                🏡
              </div>
              <div class="absolute -bottom-6 whitespace-nowrap px-2 py-0.5 bg-slate-900/90 text-white text-[10px] font-bold rounded shadow-md">
                My Residence
              </div>
            </div>
          `,
          className: 'custom-home-icon',
          iconSize: [40, 40],
          iconAnchor: [20, 20]
        });

        L.marker([user.homeCoords.lat, user.homeCoords.lng], { icon: homeIcon })
          .addTo(map)
          .bindPopup(`<b>Your Home:</b><br/>${user.homeAddress}`);

        // 2. Proximity 500m alert radius circle
        const circle = L.circle([user.homeCoords.lat, user.homeCoords.lng], {
          radius: 500,
          color: '#10b981',
          fillColor: '#10b981',
          fillOpacity: 0.12,
          weight: 1.5,
          dashArray: '4, 6'
        }).addTo(map);
        rangeCircleRef.current = circle;

        // 3. Truck Route Polyline
        if (activeTruck.routePath && activeTruck.routePath.length > 0) {
          const polyline = L.polyline(activeTruck.routePath, {
            color: '#3b82f6',
            weight: 4,
            opacity: 0.7,
            dashArray: '8, 8'
          }).addTo(map);
          routePolylineRef.current = polyline;
        }

        // 4. Moving Truck Marker
        const truckIcon = L.divIcon({
          html: `
            <div class="relative flex items-center justify-center">
              <div class="w-11 h-11 rounded-full bg-blue-600 border-2 border-white flex items-center justify-center text-white text-lg shadow-2xl animate-pulse z-20">
                🚚
              </div>
              <span class="absolute -top-1 -right-1 w-3.5 h-3.5 bg-emerald-400 border-2 border-white rounded-full animate-ping"></span>
            </div>
          `,
          className: 'custom-truck-icon',
          iconSize: [44, 44],
          iconAnchor: [22, 22]
        });

        const truckMarker = L.marker([activeTruck.lat, activeTruck.lng], { icon: truckIcon })
          .addTo(map)
          .bindPopup(`
            <div class="text-xs font-sans">
              <b class="text-blue-600">${activeTruck.id} (${activeTruck.licensePlate})</b><br/>
              Driver: <b>${activeTruck.driverName}</b><br/>
              Speed: <b>${activeTruck.speed} km/h</b><br/>
              Fuel/Battery: <b>${activeTruck.fuelLevel}%</b><br/>
              Capacity: <b>${activeTruck.capacity}%</b>
            </div>
          `);

        truckMarkerRef.current = truckMarker;
        liveMapRef.current = map;
      }, 150);

      return () => {
        clearTimeout(timer);
        if (liveMapRef.current) {
          liveMapRef.current.remove();
          liveMapRef.current = null;
        }
      };
    }
  }, [activeTab]);

  // Update truck position on map when context coordinates change
  useEffect(() => {
    if (liveMapRef.current && truckMarkerRef.current && activeTruck) {
      truckMarkerRef.current.setLatLng([activeTruck.lat, activeTruck.lng]);
    }
  }, [activeTruck?.lat, activeTruck?.lng]);

  // Initialize Pin Drop Map for On-Demand Booking
  useEffect(() => {
    if (activeTab === 'book') {
      const timer = setTimeout(() => {
        if (pinMapRef.current) {
          pinMapRef.current.remove();
          pinMapRef.current = null;
        }
        const container = document.getElementById('citizen-pin-map');
        if (!container) return;

        const map = L.map('citizen-pin-map').setView([selectedCoords.lat, selectedCoords.lng], 14);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

        const marker = L.marker([selectedCoords.lat, selectedCoords.lng], { draggable: true }).addTo(map);
        marker.on('dragend', () => {
          const pos = marker.getLatLng();
          setSelectedCoords({ lat: pos.lat, lng: pos.lng });
        });

        map.on('click', (e) => {
          marker.setLatLng(e.latlng);
          setSelectedCoords({ lat: e.latlng.lat, lng: e.latlng.lng });
        });

        pinMapRef.current = map;
      }, 150);

      return () => {
        clearTimeout(timer);
        if (pinMapRef.current) {
          pinMapRef.current.remove();
          pinMapRef.current = null;
        }
      };
    }
  }, [activeTab]);

  // Submit on-demand booking
  const handleBookSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    schedulePickup({
      type: wasteType,
      weight,
      address: bookAddress,
      lat: selectedCoords.lat,
      lng: selectedCoords.lng,
      timeSlot,
      date: pickupDate,
      photoUrl: wastePhoto || 'https://images.unsplash.com/photo-1611284446314-60a58ac0deb9?auto=format&fit=crop&q=80&w=300'
    });
    setActiveTab('track');
  };

  // Submit missed pickup
  const handleMissedSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    reportMissedPickup({
      citizenName: user.name,
      address: missedAddress,
      ward: user.ward,
      lat: user.homeCoords.lat + (Math.random() - 0.5) * 0.002,
      lng: user.homeCoords.lng + (Math.random() - 0.5) * 0.002,
      wasteType: missedWasteType,
      reason: missedReason,
      photoUrl: missedPhoto || 'https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?auto=format&fit=crop&q=80&w=300'
    });
    setShowMissedModal(false);
  };

  // Filtered schedules
  const filteredSchedules = schedules.filter(s => {
    const matchesWard = selectedWard === 'All Wards' || s.ward.toLowerCase().includes(selectedWard.toLowerCase());
    const matchesSearch = s.zoneName.toLowerCase().includes(scheduleSearch.toLowerCase()) ||
                          s.wasteCategory.toLowerCase().includes(scheduleSearch.toLowerCase()) ||
                          s.timeWindow.toLowerCase().includes(scheduleSearch.toLowerCase());
    return matchesWard && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Top Banner: Greeting, Distance & ETA Badge */}
      <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-sky-600 rounded-3xl p-6 text-white shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-white/10 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-bold uppercase tracking-wider flex items-center gap-1.5">
                <Radio className="w-3.5 h-3.5 text-emerald-300 animate-pulse" />
                Live Ward Tracking: {user.ward}
              </span>
            </div>
            <h1 className="text-2xl md:text-3xl font-black tracking-tight">
              Hello, {user.name} 👋
            </h1>
            <p className="text-emerald-100 text-xs md:text-sm max-w-xl">
              Track your daily garbage collection truck in real time, check weekly schedules, and report missed pickups with a single click.
            </p>
          </div>

          {/* Quick ETA Card */}
          <div className="flex items-center gap-4 bg-white/15 backdrop-blur-md border border-white/20 p-4 rounded-2xl shrink-0">
            <div className="w-14 h-14 rounded-2xl bg-white text-emerald-600 flex items-center justify-center text-2xl font-black shadow-lg">
              🚚
            </div>
            <div>
              <span className="text-[11px] text-emerald-200 font-semibold uppercase tracking-wider block">
                Next Truck Arrival
              </span>
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-black text-white">{distanceInfo.mins}</span>
                <span className="text-xs text-emerald-200 font-medium">({distanceInfo.text} away)</span>
              </div>
              <span className="text-[10px] text-emerald-100/90 block">
                {activeTruck.id} • Driver {activeTruck.driverName}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Citizen Navigation Sub-Tabs */}
      <div className="flex bg-white dark:bg-brand-cardDark p-1.5 rounded-2xl border border-slate-200/80 dark:border-slate-800/80 shadow-sm overflow-x-auto gap-1">
        {[
          { id: 'track', label: 'Live Truck Tracker', icon: <Compass className="w-4 h-4" /> },
          { id: 'schedule', label: 'Pickup Schedules', icon: <Calendar className="w-4 h-4" /> },
          { id: 'missed', label: 'Missed Pickups', count: missedPickups.length, icon: <AlertCircle className="w-4 h-4" /> },
          { id: 'book', label: 'Book Special Pickup', icon: <Truck className="w-4 h-4" /> },
          { id: 'rewards', label: 'Eco Rewards & Badges', icon: <Leaf className="w-4 h-4" /> }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all shrink-0 ${
              activeTab === tab.id
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/50'
            }`}
          >
            {tab.icon}
            {tab.label}
            {tab.count !== undefined && tab.count > 0 && (
              <span className="px-1.5 py-0.5 text-[10px] rounded-full bg-rose-500 text-white font-extrabold ml-0.5">
                {tab.count}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* TAB 1: LIVE TRUCK TRACKER */}
      {activeTab === 'track' && (
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Leaflet Map */}
          <div className="lg:col-span-2 space-y-4">
            <div className="bg-white dark:bg-brand-cardDark p-4 rounded-3xl border border-slate-200/80 dark:border-slate-800/80 shadow-sm">
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-emerald-500 animate-ping" />
                  <h3 className="font-extrabold text-sm text-slate-800 dark:text-white">
                    Live Sector Radar: {activeTruck.ward}
                  </h3>
                </div>
                <div className="flex items-center gap-2 text-xs">
                  <span className="text-slate-400">Truck Status:</span>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 font-bold text-[11px] border border-emerald-500/20">
                    ● {activeTruck.status}
                  </span>
                </div>
              </div>

              {/* Map Container */}
              <div
                id="citizen-live-track-map"
                className="w-full h-[450px] rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700/60 shadow-inner"
              />

              {/* Map Legend */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-3 mt-3 text-[11px] text-slate-500 dark:text-slate-400">
                <div className="flex items-center gap-4">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 inline-block" /> Your Residence
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-blue-600 inline-block" /> Active Truck (TRK-901)
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400/40 border border-emerald-600 inline-block" /> 500m Proximity Alarm Zone
                  </span>
                </div>
                <span className="font-semibold text-emerald-600 dark:text-emerald-400">
                  ⚡ GPS Updates every 2 seconds
                </span>
              </div>
            </div>
          </div>

          {/* Right Column: Telemetry & Arrival Alerts */}
          <div className="space-y-4">
            {/* Proximity Alarm Card */}
            <div className="p-5 rounded-3xl bg-white dark:bg-brand-cardDark border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-600 flex items-center justify-center font-bold">
                    🔔
                  </div>
                  <div>
                    <h4 className="font-extrabold text-xs text-slate-800 dark:text-white">Proximity Alarm</h4>
                    <span className="text-[10px] text-slate-400">Sound bell when truck is near</span>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={proximityAlertEnabled}
                    onChange={(e) => setProximityAlertEnabled(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600" />
                </label>
              </div>

              <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-100 dark:border-slate-800 text-xs space-y-2">
                <div className="flex justify-between items-center text-[11px]">
                  <span className="text-slate-500">Threshold:</span>
                  <span className="font-bold text-slate-700 dark:text-slate-300">Within 500 meters</span>
                </div>
                <div className="flex justify-between items-center text-[11px]">
                  <span className="text-slate-500">Current Distance:</span>
                  <span className="font-extrabold text-emerald-600 dark:text-emerald-400">
                    {distanceInfo.text} ({distanceInfo.mins} away)
                  </span>
                </div>
                <div className="flex justify-between items-center text-[11px]">
                  <span className="text-slate-500">Notification Sound:</span>
                  <button
                    onClick={handleTestChime}
                    className="text-emerald-600 hover:text-emerald-700 font-bold underline"
                  >
                    Test Chime
                  </button>
                </div>
              </div>
            </div>

            {/* Truck Details Card */}
            <div className="p-5 rounded-3xl bg-white dark:bg-brand-cardDark border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-extrabold text-xs text-slate-800 dark:text-white flex items-center gap-1.5">
                  <Truck className="w-4 h-4 text-emerald-600" /> Assigned Fleet Vehicle
                </h4>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-500/10 text-blue-600 border border-blue-500/20">
                  {activeTruck.fuelType} Truck
                </span>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Vehicle ID:</span>
                  <span className="font-bold text-slate-800 dark:text-white">{activeTruck.id} ({activeTruck.licensePlate})</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Driver in Charge:</span>
                  <span className="font-bold text-slate-800 dark:text-white">{activeTruck.driverName}</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Driver Contact:</span>
                  <a
                    href={`tel:${activeTruck.phone}`}
                    className="font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-1"
                  >
                    <Phone className="w-3 h-3" /> {activeTruck.phone}
                  </a>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Cruising Speed:</span>
                  <span className="font-bold text-slate-800 dark:text-white">{activeTruck.speed} km/h</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Vehicle Capacity:</span>
                  <div className="flex items-center gap-2">
                    <div className="w-20 bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-emerald-500 rounded-full"
                        style={{ width: `${activeTruck.capacity}%` }}
                      />
                    </div>
                    <span className="font-bold text-slate-700 dark:text-slate-300">{activeTruck.capacity}%</span>
                  </div>
                </div>
              </div>

              {/* Quick Action: Report Missed Pickup */}
              <button
                onClick={() => setShowMissedModal(true)}
                className="w-full py-2.5 px-3 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-600 font-bold text-xs border border-rose-500/20 transition-all flex items-center justify-center gap-2"
              >
                <AlertCircle className="w-3.5 h-3.5" /> Did the truck miss your house? Report Here
              </button>
            </div>

            {/* Upcoming Stops along current route */}
            <div className="p-5 rounded-3xl bg-white dark:bg-brand-cardDark border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-3">
              <h4 className="font-extrabold text-xs text-slate-800 dark:text-white flex items-center gap-1.5">
                <Navigation className="w-3.5 h-3.5 text-blue-500" /> Route Waypoints
              </h4>
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {activeTruck.routeStops.map((stop, idx) => (
                  <div
                    key={idx}
                    className={`p-2.5 rounded-xl text-xs flex items-start gap-2.5 transition-all ${
                      stop.completed
                        ? 'bg-slate-50 dark:bg-slate-800/30 opacity-60 line-through'
                        : idx === activeTruck.currentStopIndex
                        ? 'bg-blue-500/10 border border-blue-500/20 font-bold text-blue-600 dark:text-blue-400'
                        : 'bg-white dark:bg-slate-800/50'
                    }`}
                  >
                    <span className="text-[10px] mt-0.5 font-bold">#{idx + 1}</span>
                    <div className="flex-1">
                      <p className="line-clamp-1">{stop.name}</p>
                      {idx === activeTruck.currentStopIndex && (
                        <span className="text-[10px] text-blue-500 font-semibold block mt-0.5">
                          ● Approaching Now (ETA: {activeTruck.eta})
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: PICKUP SCHEDULES */}
      {activeTab === 'schedule' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-brand-cardDark p-6 rounded-3xl border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h3 className="text-lg font-black text-slate-900 dark:text-white">
                  Municipal Ward Pickup Timetable
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Fixed door-to-door waste collection cycles scheduled across city sectors.
                </p>
              </div>

              {/* Filters */}
              <div className="flex flex-wrap items-center gap-2.5">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Search area, waste type..."
                    value={scheduleSearch}
                    onChange={(e) => setScheduleSearch(e.target.value)}
                    className="pl-8 pr-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <select
                  value={selectedWard}
                  onChange={(e) => setSelectedWard(e.target.value)}
                  className="px-3 py-2 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border-none font-bold focus:ring-2 focus:ring-emerald-500 text-slate-700 dark:text-slate-300"
                >
                  <option value="All Wards">All City Wards</option>
                  <option value="Ward 1">Ward 1 - VIP Road / Vesu</option>
                  <option value="Ward 2">Ward 2 - Adajan</option>
                  <option value="Ward 3">Ward 3 - Varachha</option>
                  <option value="Ward 4">Ward 4 - Pal</option>
                </select>
              </div>
            </div>

            {/* Schedule Cards Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 pt-2">
              {filteredSchedules.map(sch => (
                <div
                  key={sch.id}
                  className="p-5 rounded-2xl bg-slate-50/70 dark:bg-slate-800/40 border border-slate-200/60 dark:border-slate-800/60 space-y-4 hover:shadow-md transition-all"
                >
                  <div className="flex justify-between items-start">
                    <span className={`text-[10px] font-extrabold px-2.5 py-1 rounded-full uppercase ${
                      sch.wasteCategory.includes('Organic')
                        ? 'bg-emerald-500/10 text-emerald-600 border border-emerald-500/20'
                        : sch.wasteCategory.includes('Dry')
                        ? 'bg-blue-500/10 text-blue-600 border border-blue-500/20'
                        : 'bg-amber-500/10 text-amber-600 border border-amber-500/20'
                    }`}>
                      {sch.wasteCategory}
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                      {sch.frequency}
                    </span>
                  </div>

                  <div>
                    <h4 className="font-extrabold text-sm text-slate-800 dark:text-white">{sch.zoneName}</h4>
                    <span className="text-[11px] text-slate-500 block mt-0.5">{sch.ward}</span>
                  </div>

                  <div className="space-y-2 pt-2 border-t border-slate-200/50 dark:border-slate-700/50 text-xs">
                    <div className="flex items-center gap-2 text-slate-600 dark:text-slate-300">
                      <Clock className="w-3.5 h-3.5 text-emerald-600" />
                      <span className="font-semibold">{sch.timeWindow}</span>
                    </div>

                    <div className="flex items-center gap-2 text-slate-500">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      <span>Days: <b>{sch.days.join(', ')}</b></span>
                    </div>

                    <div className="flex items-center gap-2 text-slate-500">
                      <Truck className="w-3.5 h-3.5 text-slate-400" />
                      <span>Truck: <b>{sch.assignedTruckId}</b> ({sch.truckPlate})</span>
                    </div>
                  </div>

                  <button
                    onClick={() => addNotification('Schedule Reminder Set', `You will receive a notification before the ${sch.wasteCategory} pickup in ${sch.zoneName}.`, 'success')}
                    className="w-full py-2 rounded-xl bg-white dark:bg-slate-700 hover:bg-emerald-600 hover:text-white text-slate-700 dark:text-slate-200 text-xs font-bold border border-slate-200 dark:border-slate-600 transition-all shadow-sm"
                  >
                    🔔 Set Remind Me Alert
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: MISSED PICKUPS & INCIDENTS */}
      {activeTab === 'missed' && (
        <div className="space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-brand-cardDark p-6 rounded-3xl border border-slate-200/80 dark:border-slate-800/80 shadow-sm">
            <div>
              <h3 className="text-lg font-black text-slate-900 dark:text-white">
                Missed Pickup Incident Tracker
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                If the municipal truck bypassed your building or street, file an incident for rapid dispatch recovery.
              </p>
            </div>
            <button
              onClick={() => setShowMissedModal(true)}
              className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-xs shadow-md shadow-rose-600/20 transition-all flex items-center gap-2"
            >
              <AlertCircle className="w-4 h-4" /> Report Missed Collection
            </button>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            {missedPickups.map(incident => (
              <div
                key={incident.id}
                className="p-5 rounded-3xl bg-white dark:bg-brand-cardDark border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-4"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[10px] font-mono text-slate-400 block">{incident.id}</span>
                    <h4 className="font-extrabold text-sm text-slate-800 dark:text-white mt-0.5">
                      {incident.address}
                    </h4>
                    <span className="text-xs text-slate-500">{incident.ward}</span>
                  </div>

                  <span className={`text-[10px] font-extrabold px-2.5 py-1 rounded-full uppercase ${
                    incident.status === 'Resolved'
                      ? 'bg-emerald-500/10 text-emerald-600 border border-emerald-500/20'
                      : incident.status === 'Dispatched'
                      ? 'bg-blue-500/10 text-blue-600 border border-blue-500/20 animate-pulse'
                      : 'bg-rose-500/10 text-rose-600 border border-rose-500/20'
                  }`}>
                    ● {incident.status}
                  </span>
                </div>

                <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-2xl text-xs space-y-1.5 border border-slate-100 dark:border-slate-800">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Waste Category:</span>
                    <span className="font-bold text-slate-700 dark:text-slate-300">{incident.wasteType}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Reported Time:</span>
                    <span className="font-semibold text-slate-700 dark:text-slate-300">{incident.reportedAt}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Recovery SLA:</span>
                    <span className="font-bold text-amber-500">{incident.slaMinutes} mins remaining</span>
                  </div>
                  {incident.assignedTruckId && (
                    <div className="flex justify-between">
                      <span className="text-slate-400">Recovery Truck:</span>
                      <span className="font-bold text-blue-600">{incident.assignedTruckId}</span>
                    </div>
                  )}
                </div>

                <p className="text-xs text-slate-600 dark:text-slate-400 italic">
                  "{incident.reason}"
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: BOOK SPECIAL / ON-DEMAND PICKUP */}
      {activeTab === 'book' && (
        <div className="grid lg:grid-cols-2 gap-6">
          <form onSubmit={handleBookSubmit} className="p-6 bg-white dark:bg-brand-cardDark rounded-3xl border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-4">
            <h3 className="text-lg font-black text-slate-900 dark:text-white">
              Schedule On-Demand Bulky / Recyclable Collection
            </h3>
            <p className="text-xs text-slate-500">
              Book a scheduled pickup for bulky cardboard, electronics, or bulk recyclables and earn EcoCoins.
            </p>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">Waste Type</label>
                <select
                  value={wasteType}
                  onChange={(e) => setWasteType(e.target.value as any)}
                  className="w-full p-2.5 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border-none font-bold"
                >
                  <option value="Plastic">Plastic & Bottles</option>
                  <option value="E-Waste">E-Waste & Electronics</option>
                  <option value="Metal">Metal Scrap</option>
                  <option value="Glass">Glass Bottles</option>
                  <option value="Organic">Bulk Organic Compost</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">Est. Weight (kg)</label>
                <input
                  type="number"
                  min="1"
                  max="100"
                  value={weight}
                  onChange={(e) => setWeight(Number(e.target.value))}
                  className="w-full p-2.5 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border-none font-bold"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">Address / Landmark</label>
              <input
                type="text"
                value={bookAddress}
                onChange={(e) => setBookAddress(e.target.value)}
                className="w-full p-2.5 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border-none font-semibold"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">Pickup Date</label>
                <input
                  type="date"
                  value={pickupDate}
                  onChange={(e) => setPickupDate(e.target.value)}
                  className="w-full p-2.5 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border-none font-semibold"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">Preferred Time Window</label>
                <select
                  value={timeSlot}
                  onChange={(e) => setTimeSlot(e.target.value)}
                  className="w-full p-2.5 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border-none font-semibold"
                >
                  <option>08:00 AM - 10:00 AM</option>
                  <option>10:00 AM - 12:00 PM</option>
                  <option>02:00 PM - 04:00 PM</option>
                  <option>04:00 PM - 06:00 PM</option>
                </select>
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">Photo of Scrap / Waste</label>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setWastePhoto('https://images.unsplash.com/photo-1611284446314-60a58ac0deb9?auto=format&fit=crop&q=80&w=300')}
                  className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-xs font-bold flex items-center gap-1.5"
                >
                  <Camera className="w-3.5 h-3.5" /> Attach Photo
                </button>
                {wastePhoto && (
                  <span className="text-[11px] text-emerald-600 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> Image Uploaded
                  </span>
                )}
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs shadow-lg shadow-emerald-600/20 transition-all flex items-center justify-center gap-2"
            >
              <Truck className="w-4 h-4" /> Confirm & Dispatch Nearest Truck
            </button>
          </form>

          {/* Map Pin Dropper */}
          <div className="p-6 bg-white dark:bg-brand-cardDark rounded-3xl border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-extrabold text-xs text-slate-800 dark:text-white flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-emerald-600" /> Precise Pickup Coordinates
              </h4>
              <span className="text-[10px] text-slate-400">Click or drag pin</span>
            </div>
            <div id="citizen-pin-map" className="w-full h-80 rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700" />
            <span className="text-[11px] text-slate-400 block text-right font-mono">
              Coordinates: {selectedCoords.lat.toFixed(4)}, {selectedCoords.lng.toFixed(4)}
            </span>
          </div>
        </div>
      )}

      {/* TAB 5: ECO REWARDS & BADGES */}
      {activeTab === 'rewards' && (
        <div className="grid md:grid-cols-3 gap-6">
          <div className="p-6 rounded-3xl bg-white dark:bg-brand-cardDark border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-600 flex items-center justify-center text-2xl font-black">
                🪙
              </div>
              <div>
                <span className="text-xs text-slate-400 font-bold uppercase">Your Balance</span>
                <h3 className="text-2xl font-black text-slate-900 dark:text-white">{user.ecoCoins} EcoCoins</h3>
              </div>
            </div>
            <p className="text-xs text-slate-500">
              Earned through on-time waste segregation and reporting clean collection drives.
            </p>
          </div>

          <div className="p-6 rounded-3xl bg-white dark:bg-brand-cardDark border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-teal-500/10 text-teal-600 flex items-center justify-center text-2xl font-black">
                🌱
              </div>
              <div>
                <span className="text-xs text-slate-400 font-bold uppercase">Carbon Footprint Saved</span>
                <h3 className="text-2xl font-black text-slate-900 dark:text-white">{user.carbonSaved} kg CO₂</h3>
              </div>
            </div>
            <p className="text-xs text-slate-500">
              Equivalent to planting ~3 urban trees in your municipal ward!
            </p>
          </div>

          <div className="p-6 rounded-3xl bg-white dark:bg-brand-cardDark border border-slate-200/80 dark:border-slate-800/80 shadow-sm space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/10 text-amber-600 flex items-center justify-center text-2xl font-black">
                🏆
              </div>
              <div>
                <span className="text-xs text-slate-400 font-bold uppercase">Citizen Rank</span>
                <h3 className="text-2xl font-black text-slate-900 dark:text-white">#3 in Ward 1</h3>
              </div>
            </div>
            <p className="text-xs text-slate-500">
              Top 5% of environmentally proactive households in Surat Smart City.
            </p>
          </div>
        </div>
      )}

      {/* REPORT MISSED PICKUP MODAL */}
      <AnimatePresence>
        {showMissedModal && (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-brand-cardDark max-w-lg w-full rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-5"
            >
              <div className="flex justify-between items-center pb-3 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-rose-500/10 text-rose-600 flex items-center justify-center font-bold">
                    🚨
                  </div>
                  <h3 className="font-black text-base text-slate-900 dark:text-white">
                    Report Missed Garbage Collection
                  </h3>
                </div>
                <button
                  onClick={() => setShowMissedModal(false)}
                  className="p-1 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  ✕
                </button>
              </div>

              <form onSubmit={handleMissedSubmit} className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    Your Address / Street
                  </label>
                  <input
                    type="text"
                    value={missedAddress}
                    onChange={(e) => setMissedAddress(e.target.value)}
                    required
                    className="w-full p-2.5 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border-none font-medium"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    Missed Waste Category
                  </label>
                  <select
                    value={missedWasteType}
                    onChange={(e) => setMissedWasteType(e.target.value)}
                    className="w-full p-2.5 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border-none font-semibold"
                  >
                    <option>Organic / Wet Waste</option>
                    <option>Dry Recyclables</option>
                    <option>Commercial / Market Waste</option>
                    <option>Hazardous / Medical</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    Reason / Description
                  </label>
                  <select
                    value={missedReason}
                    onChange={(e) => setMissedReason(e.target.value)}
                    className="w-full p-2.5 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 border-none font-semibold mb-2"
                  >
                    <option>Truck bypassed our lane without stopping</option>
                    <option>Truck arrived earlier than scheduled timetable</option>
                    <option>Bin was overflowing and could not fit</option>
                    <option>Truck had no capacity left</option>
                    <option>Other / Unscheduled delay</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    Photo Proof (Optional)
                  </label>
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => setMissedPhoto('https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?auto=format&fit=crop&q=80&w=300')}
                      className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-xs font-bold flex items-center gap-1.5"
                    >
                      <Camera className="w-3.5 h-3.5" /> Attach Photo Evidence
                    </button>
                    {missedPhoto && (
                      <span className="text-[11px] text-emerald-600 font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Photo Attached
                      </span>
                    )}
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowMissedModal(false)}
                    className="px-4 py-2 rounded-xl text-xs font-bold text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-xs shadow-md shadow-rose-600/20"
                  >
                    Submit Report & Dispatch Recovery
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
