import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Leaf, Shield, Truck, BarChart3, Users, Play, Check } from 'lucide-react';
import { AIWasteScanner } from '../components/AIWasteScanner';

interface LandingPageProps {
  onGetStarted: () => void;
  onBookPickup: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onGetStarted, onBookPickup }) => {
  const [totalRecycled, setTotalRecycled] = useState(1482090);
  const [co2Saved, setCo2Saved] = useState(259830);

  // Live count increments
  useEffect(() => {
    const interval = setInterval(() => {
      setTotalRecycled(prev => prev + Math.floor(Math.random() * 3) + 1);
      setCo2Saved(prev => prev + Number((Math.random() * 0.5).toFixed(2)));
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const features = [
    { icon: <Truck className="w-6 h-6 text-eco-500" />, title: "AI Route Optimization", desc: "Shortest collection routes calculated dynamically using live traffic, weather, and bin capacity data." },
    { icon: <Leaf className="w-6 h-6 text-emerald-500" />, title: "Eco-Rewards System", desc: "Citizens earn Eco Coins for recycling waste, redeemable for green products, tree planting, or NGO donations." },
    { icon: <BarChart3 className="w-6 h-6 text-blue-500" />, title: "IoT Bin Telemetry", desc: "Smart bin sensors tracking real-time fill level, temperature, and methane emission levels to predict overflow." },
    { icon: <Users className="w-6 h-6 text-purple-500" />, title: "Connected Community", desc: "Bridges citizens, municipal bodies, truck drivers, recyclers, and NGOs on a single unified portal." }
  ];

  const benefits = [
    { title: "85% Segregation Rate", desc: "Precision AI classification ensures garbage is segregated accurately at the source." },
    { title: "40% Fuel Savings", desc: "Optimized driver navigation reduces unnecessary mileage, lowering municipality fuel budgets." },
    { title: "Zero Overflowing Bins", desc: "Dynamic threshold forecasting alerts trucks before containers spill into public walkways." }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative pt-32 pb-24 md:pt-40 md:pb-32 overflow-hidden bg-gradient-to-b from-eco-50/20 via-slate-50 to-white dark:from-brand-dark/20 dark:via-brand-dark dark:to-brand-dark">
        {/* Background Glowing Orbs */}
        <div className="absolute top-1/4 left-1/10 w-96 h-96 bg-eco-500/10 rounded-full blur-[100px] pointer-events-none" />
        <div className="absolute top-1/3 right-1/10 w-96 h-96 bg-blue-500/10 rounded-full blur-[100px] pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 md:px-6 relative z-10 grid lg:grid-cols-2 gap-12 items-center">
          {/* Hero Content */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-left space-y-6"
          >
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-eco-500/10 border border-eco-500/20 text-eco-600 dark:text-eco-400 text-xs font-semibold uppercase tracking-wider">
              <Leaf className="w-3.5 h-3.5" /> Next-Gen Smart City Infrastructure
            </div>
            
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 dark:text-white leading-[1.1]">
              Transforming Waste <br />
              <span className="bg-gradient-to-r from-eco-500 to-emerald-400 bg-clip-text text-transparent">
                Into a Smarter Future.
              </span>
            </h1>

            <p className="text-lg text-slate-500 dark:text-slate-400 max-w-lg leading-relaxed">
              AI-powered waste collection, segregation, recycling, and live tracking platform for smart cities. Connecting citizens, municipalities, and recyclers.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap gap-4 pt-2">
              <button
                onClick={onGetStarted}
                id="btn-hero-get-started"
                className="flex items-center gap-2 px-8 py-3.5 rounded-full bg-eco-500 hover:bg-eco-600 text-white font-bold shadow-lg hover:shadow-eco-500/20 active:scale-95 transition-all text-sm"
              >
                Get Started <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={onBookPickup}
                id="btn-hero-book-pickup"
                className="flex items-center gap-2 px-7 py-3.5 rounded-full bg-white dark:bg-brand-cardDark text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-800 font-bold hover:bg-slate-50 dark:hover:bg-slate-800/80 active:scale-95 transition-all text-sm shadow-sm"
              >
                Book Pickup
              </button>
              <button
                id="btn-hero-demo"
                className="flex items-center gap-2 px-5 py-3.5 text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 text-sm font-semibold transition-colors"
              >
                <Play className="w-4 h-4 fill-current" /> Watch Demo
              </button>
            </div>

            {/* Live Counters */}
            <div className="grid grid-cols-2 gap-6 pt-8 border-t border-slate-200/50 dark:border-slate-800/50 max-w-md">
              <div>
                <span className="text-2xl md:text-3xl font-extrabold text-slate-800 dark:text-white tabular-nums">
                  {totalRecycled.toLocaleString()} kg
                </span>
                <p className="text-xs text-slate-400 font-semibold uppercase mt-0.5">Total Waste Recycled</p>
              </div>
              <div>
                <span className="text-2xl md:text-3xl font-extrabold text-eco-500 dark:text-eco-400 tabular-nums">
                  {co2Saved.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} kg
                </span>
                <p className="text-xs text-slate-400 font-semibold uppercase mt-0.5">CO2 Emissions Saved</p>
              </div>
            </div>
          </motion.div>

          {/* Hero Animation Visualizer */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative flex justify-center items-center h-full min-h-[350px]"
          >
            {/* Holographic earth visualizer */}
            <div className="absolute inset-0 bg-gradient-to-tr from-eco-500/10 to-blue-500/10 rounded-3xl blur-3xl pointer-events-none" />

            <div className="w-full max-w-[420px] aspect-square rounded-3xl glass-panel border border-white/20 dark:border-slate-800/40 p-6 shadow-glass relative flex flex-col justify-between overflow-hidden">
              <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:16px_16px] opacity-10 dark:opacity-30" />
              
              <div className="flex items-center justify-between border-b border-slate-200/30 dark:border-slate-800/30 pb-4 relative z-10">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" /> EcoSync Live City Map
                </span>
                <span className="text-[10px] bg-eco-500/10 text-eco-500 dark:text-eco-400 font-bold px-2 py-0.5 rounded-full uppercase border border-eco-500/20">
                  Surat Zone A
                </span>
              </div>

              {/* Simulated Smart City map layout */}
              <div className="flex-1 flex items-center justify-center relative p-4 my-2">
                <svg className="w-full h-full max-h-[220px] opacity-75" viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
                  {/* Grid Routes */}
                  <path d="M10 50 H190 M10 100 H190 M10 150 H190 M50 10 V190 M100 10 V190 M150 10 V190" stroke="currentColor" strokeWidth="0.5" className="text-slate-300 dark:text-slate-800" strokeDasharray="3 3" />
                  
                  {/* Active Optimized Path */}
                  <path d="M50 50 H150 V100 H100 V150" stroke="#22c55e" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="animate-pulse" />

                  {/* Bins status */}
                  <circle cx="50" cy="50" r="6" fill="#16a34a" className="pulse-marker-active" />
                  <circle cx="150" cy="50" r="6" fill="#e11d48" className="pulse-marker-active" />
                  <circle cx="150" cy="100" r="6" fill="#f59e0b" className="pulse-marker-active" />
                  <circle cx="100" cy="150" r="6" fill="#16a34a" />

                  {/* Truck moving simulation */}
                  <g className="animate-float">
                    <rect x="90" y="90" width="18" height="10" rx="2" fill="#3b82f6" />
                    <circle cx="94" cy="101" r="2" fill="#000" />
                    <circle cx="104" cy="101" r="2" fill="#000" />
                  </g>
                </svg>

                {/* Statistics overlay */}
                <div className="absolute top-2 right-2 bg-slate-900/80 backdrop-blur-md text-[10px] text-white p-2 rounded-lg border border-slate-700/50 space-y-1">
                  <p>🚚 TRK-901: <span className="text-sky-400">On Duty</span></p>
                  <p>🔋 Battery: <span className="text-emerald-400">82%</span></p>
                  <p>📍 Stops Left: <span className="text-amber-400">3</span></p>
                </div>
              </div>

              {/* Dynamic status panel */}
              <div className="bg-slate-100/50 dark:bg-brand-cardDark/50 p-3 rounded-xl border border-slate-200/50 dark:border-slate-800/30 flex items-center justify-between text-xs relative z-10">
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4 text-emerald-500" />
                  <span className="font-semibold text-slate-600 dark:text-slate-300">Cleanliness Rating</span>
                </div>
                <span className="font-bold text-slate-800 dark:text-slate-100">96.8% (Excellent)</span>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Interactive AI Scanner Preview */}
      <section className="py-20 bg-slate-50 dark:bg-brand-cardDark/30 border-y border-slate-200/30 dark:border-slate-800/30">
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          <div className="max-w-2xl mx-auto text-center mb-12">
            <h2 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              Test Our AI Waste Classifier
            </h2>
            <p className="text-slate-500 dark:text-slate-400 mt-2 text-sm">
              Use your device camera or upload a file. EcoSync identifies materials, explains recycling protocols, and rewards your green efforts instantly.
            </p>
          </div>

          <AIWasteScanner />
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-24 bg-white dark:bg-brand-dark">
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          <div className="max-w-2xl mx-auto text-center mb-16 space-y-3">
            <h2 className="text-3xl md:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              A Complete Smart City Ecosystem
            </h2>
            <p className="text-slate-500 dark:text-slate-400 text-sm">
              Integrating citizens, municipality fleets, scrap brokers, and recycling facilities inside one premium SaaS platform.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feat, idx) => (
              <div
                key={idx}
                className="p-6 rounded-2xl bg-slate-50 dark:bg-brand-cardDark border border-slate-200/50 dark:border-slate-800/30 hover:border-eco-500/30 transition-all hover:-translate-y-1 duration-300 flex flex-col justify-between"
              >
                <div className="space-y-4">
                  <div className="w-12 h-12 rounded-xl bg-slate-100 dark:bg-brand-dark flex items-center justify-center">
                    {feat.icon}
                  </div>
                  <h3 className="font-bold text-lg text-slate-800 dark:text-white">{feat.title}</h3>
                  <p className="text-sm text-slate-500 dark:text-slate-400 leading-relaxed">{feat.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits / Metrics Section */}
      <section className="py-24 bg-gradient-to-r from-eco-600 to-emerald-600 text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-15 bg-[radial-gradient(circle_at_bottom_left,_var(--tw-gradient-stops))] from-yellow-300 via-transparent to-transparent" />
        
        <div className="max-w-7xl mx-auto px-4 md:px-6 relative z-10 grid lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-5 space-y-6">
            <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight">
              Designed For Next-Gen Urban Management
            </h2>
            <p className="text-emerald-100 text-sm leading-relaxed">
              EcoSync streamlines city sanitation by utilizing edge algorithms, eliminating visual dump litter, minimizing empty truck runs, and improving overall carbon indices.
            </p>
            <div className="flex flex-col gap-3 pt-2">
              {['Compliant with ISO 14001 Standards', 'Full integration with municipal ward systems', 'Citizen outreach & gamified green reward coins'].map((item, idx) => (
                <div key={idx} className="flex items-center gap-2 text-sm text-emerald-50">
                  <div className="w-5 h-5 rounded-full bg-emerald-700/60 flex items-center justify-center text-emerald-300 shrink-0">
                    <Check className="w-3 h-3" />
                  </div>
                  <span>{item}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-7 grid sm:grid-cols-3 gap-6">
            {benefits.map((ben, idx) => (
              <div
                key={idx}
                className="p-6 rounded-2xl bg-white/10 backdrop-blur-md border border-white/10 flex flex-col justify-between"
              >
                <span className="text-2xl md:text-3xl font-extrabold">{ben.title}</span>
                <p className="text-xs text-emerald-100 mt-2">{ben.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Active Cities Section */}
      <section className="py-20 bg-slate-50 dark:bg-brand-cardDark/30">
        <div className="max-w-7xl mx-auto px-4 md:px-6 text-center">
          <h2 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-8">Empowering Eco-Conscious Municipalities</h2>
          <div className="flex flex-wrap justify-center items-center gap-8 md:gap-16 opacity-50 dark:opacity-70">
            {['Surat Municipal Corp.', 'Mumbai Ward A-D', 'Pune Smart City', 'Ahmedabad Urban Authority', 'Indore Clean Mission'].map((city, idx) => (
              <span key={idx} className="font-extrabold text-sm md:text-base text-slate-600 dark:text-slate-400 tracking-wider">
                🏙️ {city}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-brand-dark">
        <div className="max-w-7xl mx-auto px-4 md:px-6 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-lg bg-eco-500 flex items-center justify-center text-white font-extrabold">
              ♻️
            </div>
            <span className="font-extrabold text-lg tracking-tight text-slate-900 dark:text-white">EcoSync</span>
          </div>

          <p className="text-xs text-slate-400 text-center">
            &copy; 2026 EcoSync System Inc. Connecting smart infrastructure for carbon-negative cities. All rights reserved.
          </p>

          <div className="flex gap-4 text-xs text-slate-500 dark:text-slate-400">
            <a href="#" className="hover:text-eco-500">Privacy Policy</a>
            <a href="#" className="hover:text-eco-500">Terms of Service</a>
            <a href="#" className="hover:text-eco-500">API Documentation</a>
          </div>
        </div>
      </footer>
    </div>
  );
};
